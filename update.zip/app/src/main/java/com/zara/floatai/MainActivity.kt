package com.zara.floatai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import java.util.Calendar
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var testVoice: Voice? = null
    private lateinit var status: TextView
    private var onImported: (() -> Unit)? = null
    private var permBuilder: (() -> Unit)? = null
    private val reqPick = 101
    private val purple = 0xFF7C3AED.toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF5B21B6.toInt()
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(40)) }
        val petalView = PetalView(this).apply { active = Prefs.get(this@MainActivity, "petals_app", "1") == "1" }

        fun bg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }
        fun card(title: String): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(Color.WHITE, 18, 0xFFE9E3FF.toInt())
                setPadding(dp(16), dp(14), dp(16), dp(16))
                elevation = dp(3).toFloat()
            }
            c.addView(TextView(this).apply { text = title; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(purple) })
            col.addView(c, LinearLayout.LayoutParams(mp, wc).apply { setMargins(dp(14), dp(12), dp(14), 0) })
            return c
        }
        fun label2(t: String) = TextView(this).apply { text = t; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF4C1D95.toInt()); setPadding(0, dp(14), 0, dp(2)) }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(0xFF6B7280.toInt()); setPadding(0, dp(6), 0, dp(2)) }
        fun btn(t: String, primary: Boolean = true, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else purple)
            background = bg(if (primary) purple else 0xFFEDE9FE.toInt(), 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { setMargins(0, dp(8), 0, 0) }
            setOnClickListener { v ->
                v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(90).start() }.start()
                f()
            }
        }
        fun rowOf(vararg bs: Button): LinearLayout {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in bs) r.addView(b, LinearLayout.LayoutParams(0, wc, 1f).apply { setMargins(dp(3), dp(8), dp(3), 0) })
            return r
        }
        fun edit(key: String, hint: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(Prefs.get(this@MainActivity, key, "")); setSingleLine(); textSize = 14f
            background = bg(0xFFF9F8FF.toInt(), 10, 0xFFD9D2F5.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { setMargins(0, dp(8), 0, 0) }
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { Prefs.put(this@MainActivity, key, e.toString().trim()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        fun spin(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        fun group() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun openUrl(u: String) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
            catch (e: Exception) { Toast.makeText(this, "Browser nahi khula", Toast.LENGTH_SHORT).show() }
        }
        fun paste(box: EditText) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
            if (t.isEmpty()) Toast.makeText(this, "Clipboard khaali hai. Pehle key copy karo.", Toast.LENGTH_LONG).show()
            else { box.setText(t); Toast.makeText(this, "Paste ho gaya (" + t.length + " chars)", Toast.LENGTH_SHORT).show() }
        }
        fun sw(t: String, key: String, def: String, extra: ((Boolean) -> Unit)? = null) = Switch(this).apply {
            text = t; textSize = 13.5f
            isChecked = Prefs.get(this@MainActivity, key, def) == "1"
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                Prefs.put(this@MainActivity, key, if (on) "1" else "0")
                if (extra != null) extra(on)
            }
        }

        // ---------- Header ----------
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF5B21B6.toInt(), 0xFFDB2777.toInt()))
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        head.addView(TextView(this).apply { text = "Sai AI"; textSize = 30f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) })
        head.addView(TextView(this).apply { text = "Made with \u2764 love  |  Director: Discord sai_108"; textSize = 12.5f; setTextColor(0xFFFCE7F3.toInt()); setPadding(0, dp(4), 0, 0) })
        head.addView(TextView(this).apply { text = "Tap = baat  |  Double tap = pyaar  |  Drag = move  |  2 sec dabao = band"; textSize = 11.5f; setTextColor(0xFFEDE9FE.toInt()); setPadding(0, dp(8), 0, 0) })
        col.addView(head, LinearLayout.LayoutParams(mp, wc))

        // ---------- Control ----------
        val cControl = card("Control")
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF374151.toInt()); setPadding(0, dp(8), 0, 0) }
        cControl.addView(status)
        cControl.addView(rowOf(btn("START") { start() }, btn("STOP", false) { stopService(Intent(this, FloatingService::class.java)) }))

        // ---------- Mode ----------
        val cMode = card("Mode")
        cMode.addView(spin(listOf("Normal (friendly, informal baat)", "Beast (sharp, extra intelligent agent)"), if (Prefs.get(this, "mode", "normal") == "beast") 1 else 0) {
            Prefs.put(this, "mode", if (it == 1) "beast" else "normal")
        })
        cMode.addView(note("Voice se bhi bol sakte ho: 'beast mode' ya 'normal mode'. Character badalne ke liye: 'switch to Jarvis' ya 'Maya bulao'. Awaaz badalne ke liye: 'voice badlo'."))

        // ---------- Permission manager ----------
        val cPerm = card("Permission manager")
        val permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cPerm.addView(permBox)
        fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        fun permRow(title: String, ok: Boolean, action: (() -> Unit)?) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(0xFF1F2937.toInt()) }, LinearLayout.LayoutParams(0, wc, 1f))
            r.addView(TextView(this).apply {
                text = if (ok) "ON" else "OFF"; textSize = 12f; setTypeface(null, Typeface.BOLD)
                setTextColor(if (ok) 0xFF15803D.toInt() else 0xFFB91C1C.toInt()); setPadding(dp(8), 0, dp(10), 0)
            })
            if (action != null) {
                r.addView(Button(this).apply {
                    text = if (ok) "Settings" else "Allow"; isAllCaps = false; textSize = 12f
                    setTextColor(Color.WHITE); background = bg(purple, 10)
                    minHeight = 0; minimumHeight = 0; setPadding(dp(10), dp(4), dp(10), dp(4))
                    setOnClickListener { action() }
                }, LinearLayout.LayoutParams(wc, dp(34)))
            }
            permBox.addView(r)
        }
        fun askPerm(p: String) { requestPermissions(arrayOf(p), 77) }
        val appInfoPage = { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        permBuilder = {
            permBox.removeAllViews()
            permRow("Display over other apps (floating character)", Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            permRow("Microphone (bolna)", has(Manifest.permission.RECORD_AUDIO)) { askPerm(Manifest.permission.RECORD_AUDIO) }
            permRow("Camera (Maya dekh sake)", has(Manifest.permission.CAMERA)) { askPerm(Manifest.permission.CAMERA) }
            if (Build.VERSION.SDK_INT >= 33) permRow("Notifications", has("android.permission.POST_NOTIFICATIONS")) { askPerm("android.permission.POST_NOTIFICATIONS") }
            permRow("Phone calls (call karna)", has(Manifest.permission.CALL_PHONE)) { askPerm(Manifest.permission.CALL_PHONE) }
            permRow("Contacts (naam se call/message)", has(Manifest.permission.READ_CONTACTS)) { askPerm(Manifest.permission.READ_CONTACTS) }
            permRow("Accessibility (Sai AI Voice Control)", Util.a11yOn(this)) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            permRow("Usage access (app detect)", Util.hasUsage(this)) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            permRow("Alarm / Timer", true, null)
            permRow("Installed apps ki list dekhna", packageManager.checkPermission("android.permission.QUERY_ALL_PACKAGES", packageName) == PackageManager.PERMISSION_GRANTED, null)
        }
        cPerm.addView(btn("Apps ka block list (kaun se apps Sai AI na khole)", false) {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
            val blocked = Util.blocked(this)
            val checked = BooleanArray(apps.size) { apps[it].second in blocked }
            AlertDialog.Builder(this)
                .setTitle("Block karo (Sai AI inhe nahi kholegi / padhegi / control karegi)")
                .setMultiChoiceItems(apps.map { it.first }.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
                .setPositiveButton("Save") { _, _ ->
                    Prefs.put(this, "blocked_apps", apps.filterIndexed { i, _ -> checked[i] }.joinToString(",") { it.second })
                    Toast.makeText(this, "Block list save ho gayi", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        cPerm.addView(btn("Android ke app permissions page kholo", false) { appInfoPage() })
        cPerm.addView(note("Accessibility ON na ho paaye (sideloaded app): phone Settings > Apps > Sai AI > 3 dots > 'Allow restricted settings', phir dobara try karo. PhonePe, bank jaise apps ko block list me daal sakte ho."))

        // ---------- Character ----------
        val cChar = card("Character")
        val preview = CharacterView(this)
        val nameTv = TextView(this).apply {
            textSize = 13.5f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            setTextColor(0xFF1F2937.toInt()); setPadding(0, dp(6), 0, 0)
        }
        var idx = Prefs.geti(this, "char")
        fun setChar(i: Int) {
            val es = CharStore.entries(this)
            idx = ((i % es.size) + es.size) % es.size
            Prefs.puti(this, "char", idx)
            CharStore.applyTo(preview, this, es[idx], Prefs.geti(this, "frame"))
            nameTv.text = (idx + 1).toString() + "/" + es.size + "   " + CharStore.displayName(this)
            val sz = preview.sizeFor(d, 1f)
            preview.layoutParams = LinearLayout.LayoutParams(sz[0], sz[1]).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) }
            preview.hop()
        }
        cChar.addView(preview, LinearLayout.LayoutParams(dp(120), dp(156)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        cChar.addView(nameTv)
        setChar(idx)
        onImported = { setChar(CharStore.entries(this).size - 1) }
        cChar.addView(rowOf(
            btn("< Prev", false) { setChar(idx - 1) },
            btn("Next >", false) { setChar(idx + 1) },
            btn("Delete", false) {
                val es = CharStore.entries(this)
                val e = es[idx.coerceIn(0, es.size - 1)]
                if (e.kind == 2 && e.file != null) { CharStore.delete(e.file); setChar(0) }
                else Toast.makeText(this, "Maya aur Jarvis built-in hain, delete nahi hote.", Toast.LENGTH_SHORT).show()
            }
        ))
        cChar.addView(btn("Apni anime image import karo") { pickImages() })
        val moods = listOf("neutral", "happy", "excited", "shy", "love", "wink", "thinking", "surprised", "sad", "cry", "angry", "sleepy")
        var mi = 0
        cChar.addView(rowOf(
            btn("Emotion", false) { mi = (mi + 1) % moods.size; preview.mood = moods[mi]; preview.hop() },
            btn("Wave", false) { preview.waving = true; preview.gesture("wave"); preview.postDelayed({ preview.waving = false }, 2500) },
            btn("Nod / No", false) { preview.gesture(if (Math.random() < 0.5) "nod" else "shake") }
        ))
        cChar.addView(edit("cname", "Character ka naam (khali = Maya / Jarvis)"))
        cChar.addView(note("Personality (baat karne ka andaaz):"))
        cChar.addView(spin(listOf("Auto (character ke hisaab se)") + Looks.titles, Prefs.geti(this, "persona")) { Prefs.puti(this, "persona", it) })
        cChar.addView(note("Frame (sirf import ki hui images ke liye):"))
        cChar.addView(spin(listOf("Rounded card", "Circle (sirf chehra)", "Bina frame (transparent PNG)"), Prefs.geti(this, "frame")) {
            Prefs.puti(this, "frame", it); setChar(idx)
        })
        cChar.addView(note("Size:"))
        cChar.addView(spin(listOf("Chhota", "Medium", "Bada"), Prefs.geti(this, "csize", 1)) { Prefs.puti(this, "csize", it) })
        cChar.addView(sw("Cherry blossom: baalon se girti petals", "petals_char", "1") { setChar(idx) })
        cChar.addView(note("Maya ke aankhein, muskaan, sar/gardan aur haath hilte hain. Jarvis ek hologram AI orb hai. Import ki hui images me sirf halka hilna aur bend hota hai. Sirf wahi images lagao jinka use karne ka tumhe haq hai."))

        // ---------- Voice library ----------
        val cVoice = card("Voice library")
        val voiceSpin = Spinner(this)
        fun reloadVoices() {
            val list = VoiceStore.all(this)
            voiceSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                list.map { (if (it.eleven) "[ElevenLabs]  " else "[Phone]  ") + it.name })
            voiceSpin.setSelection(VoiceStore.selected(this).coerceIn(0, list.size - 1))
        }
        voiceSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { VoiceStore.select(this@MainActivity, pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        reloadVoices()
        cVoice.addView(voiceSpin)

        fun addVoiceDialog(prefName: String, prefId: String) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
            val nm = EditText(this).apply { hint = "Voice ka naam"; setText(prefName) }
            val vid = EditText(this).apply { hint = "ElevenLabs Voice ID (phone voice ke liye khali chhodo)"; setText(prefId) }
            val pt = EditText(this).apply { hint = "Phone pitch 0.5 - 2.0 (default 1.2)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
            val rt = EditText(this).apply { hint = "Phone speed 0.5 - 2.0 (default 1.0)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
            box.addView(nm); box.addView(vid); box.addView(pt); box.addView(rt)
            AlertDialog.Builder(this)
                .setTitle("Voice add karo")
                .setView(box)
                .setPositiveButton("Add") { _, _ ->
                    val name = nm.text.toString().trim().ifEmpty { "My voice" }
                    val id = vid.text.toString().trim()
                    val pv = pt.text.toString().toFloatOrNull()?.coerceIn(0.5f, 2f) ?: 1.2f
                    val rv = rt.text.toString().toFloatOrNull()?.coerceIn(0.5f, 2f) ?: 1f
                    VoiceStore.add(this, VEntry(name, id.isNotEmpty(), id, pv, rv))
                    VoiceStore.select(this, VoiceStore.all(this).size - 1)
                    reloadVoices()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        fun testLine(): String {
            val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val g = when {
                hr in 5..11 -> "Good morning, sir."
                hr in 12..16 -> "Good afternoon, sir."
                hr in 17..20 -> "Good evening, sir."
                else -> "Good night, sir."
            }
            return g + " All systems are online. Everything is under control. Situation normal."
        }
        fun tv(): Voice {
            if (testVoice == null) testVoice = Voice(this, {}, { n -> runOnUiThread { Toast.makeText(this, n, Toast.LENGTH_LONG).show() } })
            return testVoice!!
        }
        cVoice.addView(rowOf(
            btn("Add voice", false) { addVoiceDialog("", "") },
            btn("Delete", false) {
                val sel = VoiceStore.selected(this)
                val nameSel = VoiceStore.current(this).name
                AlertDialog.Builder(this)
                    .setTitle("'" + nameSel + "' delete karein?")
                    .setPositiveButton("Delete") { _, _ ->
                        if (!VoiceStore.delete(this, sel)) Toast.makeText(this, "Kam se kam ek voice rakhni padegi", Toast.LENGTH_SHORT).show()
                        reloadVoices()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            },
            btn("Test", false) { tv().speak(testLine(), "neutral", "en-US") }
        ))

        cVoice.addView(label2("ElevenLabs account"))
        cVoice.addView(note("ElevenLabs par free account banao, API key copy karo. Free plan me monthly characters limited hain. Hindi aur English dono chalte hain."))
        cVoice.addView(btn("1) ElevenLabs key page", false) { openUrl("https://elevenlabs.io/app/settings/api-keys") })
        val ek = edit("el_key", "ElevenLabs API key", true)
        cVoice.addView(ek)
        cVoice.addView(btn("2) Copy ki hui key paste karo", false) { paste(ek) })
        cVoice.addView(edit("el_model", "Model (khali = auto)"))
        val elStatus = TextView(this).apply { textSize = 12.5f; setPadding(0, dp(6), 0, 0) }
        val elIds = ArrayList<String>()
        val elNames = ArrayList<String>()
        val elSpin = Spinner(this).apply { visibility = View.GONE }
        cVoice.addView(btn("3) ElevenLabs se meri voices load karo", false) {
            elStatus.setTextColor(0xFF6B7280.toInt())
            elStatus.text = "Load ho rahi hain..."
            Thread {
                try {
                    val list = Eleven.listVoices(Prefs.get(this, "el_key").trim())
                    runOnUiThread {
                        elIds.clear(); elNames.clear()
                        elIds.addAll(list.map { it.first }); elNames.addAll(list.map { it.second })
                        elSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, elNames)
                        elSpin.visibility = View.VISIBLE
                        elStatus.setTextColor(0xFF15803D.toInt())
                        elStatus.text = list.size.toString() + " voices mili. Ek chuno aur library me add karo."
                    }
                } catch (e: Exception) {
                    runOnUiThread { elStatus.setTextColor(0xFFB91C1C.toInt()); elStatus.text = Eleven.friendly(e) }
                }
            }.start()
        })
        cVoice.addView(elStatus)
        cVoice.addView(elSpin)
        cVoice.addView(btn("Chuni hui voice library me add karo", false) {
            val i = elSpin.selectedItemPosition
            if (i in elIds.indices) addVoiceDialog(elNames[i], elIds[i])
        })

        val langs = listOf("hi-IN", "en-US", "en-IN")
        cVoice.addView(note("Bolne ki language (mic aur phone voice ke liye):"))
        cVoice.addView(spin(listOf("Hindi / Hinglish", "English (US)", "English (India)"), langs.indexOf(Prefs.get(this, "lang", "hi-IN")).coerceAtLeast(0)) {
            Prefs.put(this, "lang", langs[it])
        })

        // ---------- AI brain ----------
        val cAi = card("AI brain")
        val provs = listOf("offline", "gemini", "groq", "openai", "free", "custom")
        val provNames = listOf(
            "Offline (bina internet)", "Gemini (Google) - free key", "Groq - free key",
            "ChatGPT (OpenAI) - paid", "Free no-key service (experimental)", "Custom OpenAI-compatible"
        )
        val groups = HashMap<String, LinearLayout>()
        fun showGroup(p: String) { for ((k, v) in groups) v.visibility = if (k == p) View.VISIBLE else View.GONE }
        cAi.addView(spin(provNames, provs.indexOf(Prefs.get(this, "provider", "offline")).coerceAtLeast(0)) {
            Prefs.put(this, "provider", provs[it]); showGroup(provs[it])
        })

        val gGem = group()
        gGem.addView(note("Google login se free key. Key AIza ya AQ. se shuru hoti hai."))
        gGem.addView(btn("1) Free key banao", false) { openUrl("https://aistudio.google.com/apikey") })
        val gk = edit("gemini_key", "Gemini API key", true)
        gGem.addView(gk)
        gGem.addView(btn("2) Copy ki hui key paste karo", false) { paste(gk) })
        gGem.addView(edit("gem_model2", "Gemini model (khali = auto)"))
        groups["gemini"] = gGem

        val gGroq = group()
        gGroq.addView(note("Free aur fast. Key gsk_ se shuru hoti hai."))
        gGroq.addView(btn("1) Free key banao", false) { openUrl("https://console.groq.com/keys") })
        val qk = edit("groq_key", "Groq API key", true)
        gGroq.addView(qk)
        gGroq.addView(btn("2) Copy ki hui key paste karo", false) { paste(qk) })
        gGroq.addView(edit("groq_model2", "Groq model (khali = auto)"))
        groups["groq"] = gGroq

        val gOa = group()
        gOa.addView(note("OpenAI API me credit chahiye. ChatGPT Plus alag cheez hai, usse API nahi chalti."))
        gOa.addView(btn("1) Key page kholo", false) { openUrl("https://platform.openai.com/api-keys") })
        val ok = edit("openai_key", "OpenAI API key", true)
        gOa.addView(ok)
        gOa.addView(btn("2) Copy ki hui key paste karo", false) { paste(ok) })
        gOa.addView(edit("oa_model2", "OpenAI model (khali = auto)"))
        groups["openai"] = gOa

        val gFree = group()
        gFree.addView(note("Bina key, bina login. Public free service hai: slow ho sakti hai, kabhi band bhi, aur baatein unke server par jaati hain."))
        groups["free"] = gFree

        val gCus = group()
        gCus.addView(note("OpenRouter, Together, Mistral ya apna server. URL, key aur model naam daalo."))
        val cu = edit("custom_url", "Base URL (jaise https://openrouter.ai/api/v1)")
        gCus.addView(cu)
        gCus.addView(btn("OpenRouter URL bharo", false) { cu.setText("https://openrouter.ai/api/v1") })
        val ck = edit("custom_key", "API key (agar chahiye)", true)
        gCus.addView(ck)
        gCus.addView(btn("Copy ki hui key paste karo", false) { paste(ck) })
        gCus.addView(edit("custom_model", "Model naam"))
        groups["custom"] = gCus

        for (g in groups.values) cAi.addView(g)
        showGroup(Prefs.get(this, "provider", "offline"))
        cAi.addView(sw("Chuna AI na chale toh free no-key service bhi try karo", "backupfree", "0"))
        cAi.addView(note("Agar ek se zyada AI ki key daali hai, toh ek fail hone par doosra apne aap chalta hai."))
        val result = TextView(this).apply { setPadding(0, dp(8), 0, dp(4)); textSize = 13f }
        cAi.addView(btn("Test connection") {
            result.text = "Testing..."
            result.setTextColor(0xFF6B7280.toInt())
            Thread {
                val r = Brain.test(this)
                runOnUiThread {
                    result.text = r
                    result.setTextColor(if (r.startsWith("CONNECTED")) 0xFF15803D.toInt() else 0xFFB91C1C.toInt())
                }
            }.start()
        })
        cAi.addView(result)

        // ---------- Phone control ----------
        val cPhone = card("Voice se phone control")
        cPhone.addView(note("Bolo jaise: 'YouTube kholo', 'back jao', 'scroll down', 'torch on', 'volume badhao', 'Mummy ko call karo', '7 baje ka alarm lagao', 'is page me astro kahan hai'."))
        cPhone.addView(sw("Phone control ON", "phonectl", "0"))
        cPhone.addView(btn("1) Accessibility ON karo: Sai AI Voice Control") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        cPhone.addView(btn("2) Call + Contacts permission do", false) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 2)
        })
        cPhone.addView(note("Call ya message se pehle Sai AI tumse 'haan' bulwa kar confirm karti hai. 'Is page me ...' bolne par screen ka text tumhare chune AI ko bheja jata hai, sirf tabhi."))

        // ---------- Features ----------
        val cFeat = card("Features")
        cFeat.addView(sw("Sai AI kabhi kabhi khud se bolegi (idle chatter)", "idle", "1"))
        cFeat.addView(sw("App me cherry blossom effect", "petals_app", "1") { petalView.active = it })
        cFeat.addView(sw("App detect: khule apps par reaction", "appdetect", "0") { on ->
            if (on && !Util.hasUsage(this)) {
                Toast.makeText(this, "Sai AI ke liye Usage access ON karo", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        })
        cFeat.addView(btn("Usage access kholo", false) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        cFeat.addView(note("Volume + aur - ek saath dabane par character aa jata hai (Accessibility ON honi chahiye)."))

        // ---------- Memory ----------
        val cMem = card("Memory")
        cMem.addView(btn("Sai AI ne kya yaad rakha dekho", false) {
            AlertDialog.Builder(this)
                .setTitle("Yaaddasht")
                .setMessage(Memory.facts(this).joinToString("\n").ifEmpty { "Abhi kuch yaad nahi. Mujhse baat karo!" })
                .setPositiveButton("OK", null)
                .setNegativeButton("Sab bhula do") { _, _ -> Memory.clear(this) }
                .show()
        })
        cMem.addView(note("Har kuch baaton ke baad Sai AI (AI ki madad se) tumhara naam, pasand-napasand, routine, doston ke naam wagairah yaad rakhti hai. Bolo: 'yaad rakh <baat>' ya 'sab bhool ja'."))

        col.addView(TextView(this).apply {
            text = "Made with \u2764 love\nDirector: Discord sai_108"
            textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFF6B7280.toInt()); setPadding(0, dp(24), 0, 0)
        }, LinearLayout.LayoutParams(mp, wc))

        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { setBackgroundColor(0xFFF5F3FF.toInt()); addView(col) }, FrameLayout.LayoutParams(mp, mp))
        frame.addView(petalView, FrameLayout.LayoutParams(mp, mp))
        setContentView(frame)

        for (i in 1 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(420).start()
        }
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, reqPick)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            data.data?.let { uris.add(it) }
            val cd = data.clipData
            if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            Thread {
                var n = 0
                for (u in uris.distinct()) if (CharStore.import(this, u)) n++
                runOnUiThread {
                    Toast.makeText(this, n.toString() + " image import hui", Toast.LENGTH_SHORT).show()
                    onImported?.invoke()
                }
            }.start()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permBuilder?.invoke()
    }

    override fun onResume() {
        super.onResume()
        permBuilder?.invoke()
        val ov = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay: " + (if (ov) "OK" else "NAHI") +
            "   |   Mic: " + (if (mic) "OK" else "NAHI") +
            "\nUsage access: " + (if (Util.hasUsage(this)) "OK" else "band") +
            "   |   Volume wake: " + (if (Util.a11yOn(this)) "ON" else "band")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
            Toast.makeText(this, "Mic permission do, phir START dobara dabao", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" allow karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Sai AI chalu!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { testVoice?.shutdown(); super.onDestroy() }
}
