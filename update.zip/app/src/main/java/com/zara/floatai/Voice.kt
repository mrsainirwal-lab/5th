package com.zara.floatai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Voice(private val ctx: Context, private val onSpeaking: (Boolean) -> Unit) : TextToSpeech.OnInitListener {
    companion object {
        val names = listOf("1. Idol Star", "2. Soft Whisper", "3. Hero Boy", "4. Sleepy Cat", "5. Bubbly Pop",
            "6. Cool Senpai", "7. Fairy", "8. Dark Queen", "9. Anime Narrator", "10. Cheerful Sensei")
        private val pitch = floatArrayOf(1.7f, 1.1f, 0.85f, 1.3f, 2.0f, 0.7f, 1.8f, 0.55f, 0.95f, 1.2f)
        private val rate = floatArrayOf(1.1f, 0.7f, 1.1f, 0.65f, 1.3f, 0.95f, 0.9f, 0.85f, 0.75f, 1.15f)
    }

    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private var pending: String? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ready = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { h.post { onSpeaking(true) } }
            override fun onDone(id: String?) { h.post { onSpeaking(false) } }
            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(id: String?) { h.post { onSpeaking(false) } }
        })
        pending?.let { speak(it) }
        pending = null
    }

    fun speak(text: String) {
        val e = tts
        if (!ready || e == null) { pending = text; return }
        val v = Prefs.geti(ctx, "voice").coerceIn(0, 9)
        val loc = Locale.forLanguageTag(Prefs.get(ctx, "lang", "hi-IN"))
        e.language = loc
        val vs = e.voices?.filter { it.locale.language == loc.language && !it.isNetworkConnectionRequired }?.sortedBy { it.name }
        if (!vs.isNullOrEmpty()) e.voice = vs[(v * 3 + 1) % vs.size]
        e.setPitch(pitch[v])
        e.setSpeechRate(rate[v])
        e.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun stop() { tts?.stop(); onSpeaking(false) }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}
