package com.zara.floatai

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.util.Locale

/**
 * Chain commands: "WhatsApp kholo aur Siri ko hi bhejo", "Spotify par gaana chalao", "wifi band karo".
 * Ek command me kai steps ho sakte hain, jo "aur" / "phir" / "then" / "and" se alag hote hain.
 */
object ChainCommands {
    private val splitter = Regex("\\s+(?:aur|phir|then|and|fir)\\s+", RegexOption.IGNORE_CASE)

    fun split(raw: String): List<String> = raw.trim().split(splitter).map { it.trim() }.filter { it.isNotEmpty() }

    /** Spotify: pehle app kholo, phir search link se gaana. Spotify installed na ho toh browser me search. */
    fun spotify(c: Context, query: String): Reply {
        val q = query.trim()
        val uri = Uri.parse("spotify:search:" + Uri.encode(q))
        val i = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            c.startActivity(i)
            Reply("Spotify par " + q + " dhundh rahi hoon. Play dabana aapke haath me hai, ya bolo 'play' aur main accessibility se tap karungi.", "happy")
        } catch (e: Exception) {
            try {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Reply(q + " Spotify web par khol diya.", "happy")
            } catch (e2: Exception) {
                Reply("Spotify nahi khul paaya.", "sad")
            }
        }
    }

    /** Wi-Fi/Bluetooth: Android 10+ par app seedha toggle nahi kar sakti, isliye Quick Settings panel khol kar tap karti hai. */
    fun toggle(c: Context, what: String, on: Boolean): Reply {
        val svc = VolumeService.instance ?: return Reply("Accessibility ON karo, tab main ye tap kar paungi.", "sad")
        val ok = svc.openQuickSettingsAndTap(what, on)
        return if (ok) Reply(what + " " + (if (on) "on" else "off") + " karne ki koshish kar rahi hoon.", "happy")
        else Reply(what + " ka toggle panel me nahi mila. Ek baar dekh lo.", "thinking")
    }

    fun isChain(raw: String): Boolean = split(raw).size > 1
}
