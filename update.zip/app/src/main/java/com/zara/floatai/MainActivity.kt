package com.zara.floatai

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private var testVoice: Voice? = null
    private lateinit var status: TextView
    private var onImported: (() -> Unit)? = null
    private val reqPick = 101
    private val purple = 0xFF7C3AED.toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF5B21B6.toInt()
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(40)) }

        fun bg(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }
        fun card(title: String): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(Color.WHITE, 18, 0xFFE9E3FF.toInt())
                setPadding(dp(16), dp(14), dp(16), dp(16))
                elevation = dp(3).toFloat()
            }
            c.addView(TextView(this).apply { text = title; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(purple) })
            col.addView(c, LinearLayout.LayoutParams(mp, wc).apply { setMargins(dp(14), dp(12), dp(14), 0) })
            return c
        }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 12f; setTextColor(0xFF6B7280.toInt()); setPadding(0, dp(6), 0, dp(2)) }
        fun btn(t: String, primary: Boolean = true, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else purple)
            background = bg(if (primary) purple else 0xFFEDE9FE.toInt(), 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { setMargins(0, dp(8), 0, 0) }
            setOnClickListener { v ->
                v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(90).start() }.start()
                f()
            }
        }
        fun rowOf(vararg bs: Button): LinearLayout {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (b in bs) r.addView(b, LinearLayout.LayoutParams(0, wc, 1f).apply { setMargins(dp(3), dp(8), dp(3), 0) })
            return r
        }
        fun edit(key: String, hint: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(Prefs.get(this@MainActivity, key, "")); setSingleLine(); textSize = 14f
            background = bg(0xFFF9F8FF.toInt(), 10, 0xFFD9D2F5.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(mp, wc).apply { setMargins(0, dp(8), 0, 0) }
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { Prefs.put(this@MainActivity, key, e.toString().trim()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        fun spin(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        fun group() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun openUrl(u: String) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
            catch (e: Exception) { Toast.makeText(this, "Browser nahi khula", Toast.LENGTH_SHORT).show() }
        }
        fun paste(box: EditText) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
            if (t.isEmpty()) Toast.makeText(this, "Clipboard khaali hai. Pehle key copy karo.", Toast.LENGTH_LONG).show()
            else { box.setText(t); Toast.makeText(this, "Paste ho gaya (" + t.length + " chars)", Toast.LENGTH_SHORT).show() }
        }
        fun sw(t: String, key: String, def: String, extra: ((Boolean) -> Unit)? = null) = Switch(this).apply {
            text = t; textSize = 13.5f
            isChecked = Prefs.get(this@MainActivity, key, def) == "1"
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                Prefs.put(this@MainActivity, key, if (on) "1" else "0")
                if (extra != null) extra(on)
            }
        }

        // ---------- Header ----------
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF5B21B6.toInt(), 0xFFDB2777.toInt()))
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        head.addView(TextView(this).apply { text = "Sai AI"; textSize = 30f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) })
        head.addView(TextView(this).apply { text = "Made with \u2764 love  |  Director: Discord sai_108"; textSize = 12.5f; setTextColor(0xFFFCE7F3.toInt()); setPadding(0, dp(4), 0, 0) })
        head.addView(TextView(this).apply { text = "Tap = baat  |  Double tap = pyaar  |  Drag = move  |  2 sec dabao = band"; textSize = 11.5f; setTextColor(0xFFEDE9FE.toInt()); setPadding(0, dp(8), 0, 0) })
        col.addView(head, LinearLayout.LayoutParams(mp, wc))

        // ---------- Control ----------
        val cControl = card("Control")
        status = TextView(this).apply { textSize = 13f; setTextColor(0xFF374151.toInt()); setPadding(0, dp(8), 0, 0) }
        cControl.addView(status)
        cControl.addView(rowOf(btn("START") { start() }, btn("STOP", false) { stopService(Intent(this, FloatingService::class.java)) }))

        // ---------- Character ----------
        val cChar = card("Character (apni anime images)")
        val preview = CharacterView(this)
        val nameTv = TextView(this).apply {
            textSize = 13.5f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            setTextColor(0xFF1F2937.toInt()); setPadding(0, dp(6), 0, 0)
        }
        var idx = Prefs.geti(this, "char")
        fun setChar(i: Int) {
            val files = CharStore.list(this)
            if (files.isEmpty()) {
                preview.setImage(null, 0)
                nameTv.text = "Abhi koi image nahi hai. Neeche 'Image import karo' dabao (kai saath chun sakte ho)."
            } else {
                idx = ((i % files.size) + files.size) % files.size
                Prefs.puti(this, "char", idx)
                preview.setImage(CharStore.load(files[idx]), Prefs.geti(this, "frame"))
                nameTv.text = (idx + 1).toString() + "/" + files.size + "   " + Prefs.get(this, "cname", "Sai").ifBlank { "Sai" }
            }
            val sz = preview.sizeFor(d, 1f)
            preview.layoutParams = LinearLayout.LayoutParams(sz[0], sz[1]).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) }
            preview.hop()
        }
        cChar.addView(preview, LinearLayout.LayoutParams(dp(120), dp(156)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        cChar.addView(nameTv)
        setChar(idx)
        onImported = { setChar(CharStore.list(this).size - 1) }
        cChar.addView(btn("Image import karo (anime pics)") { pickImages() })
        cChar.addView(rowOf(
            btn("< Prev", false) { setChar(idx - 1) },
            btn("Next >", false) { setChar(idx + 1) },
            btn("Delete", false) {
                val files = CharStore.list(this)
                if (files.isNotEmpty()) { CharStore.delete(files[idx.coerceIn(0, files.size - 1)]); setChar(0) }
            }
        ))
        val moods = listOf("neutral", "happy", "excited", "shy", "love", "wink", "thinking", "surprised", "sad", "cry", "angry", "sleepy")
        var mi = 0
        cChar.addView(btn("Emotion dikhao", false) { mi = (mi + 1) % moods.size; preview.mood = moods[mi]; preview.hop() })
        cChar.addView(edit("cname", "Character ka naam (default: Sai)"))
        cChar.addView(note("Personality (baat karne ka andaaz):"))
        cChar.addView(spin(Looks.titles, Prefs.geti(this, "persona")) { Prefs.puti(this, "persona", it) })
        cChar.addView(note("Frame:"))
        cChar.addView(spin(listOf("Rounded card", "Circle (sirf chehra)", "Bina frame (transparent PNG)"), Prefs.geti(this, "frame")) {
            Prefs.puti(this, "frame", it); setChar(idx)
        })
        cChar.addView(note("Size:"))
        cChar.addView(spin(listOf("Chhota", "Medium", "Bada"), Prefs.geti(this, "csize", 1)) { Prefs.puti(this, "csize", it) })
        cChar.addView(note("Image pe expressions rang-effects aur hearts/sparkles se dikhte hain (image ka chehra badalta nahi). Drag karne par image neeche se bend hoti hai, asli baalon ki physics nahi. Sirf wahi images use karo jinka use karne ka tumhe haq hai."))

        // ---------- Voice ----------
        val cVoice = card("Voice")
        val engines = listOf("phone", "eleven")
        val gPhone = group()
        val gEl = group()
        fun showEngine(e: String) {
            gPhone.visibility = if (e == "phone") View.VISIBLE else View.GONE
            gEl.visibility = if (e == "eleven") View.VISIBLE else View.GONE
        }
        cVoice.addView(spin(listOf("Phone voice (offline)", "ElevenLabs (natural, internet + key)"), engines.indexOf(Prefs.get(this, "tts_engine", "phone")).coerceAtLeast(0)) {
            Prefs.put(this, "tts_engine", engines[it]); showEngine(engines[it])
        })
        gPhone.addView(note("Phone ki awaaz robotic lag sakti hai. Settings me Google Text-to-speech ki Hindi voice download karo, ya ElevenLabs chuno."))
        gPhone.addView(spin(Voice.names, Prefs.geti(this, "voice")) { Prefs.puti(this, "voice", it) })

        gEl.addView(note("ElevenLabs par free account banao, API key copy karo. Free plan me har mahine limited characters milte hain."))
        gEl.addView(btn("1) ElevenLabs key page", false) { openUrl("https://elevenlabs.io/app/settings/api-keys") })
        val ek = edit("el_key", "ElevenLabs API key", true)
        gEl.addView(ek)
        gEl.addView(btn("2) Copy ki hui key paste karo", false) { paste(ek) })
        val elStatus = TextView(this).apply { textSize = 12.5f; setPadding(0, dp(6), 0, 0) }
        val elIds = ArrayList<String>()
        val vEdit = edit("el_voice", "Voice ID (neeche list se chuno ya khud daalo)")
        val elSpin = Spinner(this).apply { visibility = View.GONE }
        elSpin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (pos in elIds.indices) vEdit.setText(elIds[pos]) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        gEl.addView(btn("3) Meri voices load karo", false) {
            elStatus.text = "Load ho rahi hain..."
            Thread {
                try {
                    val list = Eleven.listVoices(Prefs.get(this, "el_key").trim())
                    runOnUiThread {
                        elIds.clear()
                        elIds.addAll(list.map { it.first })
                        elSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list.map { it.second })
                        elSpin.visibility = View.VISIBLE
                        elStatus.setTextColor(0xFF15803D.toInt())
                        elStatus.text = list.size.toString() + " voices mili. Ek chuno."
                    }
                } catch (e: Exception) {
                    runOnUiThread { elStatus.setTextColor(0xFFB91C1C.toInt()); elStatus.text = Eleven.friendly(e) }
                }
            }.start()
        })
        gEl.addView(elStatus)
        gEl.addView(elSpin)
        gEl.addView(vEdit)
        gEl.addView(edit("el_model", "Model (khali = auto)"))
        cVoice.addView(gPhone)
        cVoice.addView(gEl)
        showEngine(Prefs.get(this, "tts_engine", "phone"))

        fun tv(): Voice {
            if (testVoice == null) testVoice = Voice(this, {}, { n -> runOnUiThread { Toast.makeText(this, n, Toast.LENGTH_LONG).show() } })
            return testVoice!!
        }
        cVoice.addView(rowOf(
            btn("Test: khush", false) { tv().speak("Arre wah, tum aa gaye! Kaise ho? Mujhe tumhari bahut yaad aayi.", "happy") },
            btn("Test: sharmili", false) { tv().speak("U-um... hello. Mujhe thodi sharam aa rahi hai.", "shy") }
        ))
        val langs = listOf("hi-IN", "en-US", "en-IN")
        cVoice.addView(note("Bolne ki language (mic aur phone voice ke liye):"))
        cVoice.addView(spin(listOf("Hindi / Hinglish", "English (US)", "English (India)"), langs.indexOf(Prefs.get(this, "lang", "hi-IN")).coerceAtLeast(0)) {
            Prefs.put(this, "lang", langs[it])
        })

        // ---------- AI brain ----------
        val cAi = card("AI brain")
        val provs = listOf("offline", "gemini", "groq", "openai", "free", "custom")
        val provNames = listOf(
            "Offline (bina internet)", "Gemini (Google) - free key", "Groq - free key",
            "ChatGPT (OpenAI) - paid", "Free no-key service (experimental)", "Custom OpenAI-compatible"
        )
        val groups = HashMap<String, LinearLayout>()
        fun showGroup(p: String) { for ((k, v) in groups) v.visibility = if (k == p) View.VISIBLE else View.GONE }
        cAi.addView(spin(provNames, provs.indexOf(Prefs.get(this, "provider", "offline")).coerceAtLeast(0)) {
            Prefs.put(this, "provider", provs[it]); showGroup(provs[it])
        })

        val gGem = group()
        gGem.addView(note("Google login se free key. Key AIza ya AQ. se shuru hoti hai."))
        gGem.addView(btn("1) Free key banao", false) { openUrl("https://aistudio.google.com/apikey") })
        val gk = edit("gemini_key", "Gemini API key", true)
        gGem.addView(gk)
        gGem.addView(btn("2) Copy ki hui key paste karo", false) { paste(gk) })
        gGem.addView(edit("gem_model2", "Gemini model (khali = auto)"))
        groups["gemini"] = gGem

        val gGroq = group()
        gGroq.addView(note("Free aur fast. Key gsk_ se shuru hoti hai."))
        gGroq.addView(btn("1) Free key banao", false) { openUrl("https://console.groq.com/keys") })
        val qk = edit("groq_key", "Groq API key", true)
        gGroq.addView(qk)
        gGroq.addView(btn("2) Copy ki hui key paste karo", false) { paste(qk) })
        gGroq.addView(edit("groq_model2", "Groq model (khali = auto)"))
        groups["groq"] = gGroq

        val gOa = group()
        gOa.addView(note("OpenAI API me credit chahiye. ChatGPT Plus alag cheez hai, usse API nahi chalti."))
        gOa.addView(btn("1) Key page kholo", false) { openUrl("https://platform.openai.com/api-keys") })
        val ok = edit("openai_key", "OpenAI API key", true)
        gOa.addView(ok)
        gOa.addView(btn("2) Copy ki hui key paste karo", false) { paste(ok) })
        gOa.addView(edit("oa_model2", "OpenAI model (khali = auto)"))
        groups["openai"] = gOa

        val gFree = group()
        gFree.addView(note("Bina key, bina login. Public free service hai: slow ho sakti hai, kabhi band bhi, aur baatein unke server par jaati hain."))
        groups["free"] = gFree

        val gCus = group()
        gCus.addView(note("OpenRouter, Together, Mistral ya apna server. URL, key aur model naam daalo."))
        val cu = edit("custom_url", "Base URL (jaise https://openrouter.ai/api/v1)")
        gCus.addView(cu)
        gCus.addView(btn("OpenRouter URL bharo", false) { cu.setText("https://openrouter.ai/api/v1") })
        val ck = edit("custom_key", "API key (agar chahiye)", true)
        gCus.addView(ck)
        gCus.addView(btn("Copy ki hui key paste karo", false) { paste(ck) })
        gCus.addView(edit("custom_model", "Model naam"))
        groups["custom"] = gCus

        for (g in groups.values) cAi.addView(g)
        showGroup(Prefs.get(this, "provider", "offline"))
        cAi.addView(sw("Chuna AI na chale toh free no-key service bhi try karo", "backupfree", "0"))
        cAi.addView(note("Agar ek se zyada AI ki key daali hai, toh ek fail hone par doosra apne aap chalta hai."))
        val result = TextView(this).apply { setPadding(0, dp(8), 0, dp(4)); textSize = 13f }
        cAi.addView(btn("Test connection") {
            result.text = "Testing..."
            result.setTextColor(0xFF6B7280.toInt())
            Thread {
                val r = Brain.test(this)
                runOnUiThread {
                    result.text = r
                    result.setTextColor(if (r.startsWith("CONNECTED")) 0xFF15803D.toInt() else 0xFFB91C1C.toInt())
                }
            }.start()
        })
        cAi.addView(result)

        // ---------- Features ----------
        val cFeat = card("Features")
        cFeat.addView(sw("Zara kabhi kabhi khud se bolegi (idle chatter)", "idle", "1"))
        cFeat.addView(sw("App detect: khule apps par reaction", "appdetect", "0") { on ->
            if (on && !Util.hasUsage(this)) {
                Toast.makeText(this, "Sai AI ke liye Usage access ON karo", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        })
        cFeat.addView(btn("Usage access kholo", false) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        cFeat.addView(btn("Volume + - wake: Accessibility kholo", false) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        cFeat.addView(note("Accessibility me 'Zara Volume Wake' ON karo. Phir Volume + aur - ek saath dabane par character aa jayega."))
        cFeat.addView(btn("Zara ki yaaddasht reset karo", false) { Memory.clear(this); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show() })
        cFeat.addView(note("Bolo: \"yaad rakh <baat>\" ya \"my name is ...\". \"sab bhool ja\" se memory clear."))

        col.addView(TextView(this).apply {
            text = "Made with \u2764 love\nDirector: Discord sai_108"
            textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFF6B7280.toInt()); setPadding(0, dp(24), 0, 0)
        }, LinearLayout.LayoutParams(mp, wc))

        setContentView(ScrollView(this).apply { setBackgroundColor(0xFFF5F3FF.toInt()); addView(col) })

        for (i in 1 until col.childCount) {
            val v = col.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(28).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(420).start()
        }
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, reqPick)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            data.data?.let { uris.add(it) }
            val cd = data.clipData
            if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            Thread {
                var n = 0
                for (u in uris.distinct()) if (CharStore.import(this, u)) n++
                runOnUiThread {
                    Toast.makeText(this, n.toString() + " image import hui", Toast.LENGTH_SHORT).show()
                    onImported?.invoke()
                }
            }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay: " + (if (ov) "OK" else "NAHI") +
            "   |   Mic: " + (if (mic) "OK" else "NAHI") +
            "\nUsage access: " + (if (Util.hasUsage(this)) "OK" else "band") +
            "   |   Volume wake: " + (if (Util.a11yOn(this)) "ON" else "band")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
            Toast.makeText(this, "Mic permission do, phir START dobara dabao", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" allow karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Sai AI chalu!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { testVoice?.shutdown(); super.onDestroy() }
}
