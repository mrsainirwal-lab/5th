package com.zara.floatai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** kind: 0 = Maya (built-in image), 1 = Jarvis (built-in hologram orb), 2 = tumhari import ki hui image. */
class Entry(val name: String, val kind: Int, val file: File?)

object CharStore {
    private fun dir(c: Context): File {
        val d = File(c.filesDir, "chars")
        d.mkdirs()
        return d
    }

    fun list(c: Context): List<File> = dir(c).listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()

    fun entries(c: Context): List<Entry> {
        val out = ArrayList<Entry>()
        out.add(Entry("Maya", 0, null))
        out.add(Entry("Jarvis", 1, null))
        list(c).forEachIndexed { i, f -> out.add(Entry("Custom " + (i + 1), 2, f)) }
        return out
    }

    fun current(c: Context): Entry {
        val e = entries(c)
        return e[Prefs.geti(c, "char").coerceIn(0, e.size - 1)]
    }

    fun displayName(c: Context): String = Prefs.get(c, "cname").trim().ifEmpty { current(c).name }

    fun bitmap(c: Context, e: Entry): Bitmap? = when (e.kind) {
        0 -> try { c.assets.open("maya.png").use { BitmapFactory.decodeStream(it) } } catch (ex: Exception) { null }
        1 -> null
        else -> e.file?.let { load(it) }
    }

    /** Entry ko CharacterView par laga deta hai (image / rig / orb). */
    fun applyTo(ch: CharacterView, c: Context, e: Entry, frame: Int) {
        ch.petalsOn = Prefs.get(c, "petals_char", "1") == "1"
        when (e.kind) {
            1 -> ch.setOrb()
            0 -> ch.setImage(bitmap(c, e), 2, true)
            else -> ch.setImage(bitmap(c, e), frame, false)
        }
    }

    fun load(f: File): Bitmap? = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }

    fun delete(f: File) { try { f.delete() } catch (e: Exception) {} }

    fun import(c: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val big = maxOf(bounds.outWidth, bounds.outHeight)
            while (big / sample > 1400) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val scale = 640f / maxOf(bmp.width, bmp.height)
            val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val alpha = out.hasAlpha()
            val f = File(dir(c), "c_" + System.nanoTime() + (if (alpha) ".png" else ".jpg"))
            f.outputStream().use { out.compress(if (alpha) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}
