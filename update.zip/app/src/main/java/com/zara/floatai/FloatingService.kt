package com.zara.floatai

import android.Manifest
import android.animation.ValueAnimator
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar
import kotlin.math.abs
import kotlin.random.Random

class FloatingService : Service() {
    companion object {
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var ch: CharacterView
    private lateinit var lp: WindowManager.LayoutParams
    private var voice: Voice? = null
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var busy = false
    private var built = false
    private var dens = 1f
    private var lastReact = 0L
    private var lastPkg = ""
    private var lastTap = 0L

    private val hideBubble = Runnable { if (built) bubble.visibility = View.GONE }
    private val sleepRun = Runnable {
        if (built && !busy && !ch.speaking) { ch.sleeping = true; bubble.visibility = View.GONE }
    }
    private val calmRun = Runnable { if (built) { ch.mood = "neutral"; ch.waving = false } }
    private val singleTapRun = Runnable { onTap() }
    private val watchRun = object : Runnable {
        override fun run() {
            try { watchApps() } catch (e: Exception) {}
            h.postDelayed(this, 3500)
        }
    }
    private val idleRun = object : Runnable {
        override fun run() {
            try { idleTick() } catch (e: Exception) {}
            h.postDelayed(this, 70000L + Random.nextLong(60000L))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!startFg()) { stopSelf(); return START_NOT_STICKY }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        running = true
        val wasBuilt = built
        if (!built) build() else applyChar()
        if (!wasBuilt || intent?.action == "wake") {
            poke()
            greet()
        }
        return START_STICKY
    }

    private fun startFg(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("zara", "Sai AI", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, "zara")
                .setContentTitle("Sai AI is floating")
                .setContentText("Tap = baat, double tap = pyaar, 2 sec dabao = band.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun build() {
        built = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        dens = d
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        bubble = TextView(this).apply {
            setTextColor(0xFF1F2937.toInt()); textSize = 13.5f
            setPadding((14 * d).toInt(), (9 * d).toInt(), (14 * d).toInt(), (9 * d).toInt())
            maxWidth = (240 * d).toInt()
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 18 * d; setStroke((2 * d).toInt(), 0xFFC4B5FD.toInt()) }
            visibility = View.GONE
        }
        ch = CharacterView(this)
        root.addView(bubble)
        root.addView(ch, LinearLayout.LayoutParams((120 * d).toInt(), (156 * d).toInt()))
        applyChar()
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (8 * d).toInt(); y = (240 * d).toInt() }

        voice = Voice(this, { ch.speaking = it }, { n -> show(n, 6000) })

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        val closeRun = Runnable { stopSelf() }
        ch.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                    h.postDelayed(closeRun, 2200)
                    poke()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) { moved = true; h.removeCallbacks(closeRun) }
                    if (moved) {
                        val nx = (ox + dx).toInt()
                        ch.nudge((nx - lp.x).toFloat())
                        lp.x = nx
                        lp.y = (oy + dy).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(closeRun)
                    if (moved) {
                        snap()
                    } else {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastTap < 320) {
                            h.removeCallbacks(singleTapRun)
                            lastTap = 0
                            onDoubleTap()
                        } else {
                            lastTap = now
                            h.postDelayed(singleTapRun, 320)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> { h.removeCallbacks(closeRun); true }
                else -> false
            }
        }
        wm.addView(root, lp)
        h.postDelayed(watchRun, 4000)
        h.postDelayed(idleRun, 80000)
    }

    private fun applyChar() {
        val files = CharStore.list(this)
        if (files.isEmpty()) {
            ch.setImage(null, 0)
            ch.style = 0
        } else {
            val idx = Prefs.geti(this, "char").coerceIn(0, files.size - 1)
            ch.setImage(CharStore.load(files[idx]), Prefs.geti(this, "frame"))
        }
        val scale = floatArrayOf(0.8f, 1f, 1.25f)[Prefs.geti(this, "csize", 1).coerceIn(0, 2)]
        val sz = ch.sizeFor(dens, scale)
        ch.layoutParams = LinearLayout.LayoutParams(sz[0], sz[1])
        ch.requestLayout()
        if (::lp.isInitialized) try { wm.updateViewLayout(root, lp) } catch (e: Exception) {}
    }

    private fun snap() {
        val sw = resources.displayMetrics.widthPixels
        val vw = root.width
        val margin = (4 * dens).toInt()
        val target = if (lp.x + vw / 2 < sw / 2) margin else sw - vw - margin
        val a = ValueAnimator.ofInt(lp.x, target)
        a.duration = 260
        a.addUpdateListener {
            val nx = it.animatedValue as Int
            ch.nudge((nx - lp.x).toFloat())
            lp.x = nx
            try { wm.updateViewLayout(root, lp) } catch (e: Exception) {}
        }
        a.start()
    }

    private fun poke() {
        ch.sleeping = false
        h.removeCallbacks(sleepRun)
        h.postDelayed(sleepRun, 60000)
    }

    private fun show(t: String, ms: Long = 0) {
        bubble.text = t
        bubble.visibility = View.VISIBLE
        h.removeCallbacks(hideBubble)
        if (ms > 0) h.postDelayed(hideBubble, ms)
    }

    private fun say(r: Reply) {
        ch.mood = r.mood
        if (r.mood == "happy" || r.mood == "excited" || r.mood == "love" || r.mood == "surprised") ch.hop()
        val n = r.note
        val shown = if (n != null) n + "\n\n" + r.text else r.text
        show(shown, maxOf(5000L, shown.length * 80L))
        voice?.speak(r.text, r.mood)
        h.removeCallbacks(calmRun)
        h.postDelayed(calmRun, maxOf(6000L, r.text.length * 90L + 3000L))
        poke()
    }

    private fun greet() {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val nm = Memory.name(this)
        val who = if (nm != null) " $nm" else ""
        val line = when {
            hr in 5..11 -> listOf("Good morning$who! Aaj ka din shandaar hone wala hai.", "Suprabhat$who! Chai pi li ya nahi?")
            hr in 12..16 -> listOf("Namaste$who! Din kaisa ja raha hai?", "Hello$who! Lunch ho gaya?")
            hr in 17..20 -> listOf("Shubh sandhya$who! Thak gaye ho? Mujhse baat karo.", "Hey$who! Shaam ho gayi, kuch mazedar karein?")
            else -> listOf("Itni raat ko jaag rahe ho$who? Main hoon na!", "Raat ho gayi hai, par main tumhare saath hoon$who.")
        }.random()
        ch.waving = true
        say(Reply(line, "happy"))
        h.postDelayed({ if (built) ch.waving = false }, 3500)
    }

    private fun idleTick() {
        if (!built || busy || ch.speaking || ch.sleeping || Prefs.get(this, "idle", "1") != "1") return
        if (Random.nextInt(3) == 0) {
            ch.mood = listOf("wink", "happy", "thinking", "shy").random()
            ch.hop()
            h.removeCallbacks(calmRun)
            h.postDelayed(calmRun, 4000)
        } else {
            say(OfflineBrain.idleLine(this))
        }
    }

    private fun onTap() {
        poke()
        if (ch.speaking) { voice?.stop(); return }
        listen()
    }

    private fun onDoubleTap() {
        val wasSleeping = ch.sleeping
        poke()
        if (wasSleeping) say(Reply("Aaah... main so rahi thi! Kya hua?", "surprised"))
        else say(OfflineBrain.pet(this))
    }

    private fun listen() {
        if (busy) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            show("Pehle app khol kar mic permission do.", 4000); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("Is phone me speech recognition available nahi hai.", 4000); return
        }
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p0: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p0: Float) {}
            override fun onBufferReceived(p0: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p0: Bundle?) {}
            override fun onEvent(p0: Int, p1: Bundle?) {}
            override fun onError(code: Int) {
                ch.listening = false
                val msg = when (code) {
                    7 -> "Samajh nahi aaya, dobara tap karke bolo."
                    6 -> "Kuch sunai nahi diya. Tap karke jaldi bolo."
                    9 -> "Mic permission nahi hai."
                    8 -> "Mic busy hai, ek second ruko."
                    else -> "Mic error ($code). Dobara try karo."
                }
                show(msg, 3500)
            }
            override fun onResults(b: Bundle?) {
                ch.listening = false
                val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) show("Kuch sunai nahi diya.", 3000) else think(text)
            }
        })
        rec?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(this, "lang", "hi-IN")))
        ch.mood = "neutral"
        ch.listening = true
        show("Sun rahi hoon...")
    }

    private fun think(text: String) {
        busy = true
        ch.mood = "thinking"
        show("Hmm...")
        Thread {
            val reply = Brain.ask(this, text)
            h.post { busy = false; say(reply) }
        }.start()
    }

    private fun watchApps() {
        if (!built || Prefs.get(this, "appdetect", "0") != "1" || !Util.hasUsage(this)) return
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 20000, now) ?: return
        val e = UsageEvents.Event()
        var pkg = ""
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == 1) pkg = e.packageName
        }
        if (pkg.isEmpty() || pkg == lastPkg) return
        lastPkg = pkg
        if (pkg == packageName || busy || ch.speaking) return
        if (now - lastReact < 40000) return
        val line = OfflineBrain.forApp(this, pkg) ?: return
        lastReact = now
        poke()
        say(line)
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        if (built) try { wm.removeView(root) } catch (e: Exception) {}
        rec?.destroy()
        voice?.shutdown()
        super.onDestroy()
    }
}
