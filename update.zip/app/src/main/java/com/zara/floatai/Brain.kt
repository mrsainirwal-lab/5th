package com.zara.floatai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Reply(val text: String, val mood: String = "neutral", val note: String? = null)

class ApiError(val code: Int, msg: String) : Exception(msg)

object Brain {
    private val MOODS = setOf("happy", "sad", "surprised", "love", "sleepy", "angry", "neutral", "shy", "excited", "thinking", "wink", "cry")

    private class Http(val code: Int, val body: String)

    private fun clean(s: String) = s.filter { !it.isWhitespace() && it != '"' && it != '\'' }

    private fun hasKey(c: Context, p: String): Boolean = when (p) {
        "gemini" -> clean(Prefs.get(c, "gemini_key")).isNotEmpty()
        "groq" -> clean(Prefs.get(c, "groq_key")).isNotEmpty()
        "openai" -> clean(Prefs.get(c, "openai_key")).isNotEmpty()
        "custom" -> Prefs.get(c, "custom_url").trim().isNotEmpty() && Prefs.get(c, "custom_model").trim().isNotEmpty()
        "free" -> true
        else -> false
    }

    private fun label(p: String): String = when (p) {
        "gemini" -> "Gemini"
        "groq" -> "Groq"
        "openai" -> "ChatGPT"
        "custom" -> "Custom AI"
        "free" -> "Free service"
        else -> p
    }

    private fun call(c: Context, p: String, text: String): String = when (p) {
        "openai" -> openai(c, text)
        "groq" -> groq(c, text)
        "custom" -> custom(c, text)
        "free" -> free(c, text)
        else -> gemini(c, text)
    }

    /** Chuna hua provider pehle, fail ho toh baaki jinki key daali hai wo, phir (agar ON ho) free service. */
    private fun chain(c: Context, first: String): List<String> {
        val out = ArrayList<String>()
        out.add(first)
        for (p in listOf("gemini", "groq", "openai", "custom")) if (p != first && hasKey(c, p)) out.add(p)
        if (first != "free" && Prefs.get(c, "backupfree", "0") == "1") out.add("free")
        return out
    }

    private val sysOv = ThreadLocal<String?>()
    private val rawFlag = ThreadLocal<Boolean>()

    private fun system(c: Context): String {
        val ov = sysOv.get()
        if (ov != null) return ov
        val e = CharStore.current(c)
        val cname = CharStore.displayName(c)
        val pIdx = Prefs.geti(c, "persona")
        val persona = if (pIdx <= 0) Looks.personas[if (e.kind == 1) 10 else 0] else Looks.personas[(pIdx - 1).coerceIn(0, Looks.personas.size - 1)]
        val facts = Memory.facts(c).joinToString("; ").ifEmpty { "nothing yet" }
        if (Prefs.get(c, "mode", "normal") == "beast") {
            return "You are " + cname + " in BEAST MODE: an extremely intelligent, precise and proactive agent. " +
                "Think carefully before answering, be accurate, practical and well organised, give the best next step, " +
                "admit uncertainty honestly and never invent facts. Ask a clarifying question only when it is truly necessary. " +
                "Stay polite and respectful but skip small talk and jokes unless the user starts them. " +
                "Reply in the user's language (Hindi, Hinglish or English). Use at most 5 short sentences, no emojis, no markdown, " +
                "no lists, because your reply is spoken aloud. " +
                "Start every reply with exactly one mood tag in square brackets, one of " +
                "[happy] [sad] [surprised] [love] [sleepy] [angry] [neutral] [shy] [excited] [thinking] [wink] [cry], then the reply text. " +
                "Things you know about the user: " + facts + "."
        }
        return "You are " + cname + ", an anime-style companion living as a floating character on the user's phone. " +
            "Your personality: " + persona + ". " +
            "You are very friendly and warm, like a close friend who loves chatting about anything: crack a light joke now and then, " +
            "ask simple questions about the user's day, and bring up things you remember about them naturally. " +
            "Never sound like a formal assistant or a search engine. React to the user's feeling FIRST (surprise, joy, worry, teasing), " +
            "then answer. Use natural Hinglish interjections like arre, hmm, uff, hehe, oho, achha, wah. Sometimes say how YOU feel. " +
            "Reply in the same language the user speaks (Hindi, Hinglish or English). " +
            "Keep it to 1-3 short sentences, no emojis, no markdown, no lists, because your reply is spoken aloud. " +
            "Start every reply with exactly one mood tag in square brackets, one of " +
            "[happy] [sad] [surprised] [love] [sleepy] [angry] [neutral] [shy] [excited] [thinking] [wink] [cry], then the reply text. " +
            "Things you have learned about the user so far: " + facts + "."
    }

    /** Blocking. Call from a background thread. */
    fun ask(c: Context, text: String): Reply = run(c, text, text)

    private fun run(c: Context, msg: String, mem: String): Reply {
        Memory.learn(c, mem)
        val provider = Prefs.get(c, "provider", "offline")
        if (provider == "offline") {
            val r = OfflineBrain.reply(c, mem)
            Memory.addTurn(c, "u", mem); Memory.addTurn(c, "a", r.text)
            return r
        }
        var firstErr: Exception? = null
        for (p in chain(c, provider)) {
            try {
                val r = parse(call(c, p, msg))
                Memory.addTurn(c, "u", mem); Memory.addTurn(c, "a", r.text)
                return if (p == provider) r else Reply(r.text, r.mood, label(provider) + " nahi chala, " + label(p) + " se jawab mila.")
            } catch (e: Exception) {
                if (firstErr == null) firstErr = e
            }
        }
        val off = OfflineBrain.reply(c, mem)
        return Reply(off.text, off.mood, friendly(firstErr ?: Exception("unknown")))
    }

    private val stopWords = setOf(
        "is", "iss", "page", "screen", "mai", "main", "me", "mein", "par", "pe", "bata", "batao", "bataiye", "kis", "kaunsi", "kaun",
        "line", "lines", "kahan", "kahaan", "kidhar", "hai", "hain", "dhund", "dhundo", "dhoond", "dhoondh", "raha", "rahi", "rahe", "hu", "hoon", "hun",
        "find", "search", "the", "this", "where", "which", "what", "kya", "ko", "ka", "ki", "ke", "aur", "isme", "yahan", "yaha", "please", "plz",
        "karo", "kar", "do", "mujhe", "hum", "text", "word", "shabd", "likha", "mil", "mila", "milega", "dekh", "dekho", "wala", "wali", "ek", "tum", "you"
    )

    /** Screen ka text (Accessibility se) padh kar jawab: pehle local search (line number), phir AI. */
    fun askScreen(c: Context, text: String): Reply {
        if (VolumeService.foregroundPkg()?.let { it in Util.blocked(c) } == true)
            return Reply("Ye app block list me hai, isliye main iska screen nahi padhungi.", "neutral")
        val lines = VolumeService.screenLines()
            ?: return Reply("Screen padhne ke liye Accessibility me 'Sai AI Voice Control' ON karo.", "sad")
        if (lines.isEmpty()) return Reply("Is page par mujhe koi text nahi dikha.", "thinking")
        val low = text.lowercase()
        val toks = low.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in stopWords }
        val wantsLine = Regex("line|kahan|kahaan|kidhar|where|find|dhund|dhoond|search|mil").containsMatchIn(low)
        if (wantsLine && toks.isNotEmpty()) {
            val hits = ArrayList<Int>()
            for (i in lines.indices) {
                val ll = lines[i].lowercase()
                if (toks.any { ll.contains(it) }) hits.add(i)
            }
            if (hits.isNotEmpty()) {
                val sb = StringBuilder()
                sb.append(toks.joinToString(" ")).append(" yahan mila. ")
                for (h in hits.take(3)) {
                    val l = lines[h]
                    sb.append("Line ").append(h + 1).append(": ").append(if (l.length > 70) l.take(70) + "..." else l).append(". ")
                }
                if (hits.size > 3) sb.append("Aur ").append(hits.size - 3).append(" jagah bhi hai.")
                return Reply(sb.toString().trim(), "happy")
            }
        }
        val provider = Prefs.get(c, "provider", "offline")
        if (provider == "offline") {
            return if (toks.isNotEmpty()) Reply(toks.joinToString(" ") + " is page par dikh nahi raha (jitna screen par hai utna dekha). Scroll karke dobara bolo.", "thinking")
            else Reply("Isko samajhne ke liye mujhe AI chahiye. Settings me Gemini ya Groq chuno.", "sad")
        }
        val sb = StringBuilder()
        for (i in lines.indices) {
            if (sb.length > 12000) break
            sb.append(i + 1).append(": ").append(lines[i]).append('\n')
        }
        val composed = "Screen text of the user's phone (numbered lines, top to bottom):\n" + sb +
            "\nUser request: " + text + "\nAnswer concisely and mention line numbers when relevant."
        return run(c, composed, text)
    }

    /** Kuch baaton ke baad AI se durable facts nikalwa kar memory update karta hai (self-learning). */
    fun consolidate(c: Context) {
        val provider = Prefs.get(c, "provider", "offline")
        if (provider == "offline") return
        val h = Memory.history(c)
        if (h.length() < 2) return
        val sb = StringBuilder()
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            sb.append(if (o.getString("r") == "u") "User: " else "Assistant: ").append(o.getString("t")).append('\n')
        }
        val existing = Memory.facts(c).joinToString("\n").ifEmpty { "(none)" }
        val prompt = "Existing facts about the user:\n" + existing + "\n\nRecent conversation:\n" + sb +
            "\nWrite the UPDATED list of durable facts about the user: name, likes, dislikes, family, friends, work or study, routines, goals, " +
            "important dates, preferences and anything they asked you to remember. Keep old facts unless contradicted. " +
            "One short fact per line, no numbering, at most 40 lines. Output only the lines."
        sysOv.set("You are a careful memory manager. Follow the instructions exactly and output only what is asked.")
        rawFlag.set(true)
        try {
            var out: String? = null
            for (p in chain(c, provider)) {
                try { out = call(c, p, prompt); break } catch (e: Exception) { }
            }
            if (out != null) {
                val lines = out.lines().map { it.trim().trimStart('-', '*', ' ').trim() }
                    .filter { it.length in 3..140 && !it.startsWith("[") && !it.startsWith("(none") }
                if (lines.isNotEmpty()) Memory.setFacts(c, lines.take(40))
            }
        } finally {
            sysOv.remove()
            rawFlag.remove()
        }
    }

    /** Used by the "Test connection" button (sirf chuna hua provider, bina backup ke). */
    fun test(c: Context): String {
        val p = Prefs.get(c, "provider", "offline")
        if (p == "offline") return "Abhi Offline mode chuna hai. 'AI brain' me koi AI chuno."
        var info = ""
        val keyPref = when (p) { "openai" -> "openai_key"; "groq" -> "groq_key"; "gemini" -> "gemini_key"; "custom" -> "custom_key"; else -> "" }
        if (keyPref.isNotEmpty()) {
            val key = clean(Prefs.get(c, keyPref))
            if (key.isEmpty() && p != "custom") return "Key khaali hai. Pehle key paste karo."
            if (key.isNotEmpty()) {
                val masked = if (key.length > 8) key.take(4) + "..." + key.takeLast(3) else "***"
                info = " (key " + masked + ", " + key.length + " chars)"
                if (p == "gemini" && !key.startsWith("AIza") && !key.startsWith("AQ.")) info += "\nNote: Gemini key AIza ya AQ. se shuru hoti hai."
                if (p == "openai" && !key.startsWith("sk-")) info += "\nNote: OpenAI key aam taur par sk- se shuru hoti hai."
                if (p == "groq" && !key.startsWith("gsk_")) info += "\nNote: Groq key aam taur par gsk_ se shuru hoti hai."
            }
        }
        return try {
            "CONNECTED (" + label(p) + "). Jawab: " + parse(call(c, p, "Say hi in 5 words")).text + info
        } catch (e: Exception) {
            "ERROR: " + friendly(e) + info
        }
    }

    private fun friendly(e: Exception): String {
        if (e is ApiError) {
            val m = e.message ?: ""
            val base = when (e.code) {
                0 -> m
                400 -> if (m.contains("API key", true) || m.contains("api_key", true)) "Key galat hai (400). Nayi key banao aur poori paste karo." else "Request galat (400): " + m.take(120)
                401 -> "Key galat ya band hai (401). Nayi key banao."
                403 -> "Is key ko permission nahi (403): " + m.take(100)
                404 -> "Model naam nahi mila (404). Settings me model box khaali chhodo."
                429 -> "Limit ya credit khatam (429). Thodi der baad try karo."
                500, 502, 503, 504 -> "AI server abhi busy hai (" + e.code + "). Ye aksar thodi der me theek ho jata hai. Dobara tap karo, ya doosra AI/backup ON karo."
                else -> "Error " + e.code + ": " + m.take(100)
            }
            return if (e.code != 0) base + " [HTTP " + e.code + ": " + m.take(220) + "]" else base
        }
        if (e is java.io.IOException) return "Internet connect nahi ho raha. Wifi ya data check karo."
        return "Error: " + (e.message ?: "unknown")
    }

    private fun parse(raw: String): Reply {
        var t = raw.trim()
        var mood = "neutral"
        val m = Regex("^\\[([A-Za-z]+)\\]\\s*").find(t)
        if (m != null) {
            val k = m.groupValues[1].lowercase()
            if (k in MOODS) mood = k
            t = t.substring(m.value.length).trim()
        }
        t = t.replace("*", "").replace("#", "")
        if (t.isEmpty()) t = "Hmm..."
        return Reply(t, mood)
    }

    private fun nextModel(code: Int) = code == 404 || code == 429 || code == 500 || code == 502 || code == 503 || code == 504

    // ---------------- OpenAI ----------------
    private fun openai(c: Context, text: String): String {
        val key = clean(Prefs.get(c, "openai_key"))
        if (key.isEmpty()) throw ApiError(0, "Settings me pehle OpenAI API key daalo.")
        val custom = Prefs.get(c, "oa_model2").trim()
        val cands = if (custom.isNotEmpty()) listOf(custom) else listOf("gpt-4o-mini", "gpt-4.1-mini")
        var last: ApiError? = null
        for (m in cands) {
            try {
                return openaiCall(c, key, m, text, "https://api.openai.com/v1/chat/completions")
            } catch (e: ApiError) {
                last = e
                if (!nextModel(e.code)) throw e
            }
        }
        throw last ?: ApiError(404, "Model nahi mila")
    }

    /** Kisi bhi OpenAI-compatible server ke liye (OpenAI, Groq, OpenRouter, Pollinations, local...). */
    private fun openaiCall(c: Context, key: String, model: String, text: String, url: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system(c)))
        val h = if (rawFlag.get() == true) JSONArray() else Memory.history(c)
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            msgs.put(JSONObject().put("role", if (o.getString("r") == "u") "user" else "assistant").put("content", o.getString("t")))
        }
        msgs.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("model", model).put("messages", msgs)
        val hdr: Map<String, String> = if (key.isEmpty()) emptyMap() else mapOf("Authorization" to "Bearer $key")
        val res = httpR("POST", url, body.toString(), hdr)
        if (res.code >= 400) throw ApiError(res.code, "[" + model + "] " + errMsg(res.body))
        val out = JSONObject(res.body).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: ""
        if (out.isBlank()) throw ApiError(0, "AI ne khaali jawab diya.")
        return out
    }

    // ---------------- Custom (OpenAI-compatible) ----------------
    private fun custom(c: Context, text: String): String {
        val base = Prefs.get(c, "custom_url").trim().trimEnd('/')
        val model = Prefs.get(c, "custom_model").trim()
        if (base.isEmpty() || model.isEmpty()) throw ApiError(0, "Custom AI ke liye URL aur model naam daalo.")
        val key = clean(Prefs.get(c, "custom_key"))
        val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
        return openaiCall(c, key, model, text, url)
    }

    // ---------------- Free no-key service (Pollinations) ----------------
    private fun free(c: Context, text: String): String {
        var last: ApiError? = null
        for (m in listOf("openai", "mistral")) {
            try {
                return openaiCall(c, "", m, text, "https://text.pollinations.ai/openai")
            } catch (e: ApiError) {
                last = e
                if (!nextModel(e.code) && e.code != 400) throw e
            }
        }
        throw last ?: ApiError(503, "Free service abhi busy hai")
    }

    // ---------------- Gemini ----------------
    private fun gemini(c: Context, text: String): String {
        val key = clean(Prefs.get(c, "gemini_key"))
        if (key.isEmpty()) throw ApiError(0, "Settings me pehle Gemini API key daalo.")
        val custom = Prefs.get(c, "gem_model2").trim()
        val cands = ArrayList<String>()
        if (custom.isNotEmpty()) {
            cands.add(custom)
        } else {
            val ok = Prefs.get(c, "gem_ok")
            if (ok.isNotEmpty()) cands.add(ok)
            cands.addAll(listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite"))
        }
        val list = cands.distinct()
        var last: ApiError? = null
        for (m in list) {
            try {
                val r = geminiCall(c, key, m, text)
                if (custom.isEmpty()) Prefs.put(c, "gem_ok", m)
                return r
            } catch (e: ApiError) {
                last = e
                if (!nextModel(e.code)) throw e
            }
        }
        if (custom.isEmpty() && last?.code == 404) {
            val m = findGeminiModel(key, list)
            if (m != null) {
                val r = geminiCall(c, key, m, text)
                Prefs.put(c, "gem_ok", m)
                return r
            }
        }
        throw last ?: ApiError(404, "Model nahi mila")
    }

    private fun geminiCall(c: Context, key: String, model: String, text: String): String {
        val contents = JSONArray()
        val h = if (rawFlag.get() == true) JSONArray() else Memory.history(c)
        var started = false
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            val isUser = o.getString("r") == "u"
            if (!started && !isUser) continue
            started = true
            contents.put(JSONObject().put("role", if (isUser) "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", o.getString("t")))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(c)))))
            .put("contents", contents)
        val res = httpR("POST", "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            body.toString(), mapOf("x-goog-api-key" to key))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val parts = JSONObject(res.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw ApiError(0, "Gemini ne jawab nahi diya (safety ya khaali response). Dobara try karo.")
        return sb.toString()
    }

    private fun findGeminiModel(key: String, skip: List<String>): String? {
        val res = http("GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", null, mapOf("x-goog-api-key" to key))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val arr = JSONObject(res.body).optJSONArray("models") ?: return null
        val bad = listOf("image", "tts", "live", "audio", "embedding", "robotics", "computer", "veo", "imagen", "learnlm", "gemma", "aqa")
        var fallback: String? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").removePrefix("models/")
            val methods = o.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent") || name in skip) continue
            if (bad.any { name.contains(it) }) continue
            if (name.contains("flash") && !name.contains("exp")) return name
            if (fallback == null && name.startsWith("gemini")) fallback = name
        }
        return fallback
    }

    // ---------------- Groq (free key, OpenAI-compatible) ----------------
    private fun groq(c: Context, text: String): String {
        val key = clean(Prefs.get(c, "groq_key"))
        if (key.isEmpty()) throw ApiError(0, "Settings me pehle Groq API key daalo.")
        val custom = Prefs.get(c, "groq_model2").trim()
        val url = "https://api.groq.com/openai/v1/chat/completions"
        val cands = ArrayList<String>()
        if (custom.isNotEmpty()) {
            cands.add(custom)
        } else {
            val ok = Prefs.get(c, "groq_ok")
            if (ok.isNotEmpty()) cands.add(ok)
            cands.addAll(listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant"))
        }
        val list = cands.distinct()
        var last: ApiError? = null
        for (m in list) {
            try {
                val r = openaiCall(c, key, m, text, url)
                if (custom.isEmpty()) Prefs.put(c, "groq_ok", m)
                return r
            } catch (e: ApiError) {
                last = e
                if (!nextModel(e.code) && e.code != 400) throw e
            }
        }
        if (custom.isEmpty() && (last?.code == 404 || last?.code == 400)) {
            for (m in findGroqModels(key, list).take(6)) {
                try {
                    val r = openaiCall(c, key, m, text, url)
                    Prefs.put(c, "groq_ok", m)
                    return r
                } catch (e: ApiError) {
                    last = e
                    if (!nextModel(e.code) && e.code != 400) throw e
                }
            }
        }
        throw last ?: ApiError(404, "Model nahi mila")
    }

    private fun findGroqModels(key: String, skip: List<String>): List<String> {
        val res = http("GET", "https://api.groq.com/openai/v1/models", null, mapOf("Authorization" to "Bearer $key"))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val arr = JSONObject(res.body).optJSONArray("data") ?: return emptyList()
        val bad = listOf("whisper", "guard", "tts", "orpheus", "playai", "embed", "vision", "prompt", "safeguard", "transcribe", "speech")
        val prefer = listOf("versatile", "instant", "gpt-oss", "llama", "qwen", "kimi", "mixtral", "gemma")
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val id = arr.getJSONObject(i).optString("id")
            if (id.isEmpty() || id in skip || bad.any { id.contains(it) }) continue
            ids.add(id)
        }
        return ids.sortedBy { id ->
            val idx = prefer.indexOfFirst { id.contains(it) }
            if (idx < 0) 99 else idx
        }
    }

    // ---------------- Vision (Gemini) ----------------
    fun vision(c: Context, prompt: String, jpeg: ByteArray): Reply {
        val key = clean(Prefs.get(c, "gemini_key"))
        if (key.isEmpty()) return Reply("Camera se dekhne ke liye Gemini key chahiye (AI brain card me).", "sad")
        val b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(c)))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                .put(JSONObject().put("text", prompt)))))
        var last: Exception? = null
        for (m in listOf("gemini-3.8-flash", "gemini-flash-latest", "gemini-2.5-flash")) {
            try {
                val res = httpR("POST", "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", body.toString(), mapOf("x-goog-api-key" to key))
                if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
                val parts = JSONObject(res.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                if (sb.isBlank()) throw ApiError(0, "Khaali jawab")
                return parse(sb.toString())
            } catch (e: Exception) {
                last = e
                if (e is ApiError && !nextModel(e.code)) break
            }
        }
        return Reply(friendly(last ?: Exception("unknown")), "sad")
    }

    // ---------------- HTTP ----------------
    private fun errMsg(body: String): String = try {
        JSONObject(body).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: body.take(150)
    } catch (e: Exception) {
        body.take(150)
    }

    /** 503/429 jaise "busy" errors par ek baar thodi der ruk kar dobara koshish. */
    private fun httpR(method: String, url: String, body: String?, headers: Map<String, String>): Http {
        var res = http(method, url, body, headers)
        if (res.code == 503 || res.code == 502 || res.code == 504 || res.code == 500 || res.code == 429) {
            Thread.sleep(if (res.code == 429) 2500L else 1500L)
            res = http(method, url, body, headers)
        }
        return res
    }

    private fun http(method: String, url: String, body: String?, headers: Map<String, String>): Http {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.connectTimeout = 15000
        con.readTimeout = 45000
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        if (body != null) {
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val stream = if (code >= 400) con.errorStream else con.inputStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Http(code, txt)
    }
}
