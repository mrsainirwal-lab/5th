package com.zara.floatai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Reply(val text: String, val mood: String = "neutral", val note: String? = null)

class ApiError(val code: Int, msg: String) : Exception(msg)

object Brain {
    private val MOODS = setOf("happy", "sad", "surprised", "love", "sleepy", "angry", "neutral")

    private class Http(val code: Int, val body: String)

    private fun clean(s: String) = s.filter { !it.isWhitespace() && it != '"' && it != '\'' }

    private fun system(c: Context): String {
        val name = Looks.all[Prefs.geti(c, "char").coerceIn(0, 4)].name
        val facts = Memory.facts(c).joinToString("; ").ifEmpty { "nothing yet" }
        return "You are $name, a cute anime-style floating companion on the user's phone. " +
            "Reply in the same language the user speaks (Hindi, Hinglish or English). Be warm, playful and emotionally aware: " +
            "comfort the user if they are sad, celebrate if they are happy. Maximum 2 short sentences, no emojis, no markdown, " +
            "because your reply is spoken aloud. Start every reply with exactly one mood tag in square brackets, one of " +
            "[happy] [sad] [surprised] [love] [sleepy] [angry] [neutral], then the reply text. " +
            "What you have learned about the user so far: $facts."
    }

    /** Blocking. Call from a background thread. */
    fun ask(c: Context, text: String): Reply {
        Memory.learn(c, text)
        val provider = Prefs.get(c, "provider", "offline")
        if (provider == "offline") {
            val r = OfflineBrain.reply(c, text)
            Memory.addTurn(c, "u", text); Memory.addTurn(c, "a", r.text)
            return r
        }
        return try {
            val raw = if (provider == "openai") openai(c, text) else gemini(c, text)
            val r = parse(raw)
            Memory.addTurn(c, "u", text); Memory.addTurn(c, "a", r.text)
            r
        } catch (e: Exception) {
            val off = OfflineBrain.reply(c, text)
            Reply(off.text, off.mood, friendly(e))
        }
    }

    /** Used by the "Test connection" button. Returns a readable result. */
    fun test(c: Context): String {
        val p = Prefs.get(c, "provider", "offline")
        if (p == "offline") return "Abhi Offline mode chuna hai. 'AI brain' me Gemini ya ChatGPT chuno."
        val key = clean(Prefs.get(c, if (p == "openai") "openai_key" else "gemini_key"))
        if (key.isEmpty()) return "Key khaali hai. Pehle key paste karo."
        var hint = ""
        if (p == "gemini" && !key.startsWith("AIza")) hint = "\nNote: Gemini key aam taur par AIza se shuru hoti hai."
        if (p == "openai" && !key.startsWith("sk-")) hint = "\nNote: OpenAI key aam taur par sk- se shuru hoti hai."
        return try {
            val raw = if (p == "openai") openai(c, "Say hi in 5 words") else gemini(c, "Say hi in 5 words")
            "CONNECTED. Jawab: " + parse(raw).text + " (key " + key.length + " chars)" + hint
        } catch (e: Exception) {
            "ERROR: " + friendly(e) + " (key " + key.length + " chars)" + hint
        }
    }

    private fun friendly(e: Exception): String {
        if (e is ApiError) {
            val m = e.message ?: ""
            return when (e.code) {
                0 -> m
                400 -> if (m.contains("API key", true) || m.contains("api_key", true)) "Key galat hai (400). Nayi key banao aur poori paste karo." else "Request galat (400): " + m.take(120)
                401 -> "Key galat ya band hai (401). Nayi key banao."
                403 -> "Is key ko permission nahi (403): " + m.take(100)
                404 -> "Model naam nahi mila (404). Settings me model box khaali chhodo."
                429 -> "Limit ya credit khatam (429). Thodi der baad try karo. " + m.take(80)
                else -> "Error " + e.code + ": " + m.take(100)
            }
        }
        if (e is java.io.IOException) return "Internet connect nahi ho raha. Wifi ya data check karo."
        return "Error: " + (e.message ?: "unknown")
    }

    private fun parse(raw: String): Reply {
        var t = raw.trim()
        var mood = "neutral"
        val m = Regex("^\\[([A-Za-z]+)\\]\\s*").find(t)
        if (m != null) {
            val k = m.groupValues[1].lowercase()
            if (k in MOODS) mood = k
            t = t.substring(m.value.length).trim()
        }
        t = t.replace("*", "").replace("#", "")
        if (t.isEmpty()) t = "Hmm..."
        return Reply(t, mood)
    }

    // ---------------- OpenAI ----------------
    private fun openai(c: Context, text: String): String {
        val key = clean(Prefs.get(c, "openai_key"))
        if (key.isEmpty()) throw ApiError(0, "Settings me pehle OpenAI API key daalo.")
        val custom = Prefs.get(c, "oa_model2").trim()
        val cands = if (custom.isNotEmpty()) listOf(custom) else listOf("gpt-4o-mini", "gpt-4.1-mini")
        var last: ApiError? = null
        for (m in cands) {
            try {
                return openaiCall(c, key, m, text)
            } catch (e: ApiError) {
                last = e
                if (e.code != 404) throw e
            }
        }
        throw last ?: ApiError(404, "Model nahi mila")
    }

    private fun openaiCall(c: Context, key: String, model: String, text: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system(c)))
        val h = Memory.history(c)
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            msgs.put(JSONObject().put("role", if (o.getString("r") == "u") "user" else "assistant").put("content", o.getString("t")))
        }
        msgs.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("model", model).put("messages", msgs)
        val res = http("POST", "https://api.openai.com/v1/chat/completions", body.toString(), mapOf("Authorization" to "Bearer $key"))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val out = JSONObject(res.body).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: ""
        if (out.isBlank()) throw ApiError(0, "OpenAI ne khaali jawab diya.")
        return out
    }

    // ---------------- Gemini ----------------
    private fun gemini(c: Context, text: String): String {
        val key = clean(Prefs.get(c, "gemini_key"))
        if (key.isEmpty()) throw ApiError(0, "Settings me pehle Gemini API key daalo.")
        val custom = Prefs.get(c, "gem_model2").trim()
        val cands = ArrayList<String>()
        if (custom.isNotEmpty()) {
            cands.add(custom)
        } else {
            val ok = Prefs.get(c, "gem_ok")
            if (ok.isNotEmpty()) cands.add(ok)
            cands.addAll(listOf("gemini-2.5-flash", "gemini-flash-latest", "gemini-2.5-flash-lite"))
        }
        val list = cands.distinct()
        var last: ApiError? = null
        for (m in list) {
            try {
                val r = geminiCall(c, key, m, text)
                if (custom.isEmpty()) Prefs.put(c, "gem_ok", m)
                return r
            } catch (e: ApiError) {
                last = e
                if (e.code != 404) throw e
            }
        }
        if (custom.isEmpty()) {
            val m = findGeminiModel(key, list)
            if (m != null) {
                val r = geminiCall(c, key, m, text)
                Prefs.put(c, "gem_ok", m)
                return r
            }
        }
        throw last ?: ApiError(404, "Model nahi mila")
    }

    private fun geminiCall(c: Context, key: String, model: String, text: String): String {
        val contents = JSONArray()
        val h = Memory.history(c)
        var started = false
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            val isUser = o.getString("r") == "u"
            if (!started && !isUser) continue
            started = true
            contents.put(JSONObject().put("role", if (isUser) "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", o.getString("t")))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(c)))))
            .put("contents", contents)
        val res = http("POST", "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            body.toString(), mapOf("x-goog-api-key" to key))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val parts = JSONObject(res.body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw ApiError(0, "Gemini ne jawab nahi diya (safety ya khaali response). Dobara try karo.")
        return sb.toString()
    }

    private fun findGeminiModel(key: String, skip: List<String>): String? {
        val res = http("GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", null, mapOf("x-goog-api-key" to key))
        if (res.code >= 400) throw ApiError(res.code, errMsg(res.body))
        val arr = JSONObject(res.body).optJSONArray("models") ?: return null
        val bad = listOf("image", "tts", "live", "audio", "embedding", "robotics", "computer", "veo", "imagen", "learnlm", "gemma", "aqa")
        var fallback: String? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").removePrefix("models/")
            val methods = o.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
            if (!methods.contains("generateContent") || name in skip) continue
            if (bad.any { name.contains(it) }) continue
            if (name.contains("flash") && !name.contains("exp")) return name
            if (fallback == null && name.startsWith("gemini")) fallback = name
        }
        return fallback
    }

    // ---------------- HTTP ----------------
    private fun errMsg(body: String): String = try {
        JSONObject(body).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: body.take(150)
    } catch (e: Exception) {
        body.take(150)
    }

    private fun http(method: String, url: String, body: String?, headers: Map<String, String>): Http {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.connectTimeout = 15000
        con.readTimeout = 45000
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        if (body != null) {
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val stream = if (code >= 400) con.errorStream else con.inputStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Http(code, txt)
    }
}
