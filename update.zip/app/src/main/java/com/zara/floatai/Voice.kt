package com.zara.floatai

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * Voice library se chuni hui voice: Fish Audio, ElevenLabs, ya phone TTS.
 * Cloud voice fail ho toh apne aap phone voice par wapas.
 */
class Voice(
    private val ctx: Context,
    private val onSpeaking: (Boolean) -> Unit,
    private val onNote: ((String) -> Unit)? = null
) : TextToSpeech.OnInitListener {
    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private var pendingRun: (() -> Unit)? = null
    private var lastId = ""
    private var player: MediaPlayer? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ready = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { h.post { onSpeaking(true) } }
            override fun onDone(id: String?) { if (id == lastId) h.post { onSpeaking(false) } }
            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(id: String?) { h.post { onSpeaking(false) } }
        })
        pendingRun?.invoke()
        pendingRun = null
    }

    fun speak(text: String, mood: String = "neutral", lang: String? = null) {
        val v = VoiceStore.current(ctx)
        val beast = Prefs.get(ctx, "mode", "normal") == "beast"
        val m = if (beast) "beast" else mood
        when (v.provider) {
            "fish" -> cloud("Fish", Prefs.get(ctx, "fish_key").trim(), v.id, text, m, lang) { k, id, t, _ -> Fish.tts(k, id, t) }
            "eleven" -> cloud("ElevenLabs", Prefs.get(ctx, "el_key").trim(), v.id, text, m, lang) { k, id, t, md ->
                Eleven.tts(k, id, Prefs.get(ctx, "el_model").trim(), t, md)
            }
            else -> speakPhone(text, mood, lang, v.pitch, v.rate)
        }
    }

    private fun cloud(label: String, key: String, vid: String, text: String, mood: String, lang: String?,
                      call: (String, String, String, String) -> ByteArray) {
        if (key.isEmpty() || vid.isEmpty()) {
            onNote?.invoke(label + " key daalo (Voice card). Abhi phone voice use ho rahi hai.")
            speakPhone(text, mood, lang, 1.15f, 0.95f)
            return
        }
        Thread {
            try {
                val audio = call(key, vid, text, mood)
                val f = File(ctx.cacheDir, "tts_" + System.nanoTime() + ".mp3")
                f.writeBytes(audio)
                h.post { play(f) }
            } catch (e: Exception) {
                val msg = if (label == "Fish") Fish.friendly(e) else Eleven.friendly(e)
                h.post {
                    onNote?.invoke(label + ": " + msg + " (phone voice use ho rahi hai)")
                    speakPhone(text, mood, lang, 1.15f, 0.95f)
                }
            }
        }.start()
    }

    private fun play(f: File) {
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { onSpeaking(false); try { f.delete() } catch (e: Exception) {} }
            mp.setOnErrorListener { _, _, _ -> onSpeaking(false); true }
            mp.prepare()
            mp.start()
            onSpeaking(true)
        } catch (e: Exception) {
            onSpeaking(false)
        }
    }

    private fun speakPhone(text: String, mood: String, lang: String?, basePitch: Float, baseRate: Float) {
        val e = tts
        if (!ready || e == null) { pendingRun = { speakPhone(text, mood, lang, basePitch, baseRate) }; return }
        val loc = Locale.forLanguageTag(lang ?: Prefs.get(ctx, "lang", "hi-IN"))
        e.language = loc
        val vs = e.voices?.filter { it.locale.language == loc.language && !it.isNetworkConnectionRequired }?.sortedBy { it.name }
        if (!vs.isNullOrEmpty()) e.voice = vs[(VoiceStore.selected(ctx) * 3 + 1) % vs.size]

        var pm = 1f
        var rm = 1f
        when (mood) {
            "happy", "wink" -> { pm = 1.08f; rm = 1.05f }
            "excited" -> { pm = 1.15f; rm = 1.15f }
            "sad", "cry" -> { pm = 0.9f; rm = 0.85f }
            "shy" -> { pm = 1.05f; rm = 0.9f }
            "angry" -> { pm = 0.95f; rm = 1.12f }
            "sleepy" -> { pm = 0.9f; rm = 0.75f }
            "love" -> { pm = 1.05f; rm = 0.92f }
            "surprised" -> { pm = 1.12f; rm = 1.1f }
            "thinking", "beast" -> { pm = 0.98f; rm = 0.92f }
        }
        val parts = text.split(Regex("(?<=[.!?\u0964])\\s+")).filter { it.isNotBlank() }
        if (parts.isEmpty()) return
        lastId = "u" + (parts.size - 1)
        for (i in parts.indices) {
            val jp = 0.97f + Math.random().toFloat() * 0.06f
            val jr = 0.97f + Math.random().toFloat() * 0.06f
            e.setPitch((basePitch * pm * jp).coerceIn(0.5f, 2.0f))
            e.setSpeechRate((baseRate * rm * jr).coerceIn(0.5f, 2.0f))
            e.speak(parts[i], if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u$i")
            if (i < parts.size - 1) e.playSilentUtterance(170, TextToSpeech.QUEUE_ADD, "s$i")
        }
    }

    fun stop() {
        tts?.stop()
        try { player?.release() } catch (e: Exception) {}
        player = null
        onSpeaking(false)
    }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null
        try { player?.release() } catch (e: Exception) {}
        player = null
    }
}
