package com.zara.floatai

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * Maya ki aankhein: phone ka camera khulta hai, photo leti hai, aur Gemini vision use pehchaanta hai.
 * Camera app ka use hota hai, isliye alag camera permission ki zaroorat nahi.
 * Live video detection (har frame) battery aur data dono khata hai, isliye ye "ek photo, ek jawab" tareeka hai.
 */
object Eyes {
    @Volatile var prompt = ""
    @Volatile var onResult: ((Reply) -> Unit)? = null

    fun isVisionQuery(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        if (t.contains("camera kholo") || t.contains("screen") || t.contains(" page") || t.startsWith("page")) return false
        return listOf("camera", "saamne", "samne", "ye kya", "yeh kya", "ye kaun", "yeh kaun", "object", "photo kh").any { t.contains(it) }
    }

    fun ask(c: Context, text: String) {
        prompt = "The user asked: \"" + text + "\". Look at this photo taken from the user's phone camera. " +
            "Name the main objects you can see and what they are used for, in a friendly way, in 1-3 short sentences. " +
            "If something is unclear, say so honestly. Start with the mood tag."
        c.startActivity(Intent(c, EyeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
    }
}

/** Halki si transparent activity: camera khol kar photo leti hai, phir jawab Eyes.onResult se bhejti hai. */
class EyeActivity : Activity() {
    private var uri: Uri? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "saiai_" + System.currentTimeMillis() + ".jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            }
            uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            startActivityForResult(i, 301)
        } catch (e: Exception) {
            done(Reply("Camera nahi khul paaya. Phone ka camera app check karo.", "sad"))
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = uri
        if (req != 301 || res != RESULT_OK || u == null) {
            cleanup()
            done(Reply("Photo nahi li, koi baat nahi.", "neutral"))
            return
        }
        Thread {
            val reply = try {
                val jpeg = prep(u)
                if (jpeg.isEmpty()) Reply("Photo saaf nahi aayi, dobara try karo.", "sad")
                else Brain.vision(this, Eyes.prompt, jpeg)
            } catch (e: Exception) {
                Reply("Photo samajh nahi aayi: " + (e.message ?: ""), "sad")
            }
            cleanup()
            runOnUiThread { done(reply) }
        }.start()
    }

    private fun cleanup() {
        try { uri?.let { contentResolver.delete(it, null, null) } } catch (e: Exception) {}
    }

    private fun done(r: Reply) {
        Eyes.onResult?.invoke(r)
        finish()
    }

    private fun prep(u: Uri): ByteArray {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / s > 900) s *= 2
        val bmp = contentResolver.openInputStream(u)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return ByteArray(0)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return out.toByteArray()
    }
}
