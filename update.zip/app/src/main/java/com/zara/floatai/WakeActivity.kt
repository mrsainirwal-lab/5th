package com.zara.floatai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings

/** Invisible helper: volume combo ke baad Zara ko foreground se start karta hai. */
class WakeActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, FloatingService::class.java).setAction("wake"))
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
