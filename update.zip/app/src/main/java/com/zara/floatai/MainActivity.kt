package com.zara.floatai

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var testVoice: Voice? = null
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(40)) }

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 15f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(18), 0, dp(4))
        }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 12f; setPadding(0, dp(4), 0, dp(4)) }
        fun edit(key: String, hint: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(Prefs.get(this@MainActivity, key, "")); setSingleLine()
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { Prefs.put(this@MainActivity, key, e.toString().trim()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        fun spin(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun group() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun openUrl(u: String) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
            catch (e: Exception) { Toast.makeText(this, "Browser nahi khula", Toast.LENGTH_SHORT).show() }
        }
        fun paste(box: EditText) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
            if (t.isEmpty()) Toast.makeText(this, "Clipboard khaali hai. Pehle key copy karo.", Toast.LENGTH_LONG).show()
            else { box.setText(t); Toast.makeText(this, "Paste ho gaya (" + t.length + " chars)", Toast.LENGTH_SHORT).show() }
        }

        // ---------- Header ----------
        col.addView(TextView(this).apply { text = "Sai AI"; textSize = 26f; setTypeface(null, Typeface.BOLD) })
        col.addView(TextView(this).apply { text = "Made with \u2764 love  |  Director: Discord sai_108"; textSize = 12f })
        col.addView(note("Tap = baat, double tap = pyaar, drag = move, 2 sec dabao = band."))
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)
        col.addView(btn("START floating assistant") { start() })
        col.addView(btn("STOP") { stopService(Intent(this, FloatingService::class.java)) })

        // ---------- Character ----------
        col.addView(label("Character"))
        val preview = CharacterView(this).apply { style = Prefs.geti(this@MainActivity, "char"); mood = "happy" }
        col.addView(spin(Looks.all.map { it.name }, Prefs.geti(this, "char")) {
            Prefs.puti(this, "char", it); preview.style = it
        })
        col.addView(preview, LinearLayout.LayoutParams(dp(120), dp(156)))

        // ---------- Voice ----------
        col.addView(label("Voice / tone"))
        col.addView(spin(Voice.names, Prefs.geti(this, "voice")) { Prefs.puti(this, "voice", it) })
        col.addView(btn("Test voice") {
            if (testVoice == null) testVoice = Voice(this) {}
            testVoice?.speak("Namaste! Main tumhari floating assistant hoon.")
        })

        // ---------- Language ----------
        col.addView(label("Language"))
        val langs = listOf("hi-IN", "en-US", "en-IN")
        col.addView(spin(listOf("Hindi / Hinglish", "English (US)", "English (India)"), langs.indexOf(Prefs.get(this, "lang", "hi-IN")).coerceAtLeast(0)) {
            Prefs.put(this, "lang", langs[it])
        })

        // ---------- AI brain ----------
        col.addView(label("AI brain"))
        val provs = listOf("offline", "gemini", "groq", "openai", "free", "custom")
        val provNames = listOf(
            "Offline (bina internet)", "Gemini (Google) - free key", "Groq - free key",
            "ChatGPT (OpenAI) - paid", "Free no-key service (experimental)", "Custom OpenAI-compatible"
        )
        val groups = HashMap<String, LinearLayout>()
        fun showGroup(p: String) { for ((k, v) in groups) v.visibility = if (k == p) View.VISIBLE else View.GONE }

        col.addView(spin(provNames, provs.indexOf(Prefs.get(this, "provider", "offline")).coerceAtLeast(0)) {
            Prefs.put(this, "provider", provs[it]); showGroup(provs[it])
        })

        val gGem = group()
        gGem.addView(note("Google account se login karke free key banti hai. Key ek lambi line hoti hai jo AIza se shuru hoti hai."))
        gGem.addView(btn("1) Free key banao (Google login)") { openUrl("https://aistudio.google.com/apikey") })
        val gk = edit("gemini_key", "Gemini API key", true)
        gGem.addView(gk)
        gGem.addView(btn("2) Copy ki hui key paste karo") { paste(gk) })
        gGem.addView(edit("gem_model2", "Gemini model (khali = auto)"))
        groups["gemini"] = gGem

        val gGroq = group()
        gGroq.addView(note("Google ya email se login karke free key milti hai (gsk_ se shuru). Gemini busy ho tab bhi kaam aati hai."))
        gGroq.addView(btn("1) Free key banao") { openUrl("https://console.groq.com/keys") })
        val qk = edit("groq_key", "Groq API key", true)
        gGroq.addView(qk)
        gGroq.addView(btn("2) Copy ki hui key paste karo") { paste(qk) })
        gGroq.addView(edit("groq_model2", "Groq model (khali = auto)"))
        groups["groq"] = gGroq

        val gOa = group()
        gOa.addView(note("OpenAI API me pehle credit daalna padta hai (ChatGPT Plus alag cheez hai, usse API nahi chalti)."))
        gOa.addView(btn("1) Key page kholo") { openUrl("https://platform.openai.com/api-keys") })
        val ok = edit("openai_key", "OpenAI API key", true)
        gOa.addView(ok)
        gOa.addView(btn("2) Copy ki hui key paste karo") { paste(ok) })
        gOa.addView(edit("oa_model2", "OpenAI model (khali = auto)"))
        groups["openai"] = gOa

        val gFree = group()
        gFree.addView(note("Bina key, bina login. Ye ek public free service hai, thodi slow ho sakti hai aur kabhi band bhi. Isme tumhari baatein unke server par jaati hain, isliye private baatein mat karo."))
        groups["free"] = gFree

        val gCus = group()
        gCus.addView(note("Koi bhi OpenAI-compatible service: OpenRouter, Together, Mistral, ya apna server. URL, key aur model naam daalo."))
        val cu = edit("custom_url", "Base URL (jaise https://openrouter.ai/api/v1)")
        gCus.addView(cu)
        gCus.addView(btn("OpenRouter ka URL bharo") { cu.setText("https://openrouter.ai/api/v1") })
        val ck = edit("custom_key", "API key (agar chahiye)", true)
        gCus.addView(ck)
        gCus.addView(btn("Copy ki hui key paste karo") { paste(ck) })
        gCus.addView(edit("custom_model", "Model naam"))
        groups["custom"] = gCus

        for (g in groups.values) col.addView(g)
        showGroup(Prefs.get(this, "provider", "offline"))

        col.addView(Switch(this).apply {
            text = "Chuna AI na chale toh free no-key service bhi try karo (chat unke server par jaati hai)"
            textSize = 13f
            isChecked = Prefs.get(this@MainActivity, "backupfree", "0") == "1"
            setOnCheckedChangeListener { _, on -> Prefs.put(this@MainActivity, "backupfree", if (on) "1" else "0") }
        })
        col.addView(note("Backup apne aap: agar tumne ek se zyada AI ki key daali hai, toh ek fail hone par doosra apne aap try hota hai."))

        val result = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)); textSize = 13f }
        col.addView(btn("Test connection (chuna hua AI)") {
            result.text = "Testing..."
            result.setTextColor(0xFF6B7280.toInt())
            Thread {
                val r = Brain.test(this)
                runOnUiThread {
                    result.text = r
                    result.setTextColor(if (r.startsWith("CONNECTED")) 0xFF15803D.toInt() else 0xFFB91C1C.toInt())
                }
            }.start()
        })
        col.addView(result)

        // ---------- Features ----------
        col.addView(label("Features"))
        col.addView(Switch(this).apply {
            text = "App detect: Zara tumhare khule apps par bolegi"
            isChecked = Prefs.get(this@MainActivity, "appdetect", "0") == "1"
            setOnCheckedChangeListener { _, on ->
                Prefs.put(this@MainActivity, "appdetect", if (on) "1" else "0")
                if (on && !Util.hasUsage(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Sai AI ke liye Usage access ON karo", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            }
        })
        col.addView(btn("Usage access settings kholo") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        col.addView(btn("Volume + - wake: Accessibility kholo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(note("Accessibility me 'Zara Volume Wake' ko ON karo. Phir Volume + aur - ek saath dabane par floating character aa jayegi."))

        col.addView(btn("Reset what Zara learned") {
            Memory.clear(this); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show()
        })
        col.addView(note("Tip: bolo \"yaad rakh <baat>\" ya \"my name is ...\". \"sab bhool ja\" se memory clear."))

        col.addView(TextView(this).apply {
            text = "Made with \u2764 love\nDirector: Discord sai_108"
            textSize = 13f
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay permission: " + (if (ov) "OK" else "NAHI") +
            "\nMic permission: " + (if (mic) "OK" else "NAHI") +
            "\nUsage access (app detect): " + (if (Util.hasUsage(this)) "OK" else "band") +
            "\nVolume wake service: " + (if (Util.a11yOn(this)) "ON" else "band")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
            Toast.makeText(this, "Mic permission do, phir START dobara dabao", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" allow karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Sai AI chalu!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { testVoice?.shutdown(); super.onDestroy() }
}
