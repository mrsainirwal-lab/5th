package com.zara.floatai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** ElevenLabs text-to-speech (official API). Key aapko elevenlabs.io par banani hoti hai. */
object Eleven {
    class Err(val code: Int, val status: String, msg: String) : Exception(msg)

    private class Resp(val code: Int, val data: ByteArray)

    private fun request(method: String, url: String, key: String, body: String?): Resp {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.connectTimeout = 15000
        con.readTimeout = 45000
        con.setRequestProperty("xi-api-key", key)
        if (body != null) {
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Accept", "audio/mpeg")
            con.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = con.responseCode
        val data = (if (code >= 400) con.errorStream else con.inputStream)?.readBytes() ?: ByteArray(0)
        return Resp(code, data)
    }

    private fun fail(r: Resp): Err {
        val txt = String(r.data)
        var status = ""
        var msg = txt.take(150)
        try {
            val d = JSONObject(txt).opt("detail")
            if (d is JSONObject) {
                status = d.optString("status")
                msg = d.optString("message", msg)
            } else if (d != null) {
                msg = d.toString().take(150)
            }
        } catch (e: Exception) {
        }
        return Err(r.code, status, msg)
    }

    fun listVoices(key: String): List<Pair<String, String>> {
        if (key.isEmpty()) throw Err(0, "", "Pehle ElevenLabs key daalo.")
        val r = request("GET", "https://api.elevenlabs.io/v1/voices", key, null)
        if (r.code >= 400) throw fail(r)
        val arr = JSONObject(String(r.data)).optJSONArray("voices") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Pair(o.optString("voice_id"), o.optString("name")))
        }
        return out
    }

    /** Returns mp3 bytes. */
    fun tts(key: String, voiceId: String, model: String, text: String, mood: String): ByteArray {
        if (key.isEmpty() || voiceId.isEmpty()) throw Err(0, "", "ElevenLabs key ya voice ID khaali hai.")
        var stability = 0.5
        var style = 0.3
        when (mood) {
            "happy", "excited", "wink", "surprised" -> { stability = 0.35; style = 0.6 }
            "sad", "cry", "sleepy" -> { stability = 0.7; style = 0.2 }
            "shy", "love" -> { stability = 0.55; style = 0.45 }
            "angry" -> { stability = 0.3; style = 0.7 }
            "beast" -> { stability = 0.65; style = 0.15 }
        }
        val models = if (model.isNotEmpty()) listOf(model) else listOf("eleven_flash_v2_5", "eleven_multilingual_v2")
        var last: Err? = null
        for (m in models) {
            val body = JSONObject()
                .put("text", text)
                .put("model_id", m)
                .put("voice_settings", JSONObject().put("stability", stability).put("similarity_boost", 0.75).put("style", style).put("use_speaker_boost", true))
            val r = request("POST", "https://api.elevenlabs.io/v1/text-to-speech/" + voiceId + "?output_format=mp3_44100_128", key, body.toString())
            if (r.code < 400) return r.data
            val e = fail(r)
            last = e
            if (r.code != 400 && r.code != 404 && r.code != 422) throw e
        }
        throw last ?: Err(0, "", "Awaaz nahi bani.")
    }

    fun friendly(e: Exception): String {
        if (e is Err) {
            val low = (e.status + " " + e.message).lowercase()
            return when {
                e.code == 0 -> e.message ?: "Error"
                e.code == 401 -> "ElevenLabs key galat hai (401)."
                low.contains("quota") -> "ElevenLabs ke free characters khatam ho gaye."
                e.code == 402 || low.contains("payment") || low.contains("paid") -> "Ye voice ya feature free plan me nahi chalta. Koi premade voice chuno ya plan upgrade karo."
                e.code == 403 -> "ElevenLabs ne mana kar diya (403): " + (e.message ?: "")
                e.code == 404 -> "Voice ID nahi mili (404). 'Meri voices load karo' se chuno."
                e.code == 422 -> "Request galat (422): " + (e.message ?: "")
                e.code == 429 -> "ElevenLabs par abhi bahut requests hain (429). Thodi der baad."
                else -> "ElevenLabs error " + e.code + ": " + (e.message ?: "")
            }
        }
        if (e is java.io.IOException) return "Internet connect nahi ho raha."
        return "Error: " + (e.message ?: "unknown")
    }
}
