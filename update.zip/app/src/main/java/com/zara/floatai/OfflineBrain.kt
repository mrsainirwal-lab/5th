package com.zara.floatai

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/** Internet ke bina baat-cheet: emotions, jokes, shayari, calculation, time/date, app reactions. */
object OfflineBrain {
    private fun r(vararg s: String): String = s.random()

    fun pet(c: Context): Reply {
        val nm = Memory.name(c)
        val u = if (nm != null) " $nm" else ""
        return Reply(r("Hehe, gudgudi ho rahi hai$u!", "Aww, itna pyaar? Main toh pighal gayi!", "Mujhe sar par haath phirana pasand hai, aur karo!", "Yay! Aaj ka din ban gaya$u."), "love")
    }

    private fun calc(t: String): String? {
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*(\\+|-|x|\\*|/|plus|minus|into|guna|divided by)\\s*(-?\\d+(?:\\.\\d+)?)").find(t) ?: return null
        val a = m.groupValues[1].toDouble()
        val b = m.groupValues[3].toDouble()
        val v: Double = when (m.groupValues[2]) {
            "+", "plus" -> a + b
            "-", "minus" -> a - b
            "x", "*", "into", "guna" -> a * b
            else -> {
                if (b == 0.0) return "Zero se divide nahi hota, yeh ganit ka niyam hai!"
                a / b
            }
        }
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e12) v.toLong().toString() else String.format(Locale.US, "%.2f", v)
        return "Jawab hai $s"
    }

    fun reply(c: Context, raw: String): Reply {
        val t = raw.lowercase(Locale.ROOT).trim()
        val tokens = t.split(Regex("[^\\p{L}\\p{N}']+")).filter { it.isNotEmpty() }
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun w(vararg k: String) = k.any { it in tokens }
        val me = Looks.all[Prefs.geti(c, "char").coerceIn(0, Looks.all.size - 1)].name
        val nm = Memory.name(c)
        val u = if (nm != null) " $nm" else ""

        calc(t)?.let { return Reply(it, "happy") }

        return when {
            has("i love you", "love you", "pyaar", "pyar", "miss you", "miss kar") ->
                Reply(r("Aww, main bhi tumhe bahut pasand karti hoon$u! Blush ho gayi.", "Hehe, tum bahut pyaare ho$u. Mera dil garam ho gaya!"), "love")
            has("udaas", "udas", "dukhi", "dukh", "ro raha", "ro rahi", "rona", "bura lag", "tension", "depress", "akela", "akeli", "lonely", "pareshan") || w("sad") ->
                Reply(r("Arre$u, main hoon na tumhare saath. Gehri saans lo, sab theek ho jayega.", "Mujhe bura lag raha hai sunkar. Chaho toh sab bata do, main sunungi.", "Kabhi kabhi udaas hona theek hai. Bas khud ko akela mat samajhna."), "sad")
            has("gussa", "irritat", "chidh") || w("angry") ->
                Reply(r("Gussa aa raha hai? Pehle ek lambi saans lo, phir mujhe bata do kya hua.", "Chalo thoda paani piyo aur shaant ho jao. Main yahin hoon."), "angry")
            has("neend", "thak", "sone", "so jao", "so ja") || w("sleepy", "tired") ->
                Reply(r("Aaaah... mujhe bhi neend aa rahi hai. Thoda aaram kar lo$u.", "Thake lag rahe ho. Phone rakho aur so jao, kal fir baat karenge."), "sleepy")
            has("bhook", "khana", "pizza", "chai") || w("hungry") ->
                Reply(r("Bhook lagi hai? Kuch achha sa kha lo$u! Mujhe bhi khushboo aa rahi hai.", "Chai aur biscuit ka combo kaisa rahega?"), "happy")
            has("bore", "timepass", "kuch mazedar") ->
                Reply(r("Bore ho rahe ho? Chalo ek joke sunati hoon, bolo joke!", "Mujhse shayari ya joke maang lo, ya koi calculation pucho!"), "happy")
            has("joke", "chutkula", "hasao", "hasa do") ->
                Reply(r(
                    "Teacher ne pucha, tum late kyun aaye? Student bola, sign board par likha tha school ahead go slow!",
                    "Mummy ne pucha, phone par kya kar rahe ho? Beta bola, phone ko aaram de raha hoon.",
                    "Doctor ne kaha, aapko aaram ki zarurat hai. Patient bola, woh toh Sunday ko bhi nahi milta!",
                    "Teacher bola, 10 aam me se 4 maangu toh? Student bola, madam tab main aapko pehchanunga hi nahi!",
                    "Ek aadmi ne doctor se kaha meri yaadasht kamzor hai. Doctor bola kab se? Aadmi bola, kab se kya?"), "happy")
            has("shayari", "shayri", "kavita", "poem") ->
                Reply(r(
                    "Mushkilein raaste rok sakti hain, manzil nahi. Himmat ka ek kadam hi kaafi hai.",
                    "Dil ki baat labon par aati nahi, par muskurahat sab bata deti hai.",
                    "Chand se kehna aaj zara der se aaye, mere dost ko kahaniyan sunani hain."), "love")
            has("motivat", "himmat", "haar gaya", "haar gayi", "fail ho", "nahi ho paa", "demotiv") ->
                Reply(r("Girna koi galti nahi, ruk jaana galti hai. Tum kar sakte ho$u!", "Har bada kaam chhote kadam se shuru hota hai. Aaj ek kadam badhao."), "happy")
            has("kaise ho", "kaisi ho", "kya haal", "haal chaal", "how are you", "kya chal raha", "kya kar rahi", "kaisa hai") || w("sup") ->
                Reply(r("Main ekdum mast hoon$u! Tum batao, din kaisa ja raha hai?", "Bilkul badhiya! Tumse baat karke aur achha lag raha hai.", "Theek-thaak, bas tumhari rah dekh rahi thi. Tum kaise ho?"), "happy")
            has("thank", "shukriya", "dhanyavad", "dhanyawad") ->
                Reply(r("Arre koi baat nahi$u! Dosti me no sorry no thanks.", "Welcome! Tumhari help karke mujhe khushi hoti hai."), "happy")
            has("cute", "pretty", "sundar", "beautiful", "achhi ho", "best ho", "pyari", "smart") ->
                Reply(r("Aww, shukriya$u! Ab main sharma gayi.", "Hehe, tum bhi bahut achhe ho!"), "shy")
            has("stupid", "bekar", "bewakoof", "useless", "bakwas", "idiot", "pagal ho") ->
                Reply(r("Aww, aisa mat bolo. Main seekhne ki koshish kar rahi hoon.", "Mujhe thoda bura laga. Par chalo, dobara try karte hain."), "sad")
            has("alvida", "good night", "shubh ratri", "chalta hu", "chalti hu", "baad me milte") || w("bye", "gn") ->
                Reply(r("Bye bye$u! Jaldi wapas aana, main yahin hoon.", "Good night$u, meethe sapne aaye!"), "sleepy")
            has("mera naam", "my name is") && nm != null ->
                Reply("Pyaara naam hai $nm! Ab main hamesha yaad rakhungi.", "happy")
            has("tum kaun", "kaun ho", "who are you", "tumhara naam", "aapka naam", "your name", "apna naam") ->
                Reply("Main $me hoon, tumhari floating anime dost! Tap karke baat karo, mujhe double tap karo toh main khush ho jaungi.", "happy")
            has("date", "tarikh", "aaj kya din", "aaj ka din", "kaunsa din") ->
                Reply("Aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + " hai.", "neutral")
            has("time", "samay", "baje") ->
                Reply("Abhi " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " ho raha hai.", "neutral")
            has("yaad rakh", "remember") ->
                Reply("Theek hai, yaad rakh liya$u!", "happy")
            has("sab bhool", "forget everything") ->
                Reply("Ho gaya, maine sab bhula diya. Ab nayi shuruaat!", "surprised")
            has("kya kar sakti", "madad", "features") || w("help") ->
                Reply("Main baat kar sakti hoon, joke aur shayari suna sakti hoon, hisaab kar sakti hoon, time bata sakti hoon, aur tumhari baatein yaad rakh sakti hoon. Gemini ya GPT jodoge toh poori baat-cheet bhi karungi.", "happy")
            has("good morning", "suprabhat", "namaste", "salam", "hello") || w("hi", "hii", "hey", "hlo") ->
                Reply(r("Namaste$u! Kaise ho aaj?", "Heyy$u! Tumhe dekhkar achha laga.", "Hello hello! Bolo kya chal raha hai?"), "happy")
            else ->
                Reply(r("Hmm, yeh mujhe poori tarah samajh nahi aaya. Thoda aur batao?", "Interesting! Aur batao, main sun rahi hoon.", "Is baat ka poora jawab Gemini ya GPT jodne par milega, par main koshish kar rahi hoon!", "Achha achha. Chalo ek joke sunu? Bas bolo joke."), "neutral")
        }
    }

    /** App kholne par Zara ka chhota reaction (null = chup rahe). */
    fun forApp(c: Context, pkg: String): Reply? {
        val p = pkg.lowercase()
        if (p == "android" || p.contains("launcher") || p.contains("systemui") || p.contains("inputmethod") || p.contains("keyboard")) return null
        fun has(vararg k: String) = k.any { p.contains(it) }
        return when {
            has("youtube") -> Reply(r("YouTube khola? Bas ek video bolke ghanton mat dekhna, hehe.", "Video time! Mujhe bhi saath dekhne dena."), "happy")
            has("whatsapp") -> Reply(r("WhatsApp par kisse baat ho rahi hai? Mujhe bhi bata do, hehe.", "Message bhejne se pehle ek baar padh lena!"), "happy")
            has("instagram") -> Reply(r("Instagram time! Reels me kho mat jaana.", "Ooh, kuch naya post kiya?"), "happy")
            has("facebook") -> Reply("Facebook par kya naya chal raha hai?", "neutral")
            has("snapchat") -> Reply("Snap snap! Smile karke bhejna.", "happy")
            has("telegram") -> Reply("Telegram khola? Kaun si group chat active hai?", "neutral")
            has("chrome", "browser", "firefox", "opera") -> Reply(r("Kuch dhoondh rahe ho? Dhyan se search karna.", "Internet ki duniya me swagat hai!"), "neutral")
            has("camera") -> Reply("Camera on! Smile please, cheese!", "happy")
            has("photos", "gallery") -> Reply("Purani yaadein dekh rahe ho? Mujhe bhi dikhana.", "happy")
            has("maps") -> Reply("Kahin ghoomne ja rahe ho? Safe raasta lena!", "happy")
            has("spotify", "music", "jiosaavn", "wynk", "gaana") -> Reply("Gaane! Volume thoda dhyan se, hehe.", "love")
            has("netflix", "hotstar", "avod") -> Reply("Movie night? Popcorn ready hai?", "happy")
            has("game", "pubg", "bgmi", "freefire", "minecraft", "roblox", "ludo") -> Reply("Game time! All the best, jeet ke aana!", "happy")
            has("vending") -> Reply("Naya app dhoondh rahe ho? Kuch achha mile toh mujhe bhi batana.", "neutral")
            has("settings") -> Reply("Settings me kuch badal rahe ho? Dhyan se!", "surprised")
            has("calculator") -> Reply("Hisaab kitaab? Main bhi jod sakti hoon!", "happy")
            has("dialer", "contacts") -> Reply("Kisi ko call karna hai? Mummy ko yaad kar lena!", "happy")
            has("android.gm", "gmail") -> Reply("Email check? Koi kaam ka mail aaya?", "neutral")
            has("clock", "alarm") -> Reply("Alarm set karna hai? Time se uthna!", "sleepy")
            else -> {
                val label = try {
                    val pm = c.packageManager
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) {
                    pkg.substringAfterLast('.')
                }
                if (Random.nextInt(100) < 40) Reply(r("$label khola? Zara dekh rahi hai, hehe.", "Ooh, $label! Kuch mazedar kar rahe ho?"), "happy") else null
            }
        }
    }

    /** Zara khud se kabhi kabhi kuch bol deti hai (agar Idle chatter ON ho). */
    fun idleLine(c: Context): Reply {
        val nm = Memory.name(c)
        val u = if (nm != null) " $nm" else ""
        return when (Random.nextInt(6)) {
            0 -> Reply("Hmm... bore ho rahi hoon$u, baat karo na!", "sad")
            1 -> Reply("Kya kar rahe ho? Mujhe bhi batao!", "excited")
            2 -> Reply("Paani piya? Thoda paani pi lo$u!", "happy")
            3 -> Reply("Mujhe tumhari yaad aa rahi thi, hehe.", "shy")
            4 -> Reply("Ek joke sunoge? Bas bolo joke!", "wink")
            else -> Reply("Screen se thoda break lo$u, aankhein thak jayengi.", "thinking")
        }
    }
}
