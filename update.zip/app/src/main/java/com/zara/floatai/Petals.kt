package com.zara.floatai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.sin

/** Cherry blossom petals: spawn karti hain, girte girte halki hoti jaati hain aur gayab ho jaati hain. */
class PetalField(private val max: Int) {
    private val x = FloatArray(max)
    private val y = FloatArray(max)
    private val vx = FloatArray(max)
    private val vy = FloatArray(max)
    private val rot = FloatArray(max)
    private val vr = FloatArray(max)
    private val sz = FloatArray(max)
    private val age = FloatArray(max)
    private val lifeA = FloatArray(max)
    private val alive = BooleanArray(max)
    private val rnd = java.util.Random()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var acc = 0f

    private fun rf(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    fun clear() { for (i in 0 until max) alive[i] = false }

    fun update(dt: Float, rate: Float, x0: Float, x1: Float, y0: Float, y1: Float, h: Float, d: Float, fall: Float, size: Float, lifeS: Float) {
        acc += dt * rate
        while (acc >= 1f) {
            acc -= 1f
            var i = -1
            for (k in 0 until max) if (!alive[k]) { i = k; break }
            if (i < 0) break
            alive[i] = true
            x[i] = rf(x0, x1)
            y[i] = rf(y0, y1)
            vx[i] = rf(-6f, 14f) * d
            vy[i] = rf(0.75f, 1.2f) * fall * d
            rot[i] = rf(0f, 360f)
            vr[i] = rf(-140f, 140f)
            sz[i] = rf(0.8f, 1.2f) * size * d
            age[i] = 0f
            lifeA[i] = rf(0.75f, 1.1f) * lifeS
        }
        for (i in 0 until max) {
            if (!alive[i]) continue
            age[i] += dt
            x[i] += (vx[i] + sin(age[i] * 2.2f + i) * 14f * d) * dt
            y[i] += vy[i] * dt
            rot[i] += vr[i] * dt
            if (age[i] > lifeA[i] || y[i] > h + 10f * d) alive[i] = false
        }
    }

    fun draw(c: Canvas) {
        for (i in 0 until max) {
            if (!alive[i]) continue
            val f = (1f - age[i] / lifeA[i]).coerceIn(0f, 1f)
            val a = (255 * f * 0.9f).toInt()
            val s = sz[i]
            c.save()
            c.translate(x[i], y[i])
            c.rotate(rot[i])
            paint.color = Color.argb(a, 255, 183, 197)
            rect.set(-s, -s * 0.55f, s, s * 0.55f)
            c.drawOval(rect, paint)
            paint.color = Color.argb(a, 255, 140, 170)
            rect.set(-s * 0.3f, -s * 0.2f, s * 0.5f, s * 0.2f)
            c.drawOval(rect, paint)
            c.restore()
        }
    }
}

/** App ke andar background me girti cherry blossom petals (touch ko rokti nahi). */
class PetalView(ctx: Context) : View(ctx) {
    var active = true
        set(v) { field = v; if (!v) field2.clear(); invalidate() }
    private val field2 = PetalField(34)
    private var last = SystemClock.uptimeMillis()

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        var dt = (now - last) / 1000f
        last = now
        if (dt > 0.05f) dt = 0.05f
        if (!active) return
        val d = resources.displayMetrics.density
        field2.update(dt, 3.2f, 0f, width.toFloat(), -12f * d, 0f, height.toFloat(), d, 38f, 6.5f, 14f)
        field2.draw(c)
        postInvalidateOnAnimation()
    }
}
