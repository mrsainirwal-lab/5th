package com.zara.floatai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

class Look(
    val name: String, val hair: Int, val hairShade: Int, val eye: Int,
    val outfit: Int, val outfit2: Int, val skin: Int,
    val kind: Int, val acc: Int, val cloth: Int, val persona: Int
)

/** 50 original anime-style characters, generated from combinations of hair, colors, accessories and outfits. */
object Looks {
    val titles = listOf("Bubbly", "Sharmili", "Tsundere", "Calm Didi", "Hyper", "Shararati", "Dreamy", "Cool", "Pyaari", "Nerdy", "Jarvis (smart + witty)")

    val personas = listOf(
        "bubbly, optimistic and cheerful; says things like 'arre wah' and 'yaay'",
        "shy and soft-spoken, a little stuttery ('u-um...'), blushes easily but is very sweet",
        "a tsundere: acts tough and teasing ('hmph') but secretly cares a lot",
        "a calm, caring elder-sister type who gives gentle advice",
        "super energetic and hyper, loves cheering the user on ('chalo chalo!')",
        "mischievous and playful, loves teasing and little jokes",
        "dreamy and poetic, speaks softly with pretty imagery",
        "cool with dry humor and short sentences, but very loyal",
        "very affectionate, worries about the user and uses their name often",
        "curious and nerdy, asks questions and shares fun facts",
        "a calm, brilliant and witty AI butler like a movie hologram assistant: confident, dry humor, loyal, warm underneath, sometimes calls the user boss"
    )

    private val names = listOf(
        "Mika", "Aoi", "Nyx", "Hikari", "Yuzu", "Sora", "Riko", "Hana", "Kaito", "Ren",
        "Miyu", "Yuna", "Akari", "Haru", "Nana", "Rina", "Kenji", "Tsubasa", "Emi", "Daichi",
        "Noa", "Mei", "Sota", "Ayame", "Koharu", "Rui", "Itsuki", "Chiyo", "Mizuki", "Shiori",
        "Toma", "Hotaru", "Sumire", "Kazuki", "Momo", "Yuki", "Reina", "Ayumi", "Leo", "Lumi",
        "Kiri", "Mari", "Shun", "Airi", "Zen", "Iris", "Luna", "Reo", "Saki", "Tomo"
    )

    private val hairs = listOf(
        0xFF22D3EE to 0xFF0E7490, 0xFF3B82F6 to 0xFF1D4ED8, 0xFF8B5CF6 to 0xFF5B21B6, 0xFFFDE68A to 0xFFF59E0B,
        0xFFFB923C to 0xFFEA580C, 0xFF2B2F55 to 0xFF1B1E3A, 0xFFE5E7EB to 0xFF9CA3AF, 0xFF34D399 to 0xFF047857,
        0xFFF87171 to 0xFFB91C1C, 0xFFA16207 to 0xFF713F12, 0xFFF472B6 to 0xFFBE185D, 0xFFA3E635 to 0xFF4D7C0F
    )
    private val eyes = listOf(
        0xFF8B5CF6, 0xFFFBBF24, 0xFFF43F5E, 0xFF38BDF8, 0xFF14B8A6, 0xFFFB923C, 0xFF3B82F6, 0xFFD946EF, 0xFF0EA5E9
    )
    private val outfits = listOf(
        0xFF1E1B4B to 0xFF22D3EE, 0xFF111827 to 0xFFEF4444, 0xFF18181B to 0xFFA855F7, 0xFFFFFFFF to 0xFFFB7185,
        0xFFFEF3C7 to 0xFFDC2626, 0xFF0F766E to 0xFFFDE047, 0xFF7C2D12 to 0xFFFBBF24, 0xFF1D4ED8 to 0xFFFFFFFF,
        0xFFBE185D to 0xFFFFE4E6, 0xFF334155 to 0xFF38BDF8
    )
    private val skins = listOf(0xFFFFE4D2, 0xFFF8D5B8, 0xFFEBC3A0)

    val all: List<Look> = List(50) { i ->
        val h = hairs[i % 12]
        val o = outfits[(i * 3 + i / 7) % outfits.size]
        Look(
            names[i], h.first.toInt(), h.second.toInt(), eyes[(i * 3 + 1) % eyes.size].toInt(),
            o.first.toInt(), o.second.toInt(), skins[i % 3].toInt(),
            i % 10, (i * 3 + i / 10) % 10, (i / 2) % 5, (i * 7) % 10
        )
    }
}

/**
 * Original anime-style characters drawn in code.
 * Moods: neutral, happy, sad, surprised, love, sleepy, angry, shy, excited, thinking, wink, cry.
 * Hair/accessories sway with a spring physics when the window is dragged (nudge).
 */
class CharacterView(ctx: Context) : View(ctx) {
    var style = 0
        set(v) { field = v.coerceIn(0, Looks.all.size - 1); invalidate() }
    var mood = "neutral"
    var speaking = false
    var listening = false
    var waving = false
    var sleeping = false

    var bitmap: Bitmap? = null
    var orb = false
    var rig = false
    var petalsOn = false
    private val petals = PetalField(26)
    private var frameDt = 0.016f
    private var pSmile = 0f
    private var pSquint = 0f
    private var pWiden = 0f
    private var pRot = 0f
    private var pNod = 0f
    private var pMouth = 0f
    private var pGx = 0f
    private var pGy = 0f
    private var pWave = 0f
    private var rotTotal = 0f
    private var gestName = ""
    private var gestStart = 0L
    private var frameMode = 0
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val meshV = FloatArray(37 * 65 * 2)
    private var fMood = ""
    private var fCache: ColorMatrixColorFilter? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f
    private var physA = 0f
    private var physV = 0f
    private var lastMs = SystemClock.uptimeMillis()
    private var hopStart = 0L
    private val ink = 0xFF3F3F46.toInt()
    private val lip = 0xFFB5334F.toInt()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    /** Window drag ke waqt call karo: dx = window ka horizontal move (px). Hair opposite side me jhoolte hain. */
    fun nudge(dx: Float) { physV = (physV - dx * 3f).coerceIn(-700f, 700f) }
    fun hop() { hopStart = SystemClock.uptimeMillis() }

    private fun fill(col: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = col }
    private fun grad(c1: Int, c2: Int, y0: Float, y1: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, y0, 0f, y1, c1, c2, Shader.TileMode.CLAMP)
    }
    private fun stroke(col: Int, wd: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = wd; p.strokeCap = Paint.Cap.ROUND
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(x, y + s * 0.35f)
        path.cubicTo(x - s, y - s * 0.3f, x - s * 0.5f, y - s * 1.1f, x, y - s * 0.45f)
        path.cubicTo(x + s * 0.5f, y - s * 1.1f, x + s, y - s * 0.3f, x, y + s * 0.35f)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    private fun spark(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(x, y - r)
        path.quadTo(x, y, x + r, y)
        path.quadTo(x, y, x, y + r)
        path.quadTo(x, y, x - r, y)
        path.quadTo(x, y, x, y - r)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val L = Looks.all[style]
        val u = width / 100f
        val cx = width / 2f
        val now = SystemClock.uptimeMillis()
        var dt = (now - lastMs) / 1000f
        lastMs = now
        if (dt > 0.05f) dt = 0.05f
        physV += (-140f * physA - 8f * physV) * dt
        physA = (physA + physV * dt).coerceIn(-40f, 40f)

        val m = if (sleeping) "sleepy" else mood
        frameDt = dt
        if (orb) { drawOrb(c, m, now); return }
        val bmp = bitmap
        if (bmp != null) { drawImage(c, bmp, m, now); return }
        val sway = sin(t * 2 * PI).toFloat()
        var bob = sway * 2.5f * u * (if (m == "sleepy") 0.4f else 1f)
        if (m == "excited") bob -= abs(sin(t * 2 * PI * 2)).toFloat() * 3f * u
        val hp = (now - hopStart) / 700f
        if (hp in 0f..1f) bob -= abs(sin(hp * PI * 2)).toFloat() * 9f * u
        val blink = if (m == "sleepy" || m == "happy" || m == "love" || m == "excited") 1f
            else if (t > 0.93f || (t > 0.45f && t < 0.48f)) 0.1f else 1f
        val mo = if (speaking) abs(sin(t * 2 * PI * 6)).toFloat() else 0f
        val lt = now / 1000f
        val gx = sin(lt * 0.7f) * 1.5f * u
        val gy = sin(lt * 0.5f + 1f) * 0.8f * u

        c.save()
        c.translate(0f, bob)
        if (listening) {
            stroke(0xAAFF4081.toInt(), 2.5f * u)
            c.drawCircle(cx, 48 * u, (33 + 4 * abs(sin(t * 2 * PI * 2)).toFloat()) * u, p)
        }
        c.save()
        c.rotate(physA * 0.5f, cx, 24 * u)
        backHair(c, L, u, cx, sway)
        c.restore()
        body(c, L, u, cx)
        fill(L.skin)
        c.drawCircle(cx, 48 * u, 28 * u, p)
        fill(0x1A7C5A4A.toInt())
        c.drawOval(RectF(cx - 24 * u, 36 * u, cx + 24 * u, 46 * u), p)
        c.save()
        c.translate(-physA * 0.05f * u, 0f)
        frontHair(c, L, u, cx, sway)
        stroke(0x55FFFFFF.toInt(), 2.2f * u)
        c.drawArc(RectF(cx - 22 * u, 16 * u, cx + 4 * u, 34 * u), 200f, 70f, false, p)
        c.restore()
        eyes(c, L, u, cx, m, blink, gx, gy)
        if (L.acc == 9) glasses(c, u, cx)
        brows(c, u, cx, m)
        fill(when (m) { "shy" -> 0xBBFF6B8A.toInt(); "love" -> 0x99FF6B8A.toInt(); else -> 0x55FF6B8A.toInt() })
        c.drawCircle(cx - 18 * u, 62 * u, 4 * u, p)
        c.drawCircle(cx + 18 * u, 62 * u, 4 * u, p)
        mouth(c, u, cx, m, mo)
        extras(c, u, cx, m)
        c.restore()
    }


    // ---------------- image / orb characters ----------------
    fun gesture(n: String) { gestName = n; gestStart = SystemClock.uptimeMillis() }

    /** frame: 0 = rounded card, 1 = circle (face crop), 2 = bina frame. rigOn = Maya ke liye chehre/sar/haath ki animation. */
    fun setImage(b: Bitmap?, frame: Int, rigOn: Boolean = false) {
        frameMode = frame
        orb = false
        rig = rigOn && b != null
        bitmap = if (b != null && frame == 1 && b.height > b.width) Bitmap.createBitmap(b, 0, 0, b.width, b.width) else b
        invalidate()
    }

    fun setOrb() { orb = true; rig = false; bitmap = null; invalidate() }

    fun sizeFor(d: Float, scale: Float): IntArray {
        val extra = if (petalsOn) (64 * d).toInt() else 0
        if (orb) {
            val s = (150 * d * scale).toInt()
            return intArrayOf(s, s + extra)
        }
        val b = bitmap
        if (b == null) return intArrayOf((120 * d * scale).toInt(), (156 * d * scale).toInt() + extra)
        val maxW = 150f * d * scale
        val maxH = 240f * d * scale
        val asp = b.width.toFloat() / b.height
        var w = minOf(maxW, maxH * asp)
        var h = w / asp
        if (h > maxH) { h = maxH; w = h * asp }
        return intArrayOf(w.toInt() + (8 * d).toInt(), h.toInt() + (8 * d).toInt() + extra)
    }

    private fun filterFor(m: String): ColorMatrixColorFilter? {
        if (m == fMood) return fCache
        var sat = 1f
        var br = 0f
        var r = 0f
        when (m) {
            "happy", "wink" -> { sat = 1.08f; br = 4f }
            "excited" -> { sat = 1.2f; br = 6f }
            "love" -> { sat = 1.08f; r = 10f }
            "shy" -> { r = 9f; br = 3f }
            "sad", "cry" -> { sat = 0.65f; br = -10f }
            "angry" -> { sat = 1.08f; r = 20f; br = -5f }
            "sleepy" -> { sat = 0.75f; br = -26f }
        }
        fMood = m
        if (sat == 1f && br == 0f && r == 0f) { fCache = null; return null }
        val cm = ColorMatrix()
        cm.setSaturation(sat)
        cm.postConcat(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, br + r,
            0f, 1f, 0f, 0f, br,
            0f, 0f, 1f, 0f, br,
            0f, 0f, 0f, 1f, 0f
        )))
        fCache = ColorMatrixColorFilter(cm)
        return fCache
    }

    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * k

    private fun gs(x: Float, y: Float, cx: Float, cy: Float, sx: Float, sy: Float): Float {
        val a = (x - cx) / sx
        val b = (y - cy) / sy
        return exp(-0.5f * (a * a + b * b))
    }

    /** Maya (192x340 source px) ke chehre ke features par warp. dx/dy source px me. */
    private var rdx = 0f
    private var rdy = 0f
    private fun rigDisp(x: Float, y: Float, bl: Float, br: Float) {
        var dx = 0f
        var dy = 0f
        var wh = ((118f - y) / 20f).coerceIn(0f, 1f)
        wh = wh * wh * (3f - 2f * wh)
        if (wh > 0f) {
            val th = Math.toRadians(rotTotal.toDouble()).toFloat()
            val rx = x - 83f
            val ry = y - 112f
            val cs = cos(th)
            val sn = sin(th)
            dx += wh * (cs * rx - sn * ry - rx)
            dy += wh * (sn * rx + cs * ry - ry + pNod)
        }
        val wl = gs(x, y, 67f, 77f, 9f, 7.5f)
        val wr = gs(x, y, 92f, 74f, 9f, 7.5f)
        val kl = (bl * 0.92f + pSquint * 0.45f - pWiden * 0.18f)
        val kr = (br * 0.92f + pSquint * 0.45f - pWiden * 0.18f)
        dy += -(y - 77f) * kl * wl - (y - 74f) * kr * wr
        dx += pGx * (wl + wr)
        dy += pGy * (wl + wr)
        val wml = gs(x, y, 78f, 99f, 4f, 3f)
        val wmr = gs(x, y, 87f, 99f, 4f, 3f)
        dy += -pSmile * 2.4f * (wml + wmr)
        dx += abs(pSmile) * 0.7f * (wmr - wml)
        dy += pMouth * 2.8f * gs(x, y, 82.5f, 101f, 4.5f, 3f)
        val wHand = gs(x, y, 62f, 23f, 14f, 14f)
        dx += pWave * 4f * wHand
        dy += pWave * 1.2f * wHand
        val wChest = gs(x, y, 85f, 160f, 40f, 30f)
        dy += sin(t * 2 * PI).toFloat() * 0.8f * wChest
        rdx = dx
        rdy = dy
    }

    private fun updateRig(m: String, now: Long, mo: Float) {
        val lt = now / 1000f
        var tSmile = 0.2f
        var tSquint = 0f
        var tWiden = 0f
        var tRot = 0f
        var tNod = 0f
        var tMouth = 0f
        var tGx = 0f
        var tGy = 0f
        when (m) {
            "happy" -> { tSmile = 1f; tSquint = 0.3f }
            "excited" -> { tSmile = 1f; tMouth = 0.5f; tWiden = 0.3f }
            "shy" -> { tSmile = 0.4f; tGx = -1.2f; tGy = 1.2f; tRot = -2.5f; tSquint = 0.1f }
            "love" -> { tSmile = 0.9f; tSquint = 0.35f }
            "wink" -> { tSmile = 0.8f }
            "thinking" -> { tSmile = 0f; tGx = 1.2f; tGy = -1.2f; tRot = 2f }
            "surprised" -> { tSmile = 0f; tWiden = 1f; tMouth = 0.8f }
            "sad" -> { tSmile = -0.8f; tSquint = 0.15f; tNod = 1.5f; tRot = 1.5f }
            "cry" -> { tSmile = -1f; tSquint = 0.3f; tNod = 1.5f }
            "angry" -> { tSmile = -0.4f; tSquint = 0.35f }
            "sleepy" -> { tSmile = 0.1f; tNod = 2f; tRot = 2f }
        }
        if (listening) { tRot = 2.5f; tGx = 0f; tGy = 0f }
        tMouth = maxOf(tMouth, mo * 0.9f)
        val k = min(1f, frameDt * 6f)
        pSmile = lerp(pSmile, tSmile, k)
        pSquint = lerp(pSquint, tSquint, k)
        pWiden = lerp(pWiden, tWiden, k)
        pRot = lerp(pRot, tRot, k)
        pNod = lerp(pNod, tNod, k)
        pMouth = lerp(pMouth, tMouth, min(1f, frameDt * 14f))
        pGx = lerp(pGx, tGx + sin(lt * 0.7f) * 0.8f, k)
        pGy = lerp(pGy, tGy + sin(lt * 0.5f + 1f) * 0.5f, k)
        var wave = 0.35f * sin(t * 2 * PI).toFloat()
        var rotX = 0f
        var nodX = 0f
        val gp = (now - gestStart) / 1400f
        if (gp in 0f..1f) {
            val fade = 1f - gp
            when (gestName) {
                "wave" -> wave = sin(lt * 25f) * 1f
                "nod" -> nodX = sin(gp * PI.toFloat() * 5f) * 2.4f * fade
                "shake" -> rotX = sin(gp * PI.toFloat() * 6f) * 3.2f * fade
                "tilt" -> rotX = 3f * sin(gp * PI.toFloat())
            }
        }
        if (waving) wave = sin(lt * 25f)
        pWave = lerp(pWave, wave, min(1f, frameDt * 12f))
        rotTotal = pRot + rotX + sin(lt * 0.6f) * 0.7f + physA * 0.05f
        pNod += 0f
        nodExtra = nodX
    }
    private var nodExtra = 0f

    private fun drawImage(c: Canvas, bmp: Bitmap, m: String, now: Long) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val pad = 4f * d
        val extra = if (petalsOn) 64f * d else 0f
        val imgBottom = h - extra
        val dw = w - 2 * pad
        val dh = imgBottom - 2 * pad
        val sway = sin(t * 2 * PI).toFloat()
        val mo = if (speaking) abs(sin(t * 2 * PI * 6)).toFloat() else 0f
        var bob = sway * 2f * d * (if (m == "sleepy") 0.4f else 1f)
        if (m == "excited") bob -= abs(sin(t * 2 * PI * 2)).toFloat() * 5f * d
        val hp = (now - hopStart) / 700f
        if (hp in 0f..1f) bob -= abs(sin(hp * PI * 2)).toFloat() * 14f * d
        val breathe = 1f + 0.012f * sway + (if (rig) 0f else 0.02f * mo)
        val tilt = (if (m == "sleepy") 3f else 0f) + sway * (if (rig) 0.5f else 1f)

        var bl = 0f
        var br = 0f
        if (rig) {
            updateRig(m, now, mo)
            val bt = (now / 1000f) % 3.8f
            val blink = if (bt < 0.2f) sin(bt / 0.2f * PI.toFloat()) else 0f
            val closed = if (m == "sleepy") 0.95f else 0f
            bl = maxOf(blink, closed, if (m == "wink") 1f else 0f)
            br = maxOf(blink, closed)
        }

        val rr = RectF(pad, pad, w - pad, imgBottom - pad)
        clip.reset()
        when (frameMode) {
            1 -> clip.addOval(rr, Path.Direction.CW)
            0 -> clip.addRoundRect(rr, 22 * d, 22 * d, Path.Direction.CW)
            else -> clip.addRect(rr, Path.Direction.CW)
        }

        c.save()
        c.translate(0f, bob)
        c.scale(1f, breathe, w / 2, imgBottom - pad)
        c.rotate(tilt, w / 2, imgBottom - pad)
        if (frameMode != 2) c.clipPath(clip)
        bp.colorFilter = filterFor(m)
        val mw = if (rig) 36 else 8
        val mh = if (rig) 64 else 12
        val sc = dw / 192f
        val sy2 = dh / 340f
        var k = 0
        for (r in 0..mh) {
            val v = r / mh.toFloat()
            val y = pad + v * dh
            val off = (physA / 40f) * 16f * d * v * v + sin(t * 2 * PI * 1.5 + v * 4).toFloat() * 0.9f * d * v
            for (col in 0..mw) {
                val u = col / mw.toFloat()
                var ox = 0f
                var oy = 0f
                if (rig) {
                    rigDisp(u * 192f, v * 340f, bl, br)
                    ox = rdx * sc
                    oy = (rdy + nodExtra * (if (v * 340f < 118f) 1f else 0f)) * sy2
                }
                meshV[k++] = pad + u * dw + off + ox
                meshV[k++] = y + oy
            }
        }
        c.drawBitmapMesh(bmp, mw, mh, meshV, 0, null, 0, bp)
        if (rig && m == "cry") {
            val ph = (t * 2) % 1f
            fill(0xCC60A5FA.toInt())
            c.drawRoundRect(RectF(pad + 65f * sc, pad + 84f * sy2, pad + 68f * sc, pad + (88f + ph * 22f) * sy2), 2f, 2f, p)
            c.drawRoundRect(RectF(pad + 90f * sc, pad + 81f * sy2, pad + 93f * sc, pad + (85f + ph * 22f) * sy2), 2f, 2f, p)
        }
        if (frameMode != 2) {
            stroke(0x99FFFFFF.toInt(), 3f * d)
            c.drawPath(clip, p)
        }
        c.restore()

        if (petalsOn) {
            petals.update(frameDt, 5f, w * 0.30f, w * 0.92f, imgBottom * 0.04f, imgBottom * 0.30f, h, d, 34f, 5f, 3.8f)
            petals.draw(c)
        } else {
            petals.clear()
        }
        if (listening) {
            stroke(Color.argb((120 + 100 * abs(sin(t * 2 * PI * 2))).toInt(), 255, 64, 129), 3f * d)
            c.drawPath(clip, p)
        }
        extras(c, w / 100f, w / 2f, m)
    }

    private fun orbColor(m: String): Int = when (m) {
        "happy", "wink" -> 0xFF22D3EE.toInt()
        "excited" -> 0xFFFBBF24.toInt()
        "love" -> 0xFFF472B6.toInt()
        "shy" -> 0xFFFB7185.toInt()
        "sad", "cry" -> 0xFF3B82F6.toInt()
        "angry" -> 0xFFEF4444.toInt()
        "sleepy" -> 0xFF64748B.toInt()
        "thinking" -> 0xFFA78BFA.toInt()
        "surprised" -> 0xFFE0F2FE.toInt()
        else -> 0xFF38BDF8.toInt()
    }

    /** Jarvis: original holographic AI orb (aankhein, muskaan, ghoomti rings, bolte waqt pulse). */
    private fun drawOrb(c: Canvas, m: String, now: Long) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val extra = if (petalsOn) 64f * d else 0f
        val bodyH = h - extra
        val cx = w / 2
        var cy = bodyH / 2
        val R = min(w, bodyH) * 0.28f
        val mo = if (speaking) abs(sin(t * 2 * PI * 6)).toFloat() else 0f
        val hp = (now - hopStart) / 700f
        if (hp in 0f..1f) cy -= abs(sin(hp * PI * 2)).toFloat() * 14f * d
        cy += sin(t * 2 * PI).toFloat() * 3f * d * (if (m == "sleepy") 0.4f else 1f)
        val col = orbColor(m)
        val rr = Color.red(col)
        val gg = Color.green(col)
        val bb = Color.blue(col)
        val dim = if (m == "sleepy") 0.5f else 1f
        val pls = 1f + 0.05f * sin(t * 2 * PI).toFloat() + 0.12f * mo

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 2f * pls, intArrayOf(Color.argb((120 * dim).toInt(), rr, gg, bb), Color.argb(0, rr, gg, bb)), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * 2f * pls, p)
        p.shader = RadialGradient(cx - R * 0.3f, cy - R * 0.3f, R * 1.3f * pls,
            intArrayOf(Color.argb(255, 235, 250, 255), Color.argb((235 * dim).toInt(), rr, gg, bb), Color.argb((200 * dim).toInt(), rr / 3, gg / 3, bb / 2)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, R * pls, p)
        p.shader = null

        for (i in 0..2) {
            c.save()
            c.rotate((t * 360f * (if (i % 2 == 0) 1f else -1f) * (0.6f + i * 0.35f)), cx, cy)
            val rad = R * (1.3f + i * 0.22f)
            stroke(Color.argb(((200 - i * 40) * dim).toInt(), rr, gg, bb), (2.4f - i * 0.5f) * d)
            c.drawArc(RectF(cx - rad, cy - rad, cx + rad, cy + rad), i * 40f, 95f + i * 30f, false, p)
            c.restore()
        }

        val blink = if (m == "sleepy") 1f else if (t > 0.93f || (t > 0.45f && t < 0.48f)) 0.15f else 1f
        val ex = R * 0.38f
        val ey = cy - R * 0.1f
        for (s in intArrayOf(-1, 1)) {
            val x = cx + s * ex
            when (m) {
                "happy", "wink" -> { stroke(Color.argb(240, 10, 30, 60), 2.4f * d); c.drawArc(RectF(x - R * 0.2f, ey - R * 0.15f, x + R * 0.2f, ey + R * 0.15f), 200f, 140f, false, p) }
                "sleepy" -> { stroke(Color.argb(240, 10, 30, 60), 2.4f * d); c.drawArc(RectF(x - R * 0.2f, ey - R * 0.15f, x + R * 0.2f, ey + R * 0.15f), 20f, 140f, false, p) }
                "love" -> heart(c, x, ey, R * 0.28f, 0xFFFFFFFF.toInt())
                else -> {
                    val eh = R * 0.26f * blink * (if (m == "surprised") 1.35f else 1f)
                    fill(Color.argb(240, 10, 30, 60))
                    c.drawRoundRect(RectF(x - R * 0.1f, ey - eh, x + R * 0.1f, ey + eh), R * 0.1f, R * 0.1f, p)
                    fill(Color.WHITE)
                    c.drawCircle(x - R * 0.03f, ey - eh * 0.4f, R * 0.04f, p)
                }
            }
        }
        val my = cy + R * 0.36f
        if (mo > 0.05f) {
            fill(Color.argb(240, 10, 30, 60))
            c.drawOval(RectF(cx - R * 0.16f, my - R * 0.05f, cx + R * 0.16f, my + R * (0.07f + 0.2f * mo)), p)
        } else if (m == "sad" || m == "cry") {
            stroke(Color.argb(240, 10, 30, 60), 2.2f * d)
            c.drawArc(RectF(cx - R * 0.2f, my, cx + R * 0.2f, my + R * 0.24f), 200f, 140f, false, p)
        } else if (m == "angry" || m == "sleepy" || m == "thinking") {
            stroke(Color.argb(240, 10, 30, 60), 2.2f * d)
            c.drawLine(cx - R * 0.15f, my + R * 0.05f, cx + R * 0.15f, my + R * 0.05f, p)
        } else {
            stroke(Color.argb(240, 10, 30, 60), 2.2f * d)
            val wide = if (m == "happy" || m == "excited" || m == "wink" || m == "love") 0.26f else 0.18f
            c.drawArc(RectF(cx - R * wide, my - R * 0.1f, cx + R * wide, my + R * 0.2f), 20f, 140f, false, p)
        }
        if (speaking) {
            for (i in 0..4) {
                val bh = R * (0.12f + 0.3f * abs(sin(t * 2 * PI * 5 + i * 1.3)).toFloat())
                fill(Color.argb(220, rr, gg, bb))
                c.drawRoundRect(RectF(cx + (i - 2) * R * 0.3f - R * 0.07f, cy + R * 1.75f - bh, cx + (i - 2) * R * 0.3f + R * 0.07f, cy + R * 1.75f), R * 0.07f, R * 0.07f, p)
            }
        }
        if (listening) {
            val rad = R * (1.7f + 0.5f * ((t * 2) % 1f))
            stroke(Color.argb((200 * (1f - (t * 2) % 1f)).toInt(), 255, 64, 129), 2.5f * d)
            c.drawCircle(cx, cy, rad, p)
        }
        if (petalsOn) {
            petals.update(frameDt, 4f, w * 0.25f, w * 0.75f, cy - R * 1.2f, cy - R * 0.6f, h, d, 34f, 5f, 3.8f)
            petals.draw(c)
        } else {
            petals.clear()
        }
        extras(c, w / 100f, w / 2f, m)
    }

    // ---------------- hair ----------------
    private fun hairBlock(c: Canvas, L: Look, u: Float, cx: Float, top: Float, bottom: Float, half: Float, r: Float) {
        grad(L.hair, L.hairShade, top * u, bottom * u)
        c.drawRoundRect(RectF(cx - half * u, top * u, cx + half * u, bottom * u), r * u, r * u, p)
    }

    private fun tail(c: Canvas, L: Look, u: Float, rootX: Float, rootY: Float, len: Float, w: Float, ang: Float) {
        c.save()
        c.rotate(ang, rootX, rootY * u)
        grad(L.hair, L.hairShade, rootY * u, (rootY + len) * u)
        c.drawRoundRect(RectF(rootX - w * u / 2, rootY * u, rootX + w * u / 2, (rootY + len) * u), w * u / 2, w * u / 2, p)
        c.restore()
    }

    private fun backHair(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.kind) {
            0 -> {
                tail(c, L, u, cx - 30 * u, 30f, 78f, 20f, sway * 3f + physA * 1.2f)
                tail(c, L, u, cx + 30 * u, 30f, 78f, 20f, sway * 3f + physA * 1.2f)
                hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
            }
            1 -> hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
            2 -> hairBlock(c, L, u, cx, 12f, 114f, 35f, 30f)
            3 -> {
                hairBlock(c, L, u, cx, 14f, 84f, 33f, 30f)
                grad(L.hair, L.hairShade, 4 * u, 24 * u)
                c.drawCircle(cx - 26 * u, 14 * u, 10 * u, p)
                c.drawCircle(cx + 26 * u, 14 * u, 10 * u, p)
            }
            4 -> hairBlock(c, L, u, cx, 14f, 80f, 33f, 30f)
            5 -> {
                hairBlock(c, L, u, cx, 12f, 70f, 32f, 28f)
                tail(c, L, u, cx + 24 * u, 24f, 72f, 14f, -physA * 1.3f + sway * 4f)
            }
            6 -> hairBlock(c, L, u, cx, 12f, 64f, 32f, 28f)
            7 -> hairBlock(c, L, u, cx, 12f, 112f, 35f, 30f)
            8 -> hairBlock(c, L, u, cx, 12f, 62f, 32f, 28f)
            else -> {
                hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
                tail(c, L, u, cx - 35 * u, 56f, 38f, 14f, sway * 4f + physA * 1.1f)
                tail(c, L, u, cx + 35 * u, 56f, 38f, 14f, sway * 4f + physA * 1.1f)
            }
        }
    }

    private fun bangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 46 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 48 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 48 * u)
        path.lineTo(cx + 22 * u, 30 * u); path.lineTo(cx + 10 * u, 40 * u); path.lineTo(cx - 2 * u, 28 * u)
        path.lineTo(cx - 14 * u, 40 * u); path.lineTo(cx - 23 * u, 30 * u); path.close()
        c.drawPath(path, p)
    }

    private fun shortBangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 40 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 46 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 46 * u)
        path.lineTo(cx + 24 * u, 26 * u); path.lineTo(cx + 12 * u, 34 * u); path.lineTo(cx, 24 * u)
        path.lineTo(cx - 12 * u, 34 * u); path.lineTo(cx - 24 * u, 26 * u); path.close()
        c.drawPath(path, p)
    }

    private fun sideBangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 52 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 52 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 46 * u)
        path.lineTo(cx + 20 * u, 33 * u)
        path.quadTo(cx + 4 * u, 46 * u, cx - 14 * u, 30 * u)
        path.quadTo(cx - 22 * u, 42 * u, cx - 30 * u, 52 * u)
        path.close()
        c.drawPath(path, p)
    }

    private fun spiky(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 4 * u, 46 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 46 * u); path.lineTo(cx - 34 * u, 20 * u); path.lineTo(cx - 20 * u, 28 * u)
        path.lineTo(cx - 18 * u, 6 * u); path.lineTo(cx - 6 * u, 22 * u); path.lineTo(cx + 2 * u, 4 * u)
        path.lineTo(cx + 10 * u, 22 * u); path.lineTo(cx + 22 * u, 8 * u); path.lineTo(cx + 24 * u, 28 * u)
        path.lineTo(cx + 36 * u, 22 * u); path.lineTo(cx + 30 * u, 46 * u)
        path.lineTo(cx + 22 * u, 34 * u); path.lineTo(cx + 8 * u, 42 * u); path.lineTo(cx - 4 * u, 32 * u)
        path.lineTo(cx - 16 * u, 42 * u); path.lineTo(cx - 24 * u, 34 * u); path.close()
        c.drawPath(path, p)
    }

    private fun frontHair(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.kind) {
            1 -> spiky(c, L, u, cx)
            6 -> {
                shortBangs(c, L, u, cx)
                c.save()
                c.rotate(physA * 1.5f + sway * 3f, cx, 14 * u)
                stroke(L.hair, 2.6f * u)
                path.reset()
                path.moveTo(cx, 15 * u)
                path.quadTo(cx + 4 * u, 6 * u, cx + 10 * u, 8 * u)
                c.drawPath(path, p)
                c.restore()
            }
            8 -> shortBangs(c, L, u, cx)
            7 -> sideBangs(c, L, u, cx)
            else -> bangs(c, L, u, cx)
        }
        accessory(c, L, u, cx, sway)
    }

    private fun accessory(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.acc) {
            1 -> {
                stroke(L.outfit2, 3.5f * u)
                c.drawArc(RectF(cx - 31 * u, 14 * u, cx + 31 * u, 82 * u), 190f, 160f, false, p)
                fill(L.outfit2)
                c.drawRoundRect(RectF(cx - 37 * u, 42 * u, cx - 27 * u, 62 * u), 4 * u, 4 * u, p)
                c.drawRoundRect(RectF(cx + 27 * u, 42 * u, cx + 37 * u, 62 * u), 4 * u, 4 * u, p)
                fill(0xFF0F172A.toInt())
                c.drawCircle(cx - 32 * u, 52 * u, 2.5f * u, p)
                c.drawCircle(cx + 32 * u, 52 * u, 2.5f * u, p)
            }
            2 -> {
                c.save()
                c.rotate(physA * 0.4f, cx, 22 * u)
                for (s in intArrayOf(-1, 1)) {
                    fill(L.hairShade)
                    path.reset()
                    path.moveTo(cx + s * 27 * u, 24 * u); path.lineTo(cx + s * 27 * u, 3 * u); path.lineTo(cx + s * 9 * u, 15 * u)
                    path.close()
                    c.drawPath(path, p)
                    fill(0xFFFFB6C9.toInt())
                    path.reset()
                    path.moveTo(cx + s * 24 * u, 19 * u); path.lineTo(cx + s * 24 * u, 8 * u); path.lineTo(cx + s * 15 * u, 15 * u)
                    path.close()
                    c.drawPath(path, p)
                }
                c.restore()
            }
            3 -> {
                for (s in intArrayOf(-1, 1)) {
                    grad(L.hair, L.hairShade, 3 * u, 28 * u)
                    path.reset()
                    path.moveTo(cx + s * 28 * u, 26 * u); path.lineTo(cx + s * 24 * u, 4 * u); path.lineTo(cx + s * 8 * u, 16 * u)
                    path.close()
                    c.drawPath(path, p)
                    fill(0xFFFFD1DC.toInt())
                    path.reset()
                    path.moveTo(cx + s * 24 * u, 21 * u); path.lineTo(cx + s * 22 * u, 10 * u); path.lineTo(cx + s * 14 * u, 17 * u)
                    path.close()
                    c.drawPath(path, p)
                }
            }
            4 -> {
                fill(0xFFFF3B5C.toInt())
                val x = cx - 22 * u
                val y = 20 * u
                path.reset(); path.moveTo(x, y); path.lineTo(x - 10 * u, y - 7 * u); path.lineTo(x - 10 * u, y + 7 * u); path.close()
                c.drawPath(path, p)
                path.reset(); path.moveTo(x, y); path.lineTo(x + 10 * u, y - 7 * u); path.lineTo(x + 10 * u, y + 7 * u); path.close()
                c.drawPath(path, p)
                c.drawCircle(x, y, 3 * u, p)
            }
            5 -> {
                spark(c, cx + 18 * u, 24 * u, 5 * u, 0xFFFDE047.toInt())
                spark(c, cx - 20 * u, 22 * u, 3 * u, 0xFFFFFFFF.toInt())
            }
            6 -> {
                val x = cx + 20 * u
                val y = 20 * u
                fill(0xFFFFFFFF.toInt())
                for (i in 0 until 5) {
                    val a = i * 2 * PI / 5
                    c.drawCircle(x + (5 * u * cos(a)).toFloat(), y + (5 * u * sin(a)).toFloat(), 3.2f * u, p)
                }
                fill(0xFFFFD84D.toInt())
                c.drawCircle(x, y, 3 * u, p)
            }
            7 -> {
                fill(0xFF1E1B4B.toInt())
                c.drawOval(RectF(cx - 36 * u, 18 * u, cx + 36 * u, 29 * u), p)
                path.reset()
                path.moveTo(cx - 20 * u, 22 * u)
                path.quadTo(cx - 4 * u, 17 * u, cx + 10 * u, 6 * u)
                path.quadTo(cx + 14 * u, 15 * u, cx + 20 * u, 22 * u)
                path.close()
                c.drawPath(path, p)
                fill(L.outfit2)
                c.drawRect(cx - 20 * u, 18 * u, cx + 20 * u, 22 * u, p)
                spark(c, cx + 12 * u, 14 * u, 3.5f * u, 0xFFFDE047.toInt())
            }
            8 -> {
                stroke(L.outfit2, 4f * u)
                c.drawArc(RectF(cx - 29 * u, 14 * u, cx + 29 * u, 60 * u), 205f, 130f, false, p)
            }
        }
    }

    // ---------------- body ----------------
    private fun body(c: Canvas, L: Look, u: Float, cx: Float) {
        fill(L.outfit)
        path.reset()
        path.moveTo(cx - 17 * u, 76 * u); path.lineTo(cx + 17 * u, 76 * u)
        path.lineTo(cx + 27 * u, 128 * u); path.lineTo(cx - 27 * u, 128 * u); path.close()
        c.drawPath(path, p)
        fill(L.outfit2)
        when (L.cloth) {
            1 -> {
                c.drawRoundRect(RectF(cx - 20 * u, 74 * u, cx + 20 * u, 85 * u), 5 * u, 5 * u, p)
                c.drawRoundRect(RectF(cx + 8 * u, 80 * u, cx + 17 * u, 104 * u), 4 * u, 4 * u, p)
            }
            2 -> {
                c.drawCircle(cx - 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx + 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx, 86 * u, 2.5f * u, p)
            }
            3 -> {
                fill(Color.WHITE)
                path.reset()
                path.moveTo(cx - 17 * u, 76 * u); path.lineTo(cx + 17 * u, 76 * u); path.lineTo(cx + 12 * u, 92 * u)
                path.lineTo(cx, 84 * u); path.lineTo(cx - 12 * u, 92 * u); path.close()
                c.drawPath(path, p)
                fill(L.outfit2)
                c.drawCircle(cx, 85 * u, 3 * u, p)
            }
            4 -> {
                stroke(L.outfit2, 5f * u)
                c.drawArc(RectF(cx - 20 * u, 70 * u, cx + 20 * u, 90 * u), 10f, 160f, false, p)
                stroke(Color.WHITE, 1.4f * u)
                c.drawLine(cx - 4 * u, 88 * u, cx - 4 * u, 100 * u, p)
                c.drawLine(cx + 4 * u, 88 * u, cx + 4 * u, 100 * u, p)
            }
            else -> {
                path.reset()
                path.moveTo(cx - 9 * u, 76 * u); path.lineTo(cx + 9 * u, 76 * u); path.lineTo(cx, 90 * u); path.close()
                c.drawPath(path, p)
            }
        }
        if (waving) {
            val ang = Math.toRadians((-55 + sin(t * 2 * PI * 4) * 22).toDouble())
            val sx = cx + 20 * u
            val sy = 88 * u
            val hx = sx + (26 * u * cos(ang)).toFloat()
            val hy = sy + (26 * u * sin(ang)).toFloat()
            stroke(L.outfit, 6 * u)
            c.drawLine(sx, sy, hx, hy, p)
            fill(L.skin)
            c.drawCircle(hx, hy, 5 * u, p)
        }
    }

    // ---------------- face ----------------
    private fun eyes(c: Canvas, L: Look, u: Float, cx: Float, m: String, blink: Float, gx0: Float, gy0: Float) {
        var gx = gx0
        var gy = gy0
        when (m) {
            "shy" -> { gx = -2.5f * u; gy = 2.5f * u }
            "thinking" -> { gx = 2.5f * u; gy = -2.5f * u }
            "sad", "cry" -> { gx = 0f; gy = 1.5f * u }
        }
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * 12 * u
            val ey = 51 * u
            val arcUp = m == "happy" || (m == "wink" && s == -1)
            when {
                arcUp -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 200f, 140f, false, p)
                }
                m == "sleepy" -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 20f, 140f, false, p)
                }
                m == "love" -> heart(c, ex, ey, 7 * u, 0xFFFF4D8D.toInt())
                m == "excited" -> {
                    fill(Color.WHITE)
                    c.drawOval(RectF(ex - 8 * u, ey - 10 * u, ex + 8 * u, ey + 10 * u), p)
                    spark(c, ex, ey, 9 * u, L.eye)
                    spark(c, ex - 2 * u, ey - 3 * u, 3 * u, Color.WHITE)
                }
                else -> {
                    val big = if (m == "surprised") 1.15f else 1f
                    val sq = if (m == "angry") 0.8f else 1f
                    c.save()
                    c.scale(1f, blink * sq, ex, ey)
                    fill(Color.WHITE)
                    c.drawOval(RectF(ex - 8 * u * big, ey - 10 * u * big, ex + 8 * u * big, ey + 10 * u * big), p)
                    val ir = (if (m == "surprised") 5.2f else 6.6f) * u
                    fill(L.eye)
                    c.drawCircle(ex + gx, ey + gy, ir, p)
                    fill(0xFF111827.toInt())
                    c.drawCircle(ex + gx, ey + gy, ir * 0.5f, p)
                    fill(Color.WHITE)
                    c.drawCircle(ex + gx - 2.5f * u, ey + gy - 3f * u, 2.2f * u, p)
                    c.drawCircle(ex + gx + 2.2f * u, ey + gy + 2.5f * u, 1.1f * u, p)
                    c.restore()
                    stroke(0xFF111827.toInt(), 1.8f * u)
                    c.drawArc(RectF(ex - 8.5f * u, ey - 10.5f * u, ex + 8.5f * u, ey + 9.5f * u), 205f, 130f, false, p)
                    if (m == "cry") {
                        val ph = (t * 2 + (if (s == 1) 0.3f else 0f)) % 1f
                        fill(0xCC60A5FA.toInt())
                        c.drawRoundRect(RectF(ex - 1.6f * u, ey + 9 * u, ex + 1.6f * u, ey + (12 + ph * 14) * u), 1.6f * u, 1.6f * u, p)
                    }
                }
            }
        }
    }

    private fun glasses(c: Canvas, u: Float, cx: Float) {
        stroke(0xFF334155.toInt(), 1.6f * u)
        c.drawCircle(cx - 12 * u, 51 * u, 10 * u, p)
        c.drawCircle(cx + 12 * u, 51 * u, 10 * u, p)
        c.drawLine(cx - 2 * u, 50 * u, cx + 2 * u, 50 * u, p)
    }

    private fun brows(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "sad", "cry", "shy" -> {
                stroke(ink, 1.8f * u)
                c.drawLine(cx - 19 * u, 41 * u, cx - 7 * u, 37 * u, p)
                c.drawLine(cx + 7 * u, 37 * u, cx + 19 * u, 41 * u, p)
            }
            "angry" -> {
                stroke(ink, 2.2f * u)
                c.drawLine(cx - 19 * u, 36 * u, cx - 7 * u, 40 * u, p)
                c.drawLine(cx + 7 * u, 40 * u, cx + 19 * u, 36 * u, p)
            }
            "surprised", "excited" -> {
                stroke(ink, 1.8f * u)
                c.drawArc(RectF(cx - 19 * u, 31 * u, cx - 7 * u, 41 * u), 200f, 140f, false, p)
                c.drawArc(RectF(cx + 7 * u, 31 * u, cx + 19 * u, 41 * u), 200f, 140f, false, p)
            }
            "thinking" -> {
                stroke(ink, 1.8f * u)
                c.drawLine(cx - 19 * u, 40 * u, cx - 7 * u, 40 * u, p)
                c.drawArc(RectF(cx + 7 * u, 30 * u, cx + 19 * u, 40 * u), 200f, 140f, false, p)
            }
        }
    }

    private fun mouth(c: Canvas, u: Float, cx: Float, m: String, mo: Float) {
        if (mo > 0.05f) {
            fill(lip)
            c.drawOval(RectF(cx - 4.5f * u, 65 * u, cx + 4.5f * u, (66 + 7 * mo) * u), p)
            return
        }
        when (m) {
            "happy", "wink" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 7 * u, 58 * u, cx + 7 * u, 72 * u), 20f, 140f, false, p) }
            "excited" -> { fill(lip); c.drawArc(RectF(cx - 7 * u, 60 * u, cx + 7 * u, 74 * u), 0f, 180f, true, p) }
            "sad" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 5 * u, 68 * u, cx + 5 * u, 78 * u), 200f, 140f, false, p) }
            "cry" -> {
                stroke(lip, 1.8f * u)
                c.drawArc(RectF(cx - 5 * u, 68 * u, cx + 5 * u, 78 * u), 200f, 140f, false, p)
            }
            "shy" -> {
                stroke(lip, 1.6f * u)
                path.reset()
                path.moveTo(cx - 5 * u, 67 * u)
                path.quadTo(cx - 2.5f * u, 64 * u, cx, 67 * u)
                path.quadTo(cx + 2.5f * u, 70 * u, cx + 5 * u, 67 * u)
                c.drawPath(path, p)
            }
            "thinking" -> { fill(lip); c.drawOval(RectF(cx + 1 * u, 65 * u, cx + 6 * u, 70 * u), p) }
            "surprised" -> { fill(lip); c.drawOval(RectF(cx - 3.5f * u, 65 * u, cx + 3.5f * u, 73 * u), p) }
            "sleepy", "angry" -> { stroke(lip, 1.8f * u); c.drawLine(cx - 4 * u, 68 * u, cx + 4 * u, 68 * u, p) }
            else -> { stroke(lip, 1.6f * u); c.drawArc(RectF(cx - 5 * u, 62 * u, cx + 5 * u, 70 * u), 20f, 140f, false, p) }
        }
    }

    private fun extras(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "love" -> for (i in 0..2) {
                val ph = (t + i / 3f) % 1f
                val a = ((1f - ph) * 255).toInt()
                heart(c, cx + (i - 1) * 16 * u + sin(ph * 6.28f) * 3 * u, 30 * u - ph * 26 * u, (3 + 2 * (1 - ph)) * u, Color.argb(a, 255, 77, 141))
            }
            "happy", "excited", "wink" -> {
                val a = (abs(sin(t * 2 * PI * 2)) * 255).toInt()
                spark(c, cx - 38 * u, 30 * u, 4 * u, Color.argb(a, 255, 220, 100))
                spark(c, cx + 38 * u, 58 * u, 3 * u, Color.argb(a, 255, 220, 100))
                if (m == "excited") spark(c, cx + 36 * u, 22 * u, 4.5f * u, Color.argb(255 - a, 255, 220, 100))
            }
            "shy" -> {
                fill(0xCC60A5FA.toInt())
                c.drawCircle(cx + 28 * u, 38 * u, 2 * u, p)
            }
            "thinking" -> {
                for (i in 0..2) {
                    val a = (((t * 3 - i) % 1f + 1f) % 1f * 255).toInt()
                    fill(Color.argb(a, 120, 120, 140))
                    c.drawCircle(cx + (30 + i * 6) * u, (20 - i * 6) * u, (1.8f + i * 0.5f) * u, p)
                }
            }
            "sad" -> {
                val ph = (t * 2) % 1f
                fill(0xCC60A5FA.toInt())
                c.drawCircle(cx - 16 * u, (58 + ph * 14) * u, 1.8f * u, p)
            }
            "sleepy" -> {
                val ph = t % 1f
                val a = ((1f - ph) * 255).toInt()
                fill(Color.argb(a, 147, 197, 253))
                p.textSize = 9 * u
                c.drawText("z", cx + 26 * u + ph * 6 * u, 24 * u - ph * 10 * u, p)
                p.textSize = 12 * u
                c.drawText("Z", cx + 32 * u + ph * 4 * u, 16 * u - ph * 8 * u, p)
            }
            "surprised" -> {
                fill(0xFFEF4444.toInt())
                p.textSize = 14 * u
                p.isFakeBoldText = true
                c.drawText("!", cx + 30 * u, 22 * u, p)
                p.isFakeBoldText = false
            }
            "angry" -> {
                stroke(0xFFEF4444.toInt(), 2f * u)
                c.drawLine(cx + 24 * u, 16 * u, cx + 32 * u, 24 * u, p)
                c.drawLine(cx + 32 * u, 16 * u, cx + 24 * u, 24 * u, p)
            }
        }
    }
}
