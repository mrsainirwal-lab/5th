package com.zara.floatai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Aapki import ki hui anime images ka store (app ke private folder me, resize karke). */
object CharStore {
    private fun dir(c: Context): File {
        val d = File(c.filesDir, "chars")
        d.mkdirs()
        return d
    }

    fun list(c: Context): List<File> = dir(c).listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()

    fun load(f: File): Bitmap? = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }

    fun delete(f: File) { try { f.delete() } catch (e: Exception) {} }

    /** Pehli baar app khulne par "Maya" ko inbuilt default character ke taur par daal deta hai (assets/maya_default.png). */
    fun seedDefault(c: Context) {
        if (list(c).isNotEmpty()) return
        try {
            val f = File(dir(c), "c_default_maya.png")
            c.assets.open("maya_default.png").use { input -> f.outputStream().use { out -> input.copyTo(out) } }
            if (Prefs.get(c, "cname").isBlank()) Prefs.put(c, "cname", "Maya")
        } catch (e: Exception) {
        }
    }

    fun import(c: Context, uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val big = maxOf(bounds.outWidth, bounds.outHeight)
            while (big / sample > 1400) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false
            val scale = 640f / maxOf(bmp.width, bmp.height)
            val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val alpha = out.hasAlpha()
            val f = File(dir(c), "c_" + System.nanoTime() + (if (alpha) ".png" else ".jpg"))
            f.outputStream().use { out.compress(if (alpha) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}
