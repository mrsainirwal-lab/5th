package com.zara.floatai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin
import kotlin.random.Random

/**
 * Halka cherry blossom (sakura) petal animation: petals upar (baalon ke paas) se shuru hoke
 * niche jaate jaate ghoomte aur dheere dheere fade/disappear hote hain.
 * Dono jagah use hota hai: floating character ke piche, aur app ke andar background me.
 * on/off Prefs se control hota hai ("petals_float" aur "petals_app").
 */
class PetalsView(ctx: Context) : View(ctx) {

    private class Petal(var x: Float, var y: Float, var speed: Float, var drift: Float, var size: Float, var rot: Float, var rotSpeed: Float, var life: Float)

    var spawnFromTopFraction = 0.12f   // kis height se petals "hair" ke paas se shuru hote hain
    var density = 1f                    // kam density = app ke andar halka effect

    private val petals = ArrayList<Petal>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFC1D9.toInt() }
    private var spawnAcc = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { step(); invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); petals.clear(); super.onDetachedFromWindow() }

    private fun step() {
        if (width <= 0 || height <= 0) return
        spawnAcc += density
        if (spawnAcc >= 6f && petals.size < (18 * density).toInt().coerceAtLeast(4)) {
            spawnAcc = 0f
            petals.add(
                Petal(
                    x = Random.nextFloat() * width,
                    y = height * spawnFromTopFraction * Random.nextFloat(),
                    speed = 0.6f + Random.nextFloat() * 1.1f,
                    drift = (Random.nextFloat() - 0.5f) * 2.2f,
                    size = (5 + Random.nextFloat() * 6) * resources.displayMetrics.density,
                    rot = Random.nextFloat() * 360f,
                    rotSpeed = (Random.nextFloat() - 0.5f) * 6f,
                    life = 1f
                )
            )
        }
        val it = petals.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.y += p.speed
            p.x += p.drift + sin(p.y * 0.03f).toFloat() * 0.6f
            p.rot += p.rotSpeed
            if (p.y > height * 0.55f) p.life -= 0.012f
            if (p.y > height || p.life <= 0f) it.remove()
        }
    }

    override fun onDraw(c: Canvas) {
        for (p in petals) {
            paint.alpha = (220 * p.life.coerceIn(0f, 1f)).toInt()
            c.save()
            c.translate(p.x, p.y)
            c.rotate(p.rot)
            val s = p.size
            val path = Path().apply {
                moveTo(0f, -s)
                quadTo(s * 0.9f, -s * 0.3f, 0f, s)
                quadTo(-s * 0.9f, -s * 0.3f, 0f, -s)
                close()
            }
            c.drawPath(path, paint)
            c.restore()
        }
    }
}
