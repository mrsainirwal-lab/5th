package com.zara.floatai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var testVoice: Voice? = null
    private lateinit var status: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(40)) }

        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(16), 0, dp(2))
        }
        fun edit(key: String, hint: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(Prefs.get(this@MainActivity, key, "")); setSingleLine()
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { Prefs.put(this@MainActivity, key, e.toString().trim()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }
        fun spin(items: List<String>, sel: Int, onSel: (Int) -> Unit) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        col.addView(TextView(this).apply { text = "Zara Float AI v2"; textSize = 24f; setTypeface(null, Typeface.BOLD) })
        col.addView(TextView(this).apply { text = "Tap = baat, double tap = pyaar, drag = move, 2 sec dabao = band." })

        status = TextView(this).apply { setPadding(0, dp(10), 0, 0) }
        col.addView(status)

        // Character
        col.addView(label("Character"))
        val preview = CharacterView(this).apply { style = Prefs.geti(this@MainActivity, "char"); mood = "happy" }
        col.addView(spin(Looks.all.map { it.name }, Prefs.geti(this, "char")) {
            Prefs.puti(this, "char", it); preview.style = it
        })
        col.addView(preview, LinearLayout.LayoutParams(dp(120), dp(156)))

        // Voice
        col.addView(label("Voice / tone"))
        col.addView(spin(Voice.names, Prefs.geti(this, "voice")) { Prefs.puti(this, "voice", it) })
        col.addView(btn("Test voice") {
            if (testVoice == null) testVoice = Voice(this) {}
            testVoice?.speak("Namaste! Main tumhari floating assistant hoon.")
        })

        // Language
        col.addView(label("Language"))
        val langs = listOf("hi-IN", "en-US", "en-IN")
        col.addView(spin(listOf("Hindi / Hinglish", "English (US)", "English (India)"), langs.indexOf(Prefs.get(this, "lang", "hi-IN")).coerceAtLeast(0)) {
            Prefs.put(this, "lang", langs[it])
        })

        // AI provider
        col.addView(label("AI brain"))
        val provs = listOf("offline", "openai", "gemini")
        col.addView(spin(listOf("Offline (bina internet)", "ChatGPT (OpenAI)", "Gemini (Google)"), provs.indexOf(Prefs.get(this, "provider", "offline")).coerceAtLeast(0)) {
            Prefs.put(this, "provider", provs[it])
        })
        col.addView(edit("gemini_key", "Gemini API key", true))
        col.addView(edit("gem_model2", "Gemini model (khali = auto, recommended)"))
        col.addView(edit("openai_key", "OpenAI API key", true))
        col.addView(edit("oa_model2", "OpenAI model (khali = auto, recommended)"))
        val result = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        col.addView(btn("Test connection") {
            result.text = "Testing..."
            Thread {
                val r = Brain.test(this)
                runOnUiThread { result.text = r }
            }.start()
        })
        col.addView(result)

        // Features
        col.addView(label("Features"))
        col.addView(Switch(this).apply {
            text = "App detect: Zara tumhare khule apps par bolegi"
            isChecked = Prefs.get(this@MainActivity, "appdetect", "0") == "1"
            setOnCheckedChangeListener { _, on ->
                Prefs.put(this@MainActivity, "appdetect", if (on) "1" else "0")
                if (on && !Util.hasUsage(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Zara Float AI ke liye Usage access ON karo", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            }
        })
        col.addView(btn("Usage access settings kholo") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        col.addView(btn("Volume + - wake: Accessibility kholo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(TextView(this).apply {
            text = "Accessibility me 'Zara Volume Wake' ko ON karo. Phir Volume + aur - ek saath dabane par Zara aa jayegi."
            textSize = 12f
        })

        // Memory
        col.addView(btn("Reset what Zara learned") {
            Memory.clear(this); Toast.makeText(this, "Memory cleared", Toast.LENGTH_SHORT).show()
        })

        // Start / stop
        col.addView(label("Control"))
        col.addView(btn("START floating assistant") { start() })
        col.addView(btn("STOP") { stopService(Intent(this, FloatingService::class.java)) })
        col.addView(TextView(this).apply {
            text = "Tip: bolo \"yaad rakh <baat>\" ya \"my name is ...\" taaki Zara tumhe yaad rakhe. \"sab bhool ja\" se memory clear. Offline me bhi: kaise ho, joke, shayari, hisaab, time."
            setPadding(0, dp(16), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = "Overlay permission: " + (if (ov) "OK" else "NAHI") +
            "\nMic permission: " + (if (mic) "OK" else "NAHI") +
            "\nUsage access (app detect): " + (if (Util.hasUsage(this)) "OK" else "band") +
            "\nVolume wake service: " + (if (Util.a11yOn(this)) "ON" else "band")
    }

    private fun start() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
            Toast.makeText(this, "Mic permission do, phir START dobara dabao", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" allow karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Zara chalu!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { testVoice?.shutdown(); super.onDestroy() }
}
