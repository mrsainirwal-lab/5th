package com.zara.floatai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class Look(val name: String, val hair: Int, val hairShade: Int, val eye: Int, val outfit: Int, val outfit2: Int, val kind: Int)

object Looks {
    val all = listOf(
        Look("Mika", 0xFF22D3EE.toInt(), 0xFF0E7490.toInt(), 0xFFF472B6.toInt(), 0xFF1E1B4B.toInt(), 0xFF22D3EE.toInt(), 0),
        Look("Aoi", 0xFF3B82F6.toInt(), 0xFF1D4ED8.toInt(), 0xFFFBBF24.toInt(), 0xFF111827.toInt(), 0xFFEF4444.toInt(), 1),
        Look("Nyx", 0xFF6D28D9.toInt(), 0xFF2E1065.toInt(), 0xFFF43F5E.toInt(), 0xFF18181B.toInt(), 0xFFA855F7.toInt(), 2),
        Look("Hikari", 0xFFFDE68A.toInt(), 0xFFF59E0B.toInt(), 0xFF38BDF8.toInt(), 0xFFFFFFFF.toInt(), 0xFFFB7185.toInt(), 3),
        Look("Yuzu", 0xFFFB923C.toInt(), 0xFFEA580C.toInt(), 0xFF84CC16.toInt(), 0xFFFEF3C7.toInt(), 0xFFDC2626.toInt(), 4)
    )
}

/** Original anime-style characters drawn in code. Moods: neutral, happy, sad, surprised, love, sleepy, angry. */
class CharacterView(ctx: Context) : View(ctx) {
    var style = 0
        set(v) { field = v.coerceIn(0, 4); invalidate() }
    var mood = "neutral"
    var speaking = false
    var listening = false
    var waving = false
    var sleeping = false

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f
    private val skin = 0xFFFFE4D2.toInt()
    private val ink = 0xFF3F3F46.toInt()
    private val lip = 0xFFB5334F.toInt()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun fill(col: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = col }
    private fun grad(c1: Int, c2: Int, y0: Float, y1: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, y0, 0f, y1, c1, c2, Shader.TileMode.CLAMP)
    }
    private fun stroke(col: Int, wd: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = wd; p.strokeCap = Paint.Cap.ROUND
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(x, y + s * 0.35f)
        path.cubicTo(x - s, y - s * 0.3f, x - s * 0.5f, y - s * 1.1f, x, y - s * 0.45f)
        path.cubicTo(x + s * 0.5f, y - s * 1.1f, x + s, y - s * 0.3f, x, y + s * 0.35f)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    private fun spark(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(x, y - r)
        path.quadTo(x, y, x + r, y)
        path.quadTo(x, y, x, y + r)
        path.quadTo(x, y, x - r, y)
        path.quadTo(x, y, x, y - r)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val L = Looks.all[style]
        val u = width / 100f
        val cx = width / 2f
        val m = if (sleeping) "sleepy" else mood
        val sway = sin(t * 2 * PI).toFloat()
        val bob = sway * 2.5f * u * (if (m == "sleepy") 0.4f else 1f)
        val blink = if (m == "sleepy") 1f else if (t > 0.93f || (t > 0.45f && t < 0.48f)) 0.1f else 1f
        val mo = if (speaking) abs(sin(t * 2 * PI * 6)).toFloat() else 0f

        c.save()
        c.translate(0f, bob)

        if (listening) {
            stroke(0xAAFF4081.toInt(), 2.5f * u)
            c.drawCircle(cx, 48 * u, (33 + 4 * abs(sin(t * 2 * PI * 2)).toFloat()) * u, p)
        }
        backHair(c, L, u, cx, sway)
        body(c, L, u, cx)
        fill(skin)
        c.drawCircle(cx, 48 * u, 28 * u, p)
        frontHair(c, L, u, cx)
        eyes(c, L, u, cx, m, blink)
        brows(c, u, cx, m)
        fill(if (m == "love") 0x99FF6B8A.toInt() else 0x55FF6B8A.toInt())
        c.drawCircle(cx - 18 * u, 62 * u, 4 * u, p)
        c.drawCircle(cx + 18 * u, 62 * u, 4 * u, p)
        mouth(c, u, cx, m, mo)
        extras(c, u, cx, m)
        c.restore()
    }

    private fun backHair(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.kind) {
            0 -> {
                for (s in intArrayOf(-1, 1)) {
                    c.save()
                    c.rotate(s * sway * 3f, cx + s * 30 * u, 36 * u)
                    grad(L.hair, L.hairShade, 30 * u, 108 * u)
                    c.drawRoundRect(RectF(cx + s * 30 * u - 10 * u, 30 * u, cx + s * 30 * u + 10 * u, 108 * u), 10 * u, 10 * u, p)
                    c.restore()
                }
                grad(L.hair, L.hairShade, 12 * u, 70 * u)
                c.drawRoundRect(RectF(cx - 32 * u, 12 * u, cx + 32 * u, 66 * u), 28 * u, 28 * u, p)
            }
            1 -> {
                grad(L.hair, L.hairShade, 12 * u, 70 * u)
                c.drawRoundRect(RectF(cx - 32 * u, 12 * u, cx + 32 * u, 66 * u), 28 * u, 28 * u, p)
            }
            2 -> {
                grad(L.hair, L.hairShade, 12 * u, 114 * u)
                c.drawRoundRect(RectF(cx - 35 * u, 12 * u, cx + 35 * u, 114 * u), 30 * u, 30 * u, p)
            }
            3 -> {
                grad(L.hair, L.hairShade, 14 * u, 84 * u)
                c.drawRoundRect(RectF(cx - 33 * u, 14 * u, cx + 33 * u, 84 * u), 30 * u, 30 * u, p)
                c.drawCircle(cx - 26 * u, 14 * u, 10 * u, p)
                c.drawCircle(cx + 26 * u, 14 * u, 10 * u, p)
            }
            else -> {
                c.save()
                c.rotate(sway * 8f, cx + 20 * u, 112 * u)
                grad(L.hair, L.hairShade, 86 * u, 122 * u)
                c.drawOval(RectF(cx + 18 * u, 86 * u, cx + 46 * u, 122 * u), p)
                fill(Color.WHITE)
                c.drawCircle(cx + 40 * u, 116 * u, 5 * u, p)
                c.restore()
                grad(L.hair, L.hairShade, 14 * u, 80 * u)
                c.drawRoundRect(RectF(cx - 33 * u, 14 * u, cx + 33 * u, 80 * u), 30 * u, 30 * u, p)
            }
        }
    }

    private fun body(c: Canvas, L: Look, u: Float, cx: Float) {
        fill(L.outfit)
        path.reset()
        path.moveTo(cx - 17 * u, 76 * u); path.lineTo(cx + 17 * u, 76 * u)
        path.lineTo(cx + 27 * u, 128 * u); path.lineTo(cx - 27 * u, 128 * u); path.close()
        c.drawPath(path, p)
        fill(L.outfit2)
        when (L.kind) {
            1 -> {
                c.drawRoundRect(RectF(cx - 20 * u, 74 * u, cx + 20 * u, 85 * u), 5 * u, 5 * u, p)
                c.drawRoundRect(RectF(cx + 8 * u, 80 * u, cx + 17 * u, 104 * u), 4 * u, 4 * u, p)
            }
            3 -> {
                c.drawCircle(cx - 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx + 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx, 86 * u, 2.5f * u, p)
            }
            else -> {
                path.reset()
                path.moveTo(cx - 9 * u, 76 * u); path.lineTo(cx + 9 * u, 76 * u); path.lineTo(cx, 90 * u); path.close()
                c.drawPath(path, p)
            }
        }
        if (waving) {
            val ang = Math.toRadians((-55 + sin(t * 2 * PI * 4) * 22).toDouble())
            val sx = cx + 20 * u
            val sy = 88 * u
            val hx = sx + (26 * u * cos(ang)).toFloat()
            val hy = sy + (26 * u * sin(ang)).toFloat()
            stroke(L.outfit, 6 * u)
            c.drawLine(sx, sy, hx, hy, p)
            fill(skin)
            c.drawCircle(hx, hy, 5 * u, p)
        }
    }

    private fun bangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 46 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 48 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 48 * u)
        path.lineTo(cx + 22 * u, 30 * u); path.lineTo(cx + 10 * u, 40 * u); path.lineTo(cx - 2 * u, 28 * u)
        path.lineTo(cx - 14 * u, 40 * u); path.lineTo(cx - 23 * u, 30 * u); path.close()
        c.drawPath(path, p)
    }

    private fun frontHair(c: Canvas, L: Look, u: Float, cx: Float) {
        if (L.kind == 1) {
            grad(L.hair, L.hairShade, 4 * u, 46 * u)
            path.reset()
            path.moveTo(cx - 30 * u, 46 * u); path.lineTo(cx - 34 * u, 20 * u); path.lineTo(cx - 20 * u, 28 * u)
            path.lineTo(cx - 18 * u, 6 * u); path.lineTo(cx - 6 * u, 22 * u); path.lineTo(cx + 2 * u, 4 * u)
            path.lineTo(cx + 10 * u, 22 * u); path.lineTo(cx + 22 * u, 8 * u); path.lineTo(cx + 24 * u, 28 * u)
            path.lineTo(cx + 36 * u, 22 * u); path.lineTo(cx + 30 * u, 46 * u)
            path.lineTo(cx + 22 * u, 34 * u); path.lineTo(cx + 8 * u, 42 * u); path.lineTo(cx - 4 * u, 32 * u)
            path.lineTo(cx - 16 * u, 42 * u); path.lineTo(cx - 24 * u, 34 * u); path.close()
            c.drawPath(path, p)
            return
        }
        bangs(c, L, u, cx)
        when (L.kind) {
            0 -> {
                stroke(L.outfit2, 3.5f * u)
                c.drawArc(RectF(cx - 31 * u, 14 * u, cx + 31 * u, 82 * u), 190f, 160f, false, p)
                fill(L.outfit2)
                c.drawRoundRect(RectF(cx - 37 * u, 42 * u, cx - 27 * u, 62 * u), 4 * u, 4 * u, p)
                c.drawRoundRect(RectF(cx + 27 * u, 42 * u, cx + 37 * u, 62 * u), 4 * u, 4 * u, p)
                fill(0xFF0F172A.toInt())
                c.drawCircle(cx - 32 * u, 52 * u, 2.5f * u, p)
                c.drawCircle(cx + 32 * u, 52 * u, 2.5f * u, p)
            }
            2 -> {
                fill(0xFF1E1B4B.toInt())
                c.drawOval(RectF(cx - 36 * u, 17 * u, cx + 36 * u, 28 * u), p)
                path.reset()
                path.moveTo(cx - 20 * u, 21 * u)
                path.quadTo(cx - 4 * u, 16 * u, cx + 10 * u, 4 * u)
                path.quadTo(cx + 14 * u, 14 * u, cx + 20 * u, 21 * u)
                path.close()
                c.drawPath(path, p)
                fill(L.outfit2)
                c.drawRect(cx - 20 * u, 17 * u, cx + 20 * u, 21 * u, p)
                spark(c, cx + 12 * u, 13 * u, 3.5f * u, 0xFFFDE047.toInt())
            }
            3 -> {
                fill(L.outfit2)
                c.drawCircle(cx - 26 * u, 22 * u, 3 * u, p)
                c.drawCircle(cx + 26 * u, 22 * u, 3 * u, p)
                spark(c, cx + 18 * u, 24 * u, 5 * u, 0xFFFDE047.toInt())
            }
            4 -> {
                for (s in intArrayOf(-1, 1)) {
                    grad(L.hair, L.hairShade, 3 * u, 28 * u)
                    path.reset()
                    path.moveTo(cx + s * 28 * u, 26 * u); path.lineTo(cx + s * 24 * u, 4 * u); path.lineTo(cx + s * 8 * u, 16 * u)
                    path.close()
                    c.drawPath(path, p)
                    fill(0xFFFFD1DC.toInt())
                    path.reset()
                    path.moveTo(cx + s * 24 * u, 21 * u); path.lineTo(cx + s * 22 * u, 10 * u); path.lineTo(cx + s * 14 * u, 17 * u)
                    path.close()
                    c.drawPath(path, p)
                }
            }
        }
    }

    private fun eyes(c: Canvas, L: Look, u: Float, cx: Float, m: String, blink: Float) {
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * 12 * u
            val ey = 51 * u
            when (m) {
                "happy" -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 200f, 140f, false, p)
                }
                "sleepy" -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 20f, 140f, false, p)
                }
                "love" -> heart(c, ex, ey, 7 * u, 0xFFFF4D8D.toInt())
                else -> {
                    val big = if (m == "surprised") 1.15f else 1f
                    c.save()
                    c.scale(1f, blink, ex, ey)
                    fill(Color.WHITE)
                    c.drawOval(RectF(ex - 8 * u * big, ey - 10 * u * big, ex + 8 * u * big, ey + 10 * u * big), p)
                    val ir = (if (m == "surprised") 5.2f else 6.6f) * u
                    fill(L.eye)
                    c.drawCircle(ex, ey, ir, p)
                    fill(0xFF111827.toInt())
                    c.drawCircle(ex, ey, ir * 0.5f, p)
                    fill(Color.WHITE)
                    c.drawCircle(ex - 2.5f * u, ey - 3f * u, 2.2f * u, p)
                    c.drawCircle(ex + 2.2f * u, ey + 2.5f * u, 1.1f * u, p)
                    c.restore()
                }
            }
        }
    }

    private fun brows(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "sad" -> {
                stroke(ink, 1.8f * u)
                c.drawLine(cx - 19 * u, 41 * u, cx - 7 * u, 37 * u, p)
                c.drawLine(cx + 7 * u, 37 * u, cx + 19 * u, 41 * u, p)
            }
            "angry" -> {
                stroke(ink, 2.2f * u)
                c.drawLine(cx - 19 * u, 36 * u, cx - 7 * u, 40 * u, p)
                c.drawLine(cx + 7 * u, 40 * u, cx + 19 * u, 36 * u, p)
            }
            "surprised" -> {
                stroke(ink, 1.8f * u)
                c.drawArc(RectF(cx - 19 * u, 31 * u, cx - 7 * u, 41 * u), 200f, 140f, false, p)
                c.drawArc(RectF(cx + 7 * u, 31 * u, cx + 19 * u, 41 * u), 200f, 140f, false, p)
            }
        }
    }

    private fun mouth(c: Canvas, u: Float, cx: Float, m: String, mo: Float) {
        if (mo > 0.05f) {
            fill(lip)
            c.drawOval(RectF(cx - 4.5f * u, 65 * u, cx + 4.5f * u, (66 + 7 * mo) * u), p)
            return
        }
        when (m) {
            "happy" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 7 * u, 58 * u, cx + 7 * u, 72 * u), 20f, 140f, false, p) }
            "sad" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 5 * u, 68 * u, cx + 5 * u, 78 * u), 200f, 140f, false, p) }
            "surprised" -> { fill(lip); c.drawOval(RectF(cx - 3.5f * u, 65 * u, cx + 3.5f * u, 73 * u), p) }
            "sleepy", "angry" -> { stroke(lip, 1.8f * u); c.drawLine(cx - 4 * u, 68 * u, cx + 4 * u, 68 * u, p) }
            else -> { stroke(lip, 1.6f * u); c.drawArc(RectF(cx - 5 * u, 62 * u, cx + 5 * u, 70 * u), 20f, 140f, false, p) }
        }
    }

    private fun extras(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "love" -> for (i in 0..2) {
                val ph = (t + i / 3f) % 1f
                val a = ((1f - ph) * 255).toInt()
                heart(c, cx + (i - 1) * 16 * u + sin(ph * 6.28f) * 3 * u, 30 * u - ph * 26 * u, (3 + 2 * (1 - ph)) * u, Color.argb(a, 255, 77, 141))
            }
            "happy" -> {
                val a = (abs(sin(t * 2 * PI * 2)) * 255).toInt()
                spark(c, cx - 38 * u, 30 * u, 4 * u, Color.argb(a, 255, 220, 100))
                spark(c, cx + 38 * u, 58 * u, 3 * u, Color.argb(a, 255, 220, 100))
            }
            "sad" -> {
                val ph = (t * 2) % 1f
                fill(0xCC60A5FA.toInt())
                c.drawCircle(cx - 16 * u, (58 + ph * 14) * u, 1.8f * u, p)
            }
            "sleepy" -> {
                val ph = t % 1f
                val a = ((1f - ph) * 255).toInt()
                fill(Color.argb(a, 147, 197, 253))
                p.textSize = 9 * u
                c.drawText("z", cx + 26 * u + ph * 6 * u, 24 * u - ph * 10 * u, p)
                p.textSize = 12 * u
                c.drawText("Z", cx + 32 * u + ph * 4 * u, 16 * u - ph * 8 * u, p)
            }
            "surprised" -> {
                fill(0xFFEF4444.toInt())
                p.textSize = 14 * u
                p.isFakeBoldText = true
                c.drawText("!", cx + 30 * u, 22 * u, p)
                p.isFakeBoldText = false
            }
            "angry" -> {
                stroke(0xFFEF4444.toInt(), 2f * u)
                c.drawLine(cx + 24 * u, 16 * u, cx + 32 * u, 24 * u, p)
                c.drawLine(cx + 32 * u, 16 * u, cx + 24 * u, 24 * u, p)
            }
        }
    }
}
