package com.zara.floatai

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * Do engine: Phone voice (TTS, offline) ya ElevenLabs (natural, internet + key).
 * ElevenLabs fail ho toh apne aap phone voice par wapas.
 */
class Voice(
    private val ctx: Context,
    private val onSpeaking: (Boolean) -> Unit,
    private val onNote: ((String) -> Unit)? = null
) : TextToSpeech.OnInitListener {
    companion object {
        val names = listOf(
            "1. Didi Meethi (F)", "2. Chulbuli (F)", "3. Shant Sakhi (F)", "4. Anime Idol (F)", "5. Komal Pari (F)",
            "6. Filmy Heroine (F)", "7. Teacher Madam (F)", "8. Masoom Bachchi (F)", "9. Raat Ki Rani (F)", "10. Dosti Wali (F)",
            "11. Sharmili (F)", "12. Boss Lady (F)", "13. Neend Wali (F)", "14. Josh Girl (F)", "15. Dadi Maa (F)",
            "16. Sapno Ki Pari (F)", "17. Hero Bhaiya (M)", "18. Gambhir Sahab (M)", "19. Dost Yaar (M)", "20. Kishor Boy (M)"
        )
        private val pitch = floatArrayOf(
            1.35f, 1.5f, 1.1f, 1.55f, 1.6f, 1.25f, 1.0f, 1.6f, 0.9f, 1.3f,
            1.45f, 1.05f, 1.2f, 1.4f, 0.85f, 1.5f, 0.85f, 0.65f, 0.95f, 1.1f
        )
        private val rate = floatArrayOf(
            0.95f, 1.1f, 0.85f, 1.05f, 0.92f, 1.0f, 0.88f, 1.12f, 0.82f, 1.05f,
            0.88f, 1.05f, 0.8f, 1.12f, 0.85f, 0.9f, 1.0f, 0.88f, 1.08f, 1.12f
        )
    }

    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(ctx, this)
    private var ready = false
    private var pending: Pair<String, String>? = null
    private var lastId = ""
    private var player: MediaPlayer? = null

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ready = true
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { h.post { onSpeaking(true) } }
            override fun onDone(id: String?) { if (id == lastId) h.post { onSpeaking(false) } }
            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(id: String?) { h.post { onSpeaking(false) } }
        })
        pending?.let { speakPhone(it.first, it.second) }
        pending = null
    }

    fun speak(text: String, mood: String = "neutral") {
        val key = Prefs.get(ctx, "el_key").trim()
        val vid = Prefs.get(ctx, "el_voice").trim()
        if (Prefs.get(ctx, "tts_engine", "phone") == "eleven" && key.isNotEmpty() && vid.isNotEmpty()) {
            speakEleven(key, vid, text, mood)
        } else {
            speakPhone(text, mood)
        }
    }

    private fun speakEleven(key: String, vid: String, text: String, mood: String) {
        val model = Prefs.get(ctx, "el_model").trim()
        Thread {
            try {
                val audio = Eleven.tts(key, vid, model, text, mood)
                val f = File(ctx.cacheDir, "tts_" + System.nanoTime() + ".mp3")
                f.writeBytes(audio)
                h.post { play(f) }
            } catch (e: Exception) {
                h.post {
                    onNote?.invoke("ElevenLabs: " + Eleven.friendly(e) + " (phone voice use ho rahi hai)")
                    speakPhone(text, mood)
                }
            }
        }.start()
    }

    private fun play(f: File) {
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { onSpeaking(false); try { f.delete() } catch (e: Exception) {} }
            mp.setOnErrorListener { _, _, _ -> onSpeaking(false); true }
            mp.prepare()
            mp.start()
            onSpeaking(true)
        } catch (e: Exception) {
            onSpeaking(false)
        }
    }

    private fun speakPhone(text: String, mood: String) {
        val e = tts
        if (!ready || e == null) { pending = Pair(text, mood); return }
        val v = Prefs.geti(ctx, "voice").coerceIn(0, names.size - 1)
        val loc = Locale.forLanguageTag(Prefs.get(ctx, "lang", "hi-IN"))
        e.language = loc
        val vs = e.voices?.filter { it.locale.language == loc.language && !it.isNetworkConnectionRequired }?.sortedBy { it.name }
        if (!vs.isNullOrEmpty()) e.voice = vs[(v * 3 + 1) % vs.size]

        var pm = 1f
        var rm = 1f
        when (mood) {
            "happy", "wink" -> { pm = 1.08f; rm = 1.05f }
            "excited" -> { pm = 1.15f; rm = 1.15f }
            "sad", "cry" -> { pm = 0.9f; rm = 0.85f }
            "shy" -> { pm = 1.05f; rm = 0.9f }
            "angry" -> { pm = 0.95f; rm = 1.12f }
            "sleepy" -> { pm = 0.9f; rm = 0.75f }
            "love" -> { pm = 1.05f; rm = 0.92f }
            "surprised" -> { pm = 1.12f; rm = 1.1f }
            "thinking" -> { pm = 0.98f; rm = 0.9f }
        }

        val parts = text.split(Regex("(?<=[.!?\u0964])\\s+")).filter { it.isNotBlank() }
        if (parts.isEmpty()) return
        lastId = "u" + (parts.size - 1)
        for (i in parts.indices) {
            val jp = 0.97f + Math.random().toFloat() * 0.06f
            val jr = 0.97f + Math.random().toFloat() * 0.06f
            e.setPitch((pitch[v] * pm * jp).coerceIn(0.5f, 2.0f))
            e.setSpeechRate((rate[v] * rm * jr).coerceIn(0.5f, 2.0f))
            e.speak(parts[i], if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u$i")
            if (i < parts.size - 1) e.playSilentUtterance(170, TextToSpeech.QUEUE_ADD, "s$i")
        }
    }

    fun stop() {
        tts?.stop()
        try { player?.release() } catch (e: Exception) {}
        player = null
        onSpeaking(false)
    }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null
        try { player?.release() } catch (e: Exception) {}
        player = null
    }
}
