package com.zara.floatai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Volume + aur - ek saath dabane par Zara ko bulata hai (Accessibility me ON karna padta hai). */
class VolumeService : AccessibilityService() {
    private var upDown = false
    private var downDown = false
    private var last = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = down else downDown = down
        if (down && upDown && downDown) {
            val now = SystemClock.uptimeMillis()
            if (now - last > 1500) {
                last = now
                trigger()
            }
            return true
        }
        return false
    }

    private fun trigger() {
        try {
            if (FloatingService.running) {
                startForegroundService(Intent(this, FloatingService::class.java).setAction("wake"))
            } else {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            } catch (e2: Exception) {
            }
        }
    }
}
