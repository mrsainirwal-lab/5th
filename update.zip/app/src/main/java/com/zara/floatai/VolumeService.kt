package com.zara.floatai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Sai AI Voice Control (Accessibility):
 * - Volume + aur - ek saath dabane par Sai AI aati hai
 * - Voice commands: back/home/recents, scroll, tap on text, type, screenshot
 * - Screen ka text padhna (jab tum "is page me ... kahan hai" jaisa poochho)
 */
class VolumeService : AccessibilityService() {
    companion object {
        @Volatile var instance: VolumeService? = null

        fun foregroundPkg(): String? = try { instance?.rootInActiveWindow?.packageName?.toString() } catch (e: Exception) { null }

        fun screenLines(): List<String>? {
            val s = instance ?: return null
            return try { s.readScreen() } catch (e: Exception) { emptyList() }
        }
    }

    private var upDown = false
    private var downDown = false
    private var last = 0L

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = down else downDown = down
        if (down && upDown && downDown) {
            val now = SystemClock.uptimeMillis()
            if (now - last > 1500) {
                last = now
                trigger()
            }
            return true
        }
        return false
    }

    private fun trigger() {
        try {
            if (FloatingService.running) {
                startForegroundService(Intent(this, FloatingService::class.java).setAction("wake"))
            } else {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            } catch (e2: Exception) {
            }
        }
    }

    // ---------------- screen reading ----------------
    private fun collect(n: AccessibilityNodeInfo?, out: ArrayList<Triple<Int, Int, String>>, depth: Int) {
        if (n == null || depth > 40 || out.size > 600) return
        val t = n.text?.toString() ?: n.contentDescription?.toString()
        if (!t.isNullOrBlank() && n.isVisibleToUser) {
            val r = Rect()
            n.getBoundsInScreen(r)
            out.add(Triple(r.top, r.left, t.trim()))
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    fun readScreen(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val items = ArrayList<Triple<Int, Int, String>>()
        collect(root, items, 0)
        items.sortWith(compareBy<Triple<Int, Int, String>>({ it.first / 14 }, { it.second }))
        val out = ArrayList<String>()
        for (it in items) {
            if (out.isEmpty() || out[out.size - 1] != it.third) out.add(it.third)
            if (out.size >= 400) break
        }
        return out
    }

    // ---------------- actions ----------------
    fun global(action: Int): Boolean = performGlobalAction(action)

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val list = root.findAccessibilityNodeInfosByText(t)
        for (n in list) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 30) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i), depth + 1)
            if (r != null) return r
        }
        return null
    }

    /** Quick Settings kholo, phir text (jaise "Wi-Fi", "Bluetooth") wale tile par tap karo. */
    fun openQuickSettingsAndTap(label: String, want: Boolean): Boolean {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        val key = if (label.lowercase().contains("bluetooth")) "bluetooth" else "wi-fi"
        val tryTap = Runnable {}
        for (attempt in 0 until 6) {
            try { Thread.sleep(350) } catch (e: Exception) {}
            val root = rootInActiveWindow ?: continue
            val nodes = root.findAccessibilityNodeInfosByText(key) + root.findAccessibilityNodeInfosByText(if (key == "wi-fi") "wifi" else key)
            for (n in nodes) {
                var x: AccessibilityNodeInfo? = n
                while (x != null && !x.isClickable) x = x.parent
                if (x != null) {
                    val state = x.isChecked
                    if (state != want) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
            }
        }
        return false
    }

    fun scroll(forward: Boolean): Boolean {
        val s = findScrollable(rootInActiveWindow, 0)
        if (s != null && s.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val path = Path()
        if (forward) { path.moveTo(w / 2, h * 0.72f); path.lineTo(w / 2, h * 0.28f) }
        else { path.moveTo(w / 2, h * 0.28f); path.lineTo(w / 2, h * 0.72f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 320)).build()
        return dispatchGesture(g, null, null)
    }
}
