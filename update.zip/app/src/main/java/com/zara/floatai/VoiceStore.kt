package com.zara.floatai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** provider: "phone" | "eleven" | "fish". id = ElevenLabs ya Fish voice ID. */
class VEntry(val name: String, val provider: String, val id: String, val pitch: Float, val rate: Float) {
    val eleven: Boolean get() = provider == "eleven"
}

object VoiceStore {
    private const val KEY = "voices_v3"
    const val FISH_DEFAULT_ID = "d13f84b987ad4f22b56d2b47f4eb838e"

    private fun defaults(): List<VEntry> {
        val out = ArrayList<VEntry>()
        out.add(VEntry("Fish Default", "fish", FISH_DEFAULT_ID, 1f, 1f))
        out.add(VEntry("Sweet (phone F)", "phone", "", 1.3f, 0.95f))
        out.add(VEntry("Calm (phone F)", "phone", "", 1.05f, 0.85f))
        out.add(VEntry("Deep (phone M)", "phone", "", 0.7f, 0.9f))
        val ids = listOf("F8IvasoAdpDhOjLm5YBm", "7PoJrtDD6yvTa56HTDt1", "kqVT88a5QfII1HNAEPTJ", "FF7KdobWPaiR0vkcALHF", "qNkzaJoHLLdpvgh5tISm",
            "6RDBmepnHSilYYdPZC4W", "JBLmavSCXG2kfzrhnYGg", "jUjRbhZWoMK4aDciW36V", "5mnzuCX5VBUY3U7RY1pn")
        val nums = listOf(1, 2, 3, 4, 5, 6, 7, 9, 10)
        for (i in ids.indices) out.add(VEntry("Voice " + nums[i], "eleven", ids[i], 1f, 1f))
        return out
    }

    /** ID ki shape se provider: 32 hex = Fish, warna ElevenLabs. */
    fun providerFor(id: String): String = when {
        id.isEmpty() -> "phone"
        id.length == 32 && id.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' } -> "fish"
        else -> "eleven"
    }

    private fun save(c: Context, list: List<VEntry>) {
        val arr = JSONArray()
        for (e in list) arr.put(JSONObject().put("n", e.name).put("v", e.provider).put("i", e.id).put("p", e.pitch.toDouble()).put("r", e.rate.toDouble()))
        Prefs.put(c, KEY, arr.toString())
    }

    fun all(c: Context): List<VEntry> {
        val raw = Prefs.get(c, KEY)
        if (raw.isEmpty()) {
            val d = defaults()
            save(c, d)
            return d
        }
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<VEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val prov = o.optString("v").ifEmpty { if (o.optBoolean("e")) "eleven" else "phone" }
                out.add(VEntry(o.getString("n"), prov, o.optString("i"), o.optDouble("p", 1.0).toFloat(), o.optDouble("r", 1.0).toFloat()))
            }
            if (out.none { it.provider == "fish" && it.id == FISH_DEFAULT_ID }) {
                out.add(0, defaults()[0])
                save(c, out)
            }
            if (out.isEmpty()) defaults() else out
        } catch (e: Exception) {
            defaults()
        }
    }

    fun add(c: Context, e: VEntry) {
        val l = all(c).toMutableList()
        l.add(e)
        save(c, l)
    }

    fun delete(c: Context, i: Int): Boolean {
        val l = all(c).toMutableList()
        if (l.size <= 1 || i !in l.indices) return false
        val s = selected(c)
        l.removeAt(i)
        save(c, l)
        if (s == i || s >= l.size) select(c, 0) else if (s > i) select(c, s - 1)
        return true
    }

    fun selected(c: Context): Int = Prefs.geti(c, "voice_sel").coerceIn(0, maxOf(0, all(c).size - 1))
    fun select(c: Context, i: Int) = Prefs.puti(c, "voice_sel", i)

    fun current(c: Context): VEntry {
        val l = all(c)
        return l[selected(c).coerceIn(0, l.size - 1)]
    }

    fun next(c: Context): VEntry {
        val l = all(c)
        val n = (selected(c) + 1) % l.size
        select(c, n)
        return l[n]
    }
}
