package com.zara.floatai

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import java.util.Locale

/** Voice se phone control. Sirf tab chalta hai jab Settings me "Phone control ON" ho. */
object PhoneControl {
    private var pending: (() -> Reply)? = null
    private val main = Handler(Looper.getMainLooper())

    fun isScreenQuery(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        val where = listOf("is page", "iss page", "is screen", "iss screen", "screen par", "screen pe", "screen me", "page me", "page par", "page pe", "this page", "this screen", "on screen", "on the screen", "yahan par", "is app me")
        val what = listOf("dhund", "dhoond", "search", "find", "kahan", "kahaan", "kidhar", "kis line", "kaunsi line", "which line", "padh", "read", "bata", "summar", "meaning", "kya likha", "explain", "translate", "where", "screen padho", "ye kya likha")
        if (t.contains("screen padho") || t.contains("screen read") || t.contains("page padho")) return true
        return where.any { t.contains(it) } && what.any { t.contains(it) }
    }

    private fun needA11y() = Reply("Iske liye Accessibility me 'Sai AI Voice Control' ON karo.", "sad")

    private fun act(c: Context, f: (VolumeService) -> Unit): Boolean {
        val s = VolumeService.instance ?: return false
        main.post { try { f(s) } catch (e: Exception) { } }
        return true
    }

    private fun launch(c: Context, i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun findApp(c: Context, name0: String): Pair<String, String>? {
        val alias = mapOf("yt" to "youtube", "insta" to "instagram", "fb" to "facebook", "gpay" to "google pay", "whats app" to "whatsapp",
            "setting" to "settings", "gallery" to "photos", "clock" to "clock", "chrome browser" to "chrome")
        val name = (alias[name0.trim().lowercase()] ?: name0.trim().lowercase())
        if (name.isEmpty()) return null
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var best: Pair<String, String>? = null
        var bestScore = 0
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase()
            val score = when {
                l == name -> 100
                l.startsWith(name) -> 80
                l.contains(name) -> 60
                l.length >= 3 && name.contains(l) -> 40
                else -> 0
            }
            if (score > bestScore || (score == bestScore && score > 0 && label.length < (best?.first?.length ?: 999))) {
                best = Pair(label, ri.activityInfo.packageName)
                bestScore = score
            }
        }
        return best
    }

    private fun findNumber(c: Context, name: String): Pair<String, String>? {
        val n = name.trim()
        if (Regex("^[+\\d][\\d\\s-]{5,}$").matches(n)) return Pair(n, n.replace(" ", "").replace("-", ""))
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val cur = c.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%" + n + "%"), null
        ) ?: return null
        cur.use { if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1).replace(" ", "")) }
        return null
    }

    private fun torch(c: Context, on: Boolean): Boolean {
        return try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in cm.cameraIdList) {
                val has = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                if (has) { cm.setTorchMode(id, on); return true }
            }
            false
        } catch (e: Exception) {
            false
        }
    }

    fun handle(c: Context, raw: String): Reply? {
        if (Prefs.get(c, "phonectl", "0") != "1") return null
        val t = raw.lowercase(Locale.ROOT).trim()
        val tok = t.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }.toSet()
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun w(vararg k: String) = k.any { it in tok }

        val p = pending
        if (p != null) {
            pending = null
            if (w("haan", "han", "ha", "yes", "yep", "ok", "okay", "sure", "karo", "theek")) return p()
            if (w("na", "nahi", "no", "nope", "mat", "cancel", "ruko")) return Reply("Theek hai, cancel kar diya.", "neutral")
        }

        val blockedFg = VolumeService.foregroundPkg()?.let { it in Util.blocked(c) } ?: false
        if (blockedFg && Regex("^(click|tap|press|dabao|type|likho|write)\\b|scroll").containsMatchIn(t))
            return Reply("Ye app block list me hai, yahan main kuch nahi karungi.", "neutral")

        // ---- navigation ----
        if (has("piche jao", "peeche jao", "wapas jao", "go back", "back karo", "back jao", "back kar do"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }) Reply("Piche aa gayi.", "happy") else needA11y()
        if (has("home jao", "home screen", "go home", "home karo", "home par jao", "home pe jao"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }) Reply("Home par.", "happy") else needA11y()
        if (has("recent apps", "recents", "multitask"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }) Reply("Recent apps khol diye.", "happy") else needA11y()
        if (has("notification kholo", "notifications dikhao", "open notifications", "notification panel", "notifications kholo"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) }) Reply("Notifications khul gaye.", "happy") else needA11y()
        if (has("quick settings"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) }) Reply("Quick settings.", "happy") else needA11y()
        if (has("screenshot", "screen shot"))
            return if (act(c) { it.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) }) Reply("Screenshot le liya.", "wink") else needA11y()
        if (has("lock karo", "screen lock", "phone lock", "lock screen", "phone band karo")) {
            if (VolumeService.instance == null) return needA11y()
            pending = {
                act(c) { it.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) }
                Reply("Phone lock kar diya.", "sleepy")
            }
            return Reply("Phone lock kar du? Haan ya na bolo.", "thinking")
        }
        if (has("scroll down", "niche scroll", "neeche scroll", "scroll niche", "scroll neeche"))
            return if (act(c) { it.scroll(true) }) Reply("Scroll kar rahi hoon.", "happy") else needA11y()
        if (has("scroll up", "upar scroll", "scroll upar"))
            return if (act(c) { it.scroll(false) }) Reply("Upar scroll.", "happy") else needA11y()

        // ---- volume / torch ----
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (has("volume badhao", "volume up", "volume increase", "awaaz badhao", "volume zyada", "volume tez", "volume badha"))
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return Reply("Volume badha diya.", "happy") }
        if (has("volume ghatao", "volume down", "awaaz kam", "volume kam", "volume dheema", "volume decrease", "volume ghata"))
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return Reply("Volume kam kar diya.", "happy") }
        if (has("mute karo", "volume mute", "phone mute"))
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI); return Reply("Mute toggle kar diya.", "neutral") }
        if (has("torch", "flashlight", "flash light", "tarch")) {
            val off = w("off", "band", "bujha", "bujhao", "stop")
            val ok = torch(c, !off)
            return if (ok) Reply(if (off) "Torch band." else "Torch chalu!", "happy") else Reply("Torch nahi chal paayi.", "sad")
        }

        // ---- tap / type ----
        Regex("^(?:click|tap|press|dabao)\\s+(.+)$").find(t)?.let {
            val target = it.groupValues[1]
            return if (VolumeService.instance == null) needA11y()
            else if (act(c) { s -> s.clickText(target) }) Reply(target + " par tap kar rahi hoon.", "happy") else needA11y()
        }
        Regex("^(.+?)\\s+(?:par|pe)\\s+(?:click|tap|press|dabao)(?:\\s+karo|\\s+kar do)?$").find(t)?.let {
            val target = it.groupValues[1]
            return if (VolumeService.instance == null) needA11y()
            else if (act(c) { s -> s.clickText(target) }) Reply(target + " par tap kar rahi hoon.", "happy") else needA11y()
        }
        Regex("(?i)^(?:type|likho|likh do|write)\\s+(.+)$").find(raw.trim())?.let {
            val txt = it.groupValues[1]
            return if (VolumeService.instance == null) needA11y()
            else if (act(c) { s -> s.typeText(txt) }) Reply("Likh diya.", "happy") else needA11y()
        }

        // ---- alarm / timer ----
        if (w("alarm")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t)
            if (m != null) {
                var hr = m.groupValues[1].toInt()
                val mn = m.groupValues[2].toIntOrNull() ?: 0
                val pm = w("pm", "shaam", "sham", "raat", "dopahar", "evening", "night")
                val amm = w("am", "subah", "morning")
                if (pm && hr < 12) hr += 12
                if (amm && hr == 12) hr = 0
                val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hr).putExtra(AlarmClock.EXTRA_MINUTES, mn).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (launch(c, i)) Reply("Alarm set kar diya: " + hr + ":" + (if (mn < 10) "0" else "") + mn, "happy") else Reply("Alarm set nahi ho paaya.", "sad")
            }
        }
        if (w("timer")) {
            val m = Regex("(\\d+)\\s*(second|sec|minute|min|mins|ghanta|ghante|hour|hr)").find(t)
            if (m != null) {
                val n = m.groupValues[1].toInt()
                val unit = m.groupValues[2]
                val secs = if (unit.startsWith("sec") || unit == "second") n else if (unit.startsWith("min")) n * 60 else n * 3600
                val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (launch(c, i)) Reply("Timer chalu kar diya.", "happy") else Reply("Timer nahi laga.", "sad")
            }
        }

        // ---- call / sms ----
        val callM = Regex("^(?:call|phone)\\s+(?:to\\s+)?(.+?)(?:\\s+(?:karo|kar do|lagao))?$").find(t)
            ?: Regex("^(.+?)\\s+ko\\s+(?:call|phone)(?:\\s+karo|\\s+lagao|\\s+kar do)?$").find(t)
        if (callM != null) {
            val who = callM.groupValues[1]
            val num = findNumber(c, who) ?: return Reply("'" + who + "' ka number nahi mila. Contacts permission do ya number bolo.", "sad")
            pending = {
                val direct = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val i = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + num.second))
                if (launch(c, i)) Reply(num.first + " ko call laga rahi hoon.", "happy") else Reply("Call nahi lag paayi.", "sad")
            }
            return Reply(num.first + " ko call karun? Haan ya na bolo.", "thinking")
        }
        val smsM = Regex("^(?:message|sms|msg|text)\\s+(?:to\\s+)?(\\S+)\\s+(.+)$").find(t)
            ?: Regex("^(\\S+)\\s+ko\\s+(?:message|sms|msg)\\s+(?:karo|bhejo|kar do|likho)\\s*(.*)$").find(t)
        if (smsM != null) {
            val who = smsM.groupValues[1]
            val body = smsM.groupValues[2]
            val num = findNumber(c, who) ?: return Reply("'" + who + "' ka number nahi mila.", "sad")
            pending = {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + num.second)).putExtra("sms_body", body)
                if (launch(c, i)) Reply("Message taiyaar hai, bhejne ke liye send dabao.", "happy") else Reply("Message app nahi khula.", "sad")
            }
            return Reply(num.first + " ko message likhun: " + body + ". Haan ya na?", "thinking")
        }

        // ---- web / youtube / maps / settings ----
        Regex("^youtube\\s*(?:par|pe|me|mein)?\\s*(.+?)\\s*(?:chalao|play|search karo|dhundo|dikhao|lagao)?$").find(t)?.let {
            val q = it.groupValues[1]
            if (q.isNotEmpty()) return if (launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))))
                Reply("YouTube par " + q + " dhundh rahi hoon.", "happy") else Reply("YouTube nahi khula.", "sad")
        }
        Regex("^(?:navigate|directions?|rasta|route)\\s+(?:to|for)?\\s*(.+)$").find(t)?.let {
            return if (launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(it.groupValues[1])))))
                Reply("Map par " + it.groupValues[1] + " dikha rahi hoon.", "happy") else Reply("Maps nahi khula.", "sad")
        }
        Regex("^(.+?)\\s+ka\\s+rasta$").find(t)?.let {
            return if (launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(it.groupValues[1])))))
                Reply("Map par " + it.groupValues[1] + " dikha rahi hoon.", "happy") else Reply("Maps nahi khula.", "sad")
        }
        val sq = Regex("^(?:search|google|dhundo|dhoondo)\\s+(.+)$").find(t) ?: Regex("^(.+?)\\s+(?:search karo|google karo|dhundo)$").find(t)
        if (sq != null) {
            val q = sq.groupValues[1]
            return if (launch(c, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))) Reply(q + " search kar rahi hoon.", "happy") else Reply("Search nahi khula.", "sad")
        }
        Regex("^(?:spotify\\s+(?:par|pe)\\s+)?(.+?)\\s+(?:spotify\\s+)?(?:par|pe)\\s+(?:gaana\\s+)?(?:chalao|play|bajao)$").find(t)?.let {
            return ChainCommands.spotify(c, it.groupValues[1])
        }
        Regex("^(?:spotify\\s+(?:par|pe)\\s+|spotify\\s+)(?:gaana\\s+)?(.+?)(?:\\s+(?:chalao|play|bajao))?$").find(t)?.let {
            if (it.groupValues[1].isNotBlank()) return ChainCommands.spotify(c, it.groupValues[1])
        }
        Regex("^(?:wifi|wi-fi|wi fi)\\s+(on|off|chalu karo|band karo|on karo|off karo)$").find(t)?.let {
            val on = it.groupValues[1].contains("on") || it.groupValues[1].contains("chalu")
            return ChainCommands.toggle(c, "Wi-Fi", on)
        }
        Regex("^(?:bluetooth)\\s+(on|off|chalu karo|band karo|on karo|off karo)$").find(t)?.let {
            val on = it.groupValues[1].contains("on") || it.groupValues[1].contains("chalu")
            return ChainCommands.toggle(c, "Bluetooth", on)
        }
        Regex("^(wifi|wi-fi|wi fi|bluetooth)\\s+(.+)$").find(t)?.let {
            val what = if (it.groupValues[1] == "bluetooth") "Bluetooth" else "Wi-Fi"
            val rest = it.groupValues[2]
            if (rest.contains("on") || rest.contains("chalu") || rest.contains("shuru")) return ChainCommands.toggle(c, what, true)
            if (rest.contains("off") || rest.contains("band")) return ChainCommands.toggle(c, what, false)
        }
        Regex("^(?:is app me|app me|yahan|yaha)\\s+(?:search|dhundo|dhoondo|dhund)\\s+(?:karo\\s+)?(.+)$").find(t)?.let {
            val q = it.groupValues[1]
            return if (VolumeService.instance == null) needA11y()
            else if (act(c) { s -> s.typeText(q) }) Reply(q + " search box me likh diya.", "happy") else needA11y()
        }
        if (has("wifi settings", "wifi kholo")) return if (launch(c, Intent(Settings.ACTION_WIFI_SETTINGS))) Reply("Wifi settings.", "happy") else Reply("Settings nahi khuli.", "sad")
        if (has("bluetooth settings", "bluetooth kholo")) return if (launch(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))) Reply("Bluetooth settings.", "happy") else Reply("Settings nahi khuli.", "sad")

        // ---- open app ----
        val openM = Regex("^(?:open|launch|start|kholo|chalao)\\s+(.+)$").find(t)
            ?: Regex("^(.+?)\\s+(?:kholo|khol do|open karo|open kar do|chalao|chalu karo|start karo|open)$").find(t)
        if (openM != null) {
            val app = findApp(c, openM.groupValues[1])
            if (app != null) {
                if (app.second in Util.blocked(c)) return Reply(app.first + " block list me hai, isliye nahi khol rahi.", "neutral")
                val li = c.packageManager.getLaunchIntentForPackage(app.second)
                return if (li != null && launch(c, li)) Reply(app.first + " khol rahi hoon.", "happy") else Reply(app.first + " nahi khul paaya.", "sad")
            }
        }
        return null
    }
}
