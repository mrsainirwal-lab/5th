package com.zara.floatai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Do kaam karta hai (dono ke liye Settings > Accessibility > "Sai AI Control" ON karna zaroori hai):
 * 1) Volume + aur - ek saath dabane par Sai ko bulata hai.
 * 2) Basic phone control + "is page me <word> dhundo" / "kis line me hai" jaisi screen-reading commands,
 *    jo FloatingService/Brain is companion object ke through call karte hain.
 *
 * Limitation: ye sirf wahi text padh sakta hai jo screen par dikh raha hai (Accessibility node tree se),
 * aur sirf wahi actions kar sakta hai jo Android ki Accessibility API allow karti hai
 * (home/back/recents, app kholna, volume). Banking/payment jaise secure/protected apps me
 * Android khud hi accessibility access block kar deta hai — ye security ke liye hai, bug nahi.
 */
class VolumeService : AccessibilityService() {
    companion object {
        var instance: VolumeService? = null
    }

    private var upDown = false
    private var downDown = false
    private var last = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        serviceInfo = info
    }

    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------------- "Readable": screen par koi shabd dhundo, line number batao ----------------
    /** Current screen ki saari dikh rahi lines (top se bottom), ek list ki tarah. */
    fun screenLines(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = ArrayList<Pair<Int, String>>() // (y position, text) taaki top-to-bottom sort ho sake
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty()) {
                val r = android.graphics.Rect()
                n.getBoundsInScreen(r)
                out.add(Pair(r.top, t))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out.sortedBy { it.first }.map { it.second }.distinct()
    }

    /** "<word> is page me kis line me hai" ka jawab. Line number 1-based, user ko bolne layak text. */
    fun findLine(word: String): String {
        val w = word.trim().lowercase()
        if (w.isEmpty()) return "Kya dhundna hai, naam nahi bataya tumne."
        val lines = screenLines()
        if (lines.isEmpty()) return "Abhi screen par kuch padh nahi paa rahi, app khol ke rakho aur dobara bolo."
        val idx = lines.indexOfFirst { it.lowercase().contains(w) }
        return if (idx == -1) "\"$word\" is screen par mujhe dikh nahi raha."
        else "\"$word\" line number ${idx + 1} me hai: \"${lines[idx].take(60)}\""
    }

    // ---------------- Basic phone control ----------------
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun volume(up: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
    }

    /** Naam se app dhundke kholta hai (jaise "WhatsApp khol do"). true = mil gaya aur khol diya. */
    fun openAppByName(name: String): Boolean {
        val target = name.trim().lowercase()
        if (target.isEmpty()) return false
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(target) } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = down else downDown = down
        if (down && upDown && downDown) {
            val now = SystemClock.uptimeMillis()
            if (now - last > 1500) {
                last = now
                trigger()
            }
            return true
        }
        return false
    }

    private fun trigger() {
        try {
            if (FloatingService.running) {
                startForegroundService(Intent(this, FloatingService::class.java).setAction("wake"))
            } else {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            }
        } catch (e: Exception) {
            try {
                startActivity(Intent(this, WakeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            } catch (e2: Exception) {
            }
        }
    }
}
