# Is update me kya naya add hua (Hinglish)

1. **Gemini model**: ab `gemini-3.8-flash` pehle try hota hai (auto-selected), available na ho toh purane models par khud fallback ho jaata hai.
2. **ElevenLabs**: aapki di hui 9 voice IDs ek "Preset chuno" dropdown me already judi hain (Settings > Voice > ElevenLabs) — seedha chuno, account se load karne ki zaroorat nahi.
3. **Character "Maya"**: aapki transparent-background wali image ab app pehli baar khulte hi inbuilt default character hai (`app/src/main/assets/maya_default.png` se). "Jarvis" ke liye koi image nahi di gayi thi, isliye wo add nahi ho saka — ek image bhejo to wahi tarike se add ho jayega.
4. **App icon**: aapki background-wali image app ka launcher icon ban gayi hai.
5. **App ka naam**: "Sai AI" — ye is update.zip me pehle se theek tha, floating label aur accessibility service ka naam bhi ab "Sai AI Control" hai.
6. **Cherry blossom petals**: naya `Petals.kt`. Floating character ke piche (upar/baalon ke paas se shuru hoke niche fade) aur app ke andar bhi — dono jagah Settings > Extra Features me alag-alag ON/OFF switch.
7. **"Readable" (is page me X dhundo, kis line me hai)**: `Commands.kt` + `VolumeService.kt` (naam se mat jao, ye ab ek general Accessibility control service hai) — screen ka visible text padh ke line batata hai. Sirf wahi text padh sakta hai jo accessibility tree me dikh raha ho; secure/banking apps me Android khud hi block karta hai.
8. **Basic phone control (voice se)**: home jao / back jao / recent apps / notifications khol / volume badhao-kam karo / "<app name> khol do". Sab Settings > Accessibility > "Sai AI Control" ON karne ke baad hi kaam karta hai.
9. Settings screen me ab seedha "Accessibility settings kholo" button hai.

## Jo is update me nahi hai (scope se bahar)
- Full system-level control (calls karna, messages bhejna, settings badalna) — Android deliberately isko accessibility API se allow nahi karta, security ke liye.
- Real limb/eye movement image character par — ye ek static PNG hai, "movement" mesh-warp/breathing/sway/mouth-flash se simulate hota hai (pehle se CharacterView.kt me tha), asli bones/rig nahi.
- GitHub push — is zip ko khud apne repo me extract/commit karke push karna hoga.

## Build karne ka tareeka
Android Studio me `build/` folder open karo (ye poora Gradle project hai) ya GitHub repo me extract karke push karo, phir normal Android build/run.
