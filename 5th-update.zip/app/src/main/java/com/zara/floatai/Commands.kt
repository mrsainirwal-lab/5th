package com.zara.floatai

import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Bolkar diye kuch commands AI (Gemini/ChatGPT) ko bheje bina, seedhe handle hote hain:
 * - "is page me <word> dhundo" / "<word> kis line me hai" -> VolumeService se screen padh ke batata hai
 * - "home jao" / "back jao" / "recent apps" / "notification khol" -> basic navigation
 * - "<app name> khol do" -> installed app launch karta hai
 * - "volume badhao / kam karo" -> system volume
 *
 * In sabke liye Settings > Accessibility me "Sai AI Control" ON hona zaroori hai (VolumeService).
 * ON na ho toh user ko bata diya jaata hai, AI call nahi hoti.
 */
object Commands {
    private fun needAccessibility() =
        "Ye karne ke liye pehle Settings > Accessibility me \"Sai AI Control\" ON karo, phir dobara bolo."

    fun handle(c: Context, raw: String): String? {
        val t = raw.trim()
        val low = t.lowercase()
        val svc = VolumeService.instance

        // ---- Readable: find a word, tell the line ----
        Regex("(?i)(?:is page me |page me |yahan |screen par )?(.+?) (?:dhund|dhoond|dhundh)[a-z]* (?:raha|rahi)?\\s*(?:hu|hoon)?[,. ]*(?:bata|batao)?").find(low)
            ?.takeIf { low.contains("dhund") || low.contains("dhoond") }?.let {
                val word = it.groupValues[1].removePrefix("main ").removePrefix("mai ").trim()
                if (word.isNotBlank()) {
                    return svc?.findLine(word) ?: needAccessibility()
                }
            }
        Regex("(?i)(.+?) kis line me hai").find(low)?.let {
            return svc?.findLine(it.groupValues[1].trim()) ?: needAccessibility()
        }
        Regex("(?i)(.+?) kahan hai (?:is page|yahan|screen)").find(low)?.let {
            return svc?.findLine(it.groupValues[1].trim()) ?: needAccessibility()
        }

        // ---- Navigation ----
        if (Regex("(?i)\\bhome (?:jao|chalo|le chalo)\\b|\\bghar jao\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.goHome(); return "Theek hai, home."
        }
        if (Regex("(?i)\\bback (?:jao|chalo)\\b|\\bpeeche jao\\b|\\bpichla\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.goBack(); return "Theek hai, wapas."
        }
        if (Regex("(?i)\\brecent apps?\\b|\\bpichle apps?\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.recents(); return "Recent apps khol diye."
        }
        if (Regex("(?i)\\bnotification[s]? khol\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.notifications(); return "Notifications khol di."
        }

        // ---- Volume ----
        if (Regex("(?i)\\bvolume (?:badhao|tez karo|increase)\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.volume(true); return "Volume badha diya."
        }
        if (Regex("(?i)\\bvolume (?:kam karo|ghatao|decrease)\\b").containsMatchIn(low)) {
            if (svc == null) return needAccessibility()
            svc.volume(false); return "Volume kam kar diya."
        }

        // ---- Open app by name: "<naam> khol do" / "open <naam>" ----
        Regex("(?i)^(.+?) (?:khol do|khol de|khol|open karo)$").find(t)?.let { m ->
            val name = m.groupValues[1].trim()
            if (name.isNotBlank() && name.length < 30) {
                if (svc == null) return needAccessibility()
                return if (svc.openAppByName(name)) "$name khol di."
                else "Mujhe \"$name\" naam ka app nahi mila. Poora sahi naam bolo (jaise WhatsApp, Chrome)."
            }
        }
        Regex("(?i)^open (.+)$").find(t)?.let { m ->
            val name = m.groupValues[1].trim()
            if (svc == null) return needAccessibility()
            return if (svc.openAppByName(name)) "$name khol di."
            else "\"$name\" nahi mila."
        }

        return null // AI ko bhejo normal tareeke se
    }

    fun openAccessibilitySettings(c: Context) {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
