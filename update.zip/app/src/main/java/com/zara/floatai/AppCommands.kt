package com.zara.floatai

import android.content.Context
import java.util.Locale

/** App ke apne voice commands: mode (normal/beast), character badalna, voice badalna. Phone control band ho tab bhi chalte hain. */
object AppCommands {
    @Volatile var refreshChar = false

    fun handle(c: Context, raw: String): Reply? {
        val t = raw.lowercase(Locale.ROOT).trim()
        val tok = t.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        if (tok.size > 7) return null
        fun has(vararg k: String) = k.any { t.contains(it) }

        if (has("beast mode", "beast on", "beast ban", "beast moad", "beast ho ja")) {
            Prefs.put(c, "mode", "beast")
            return Reply("Beast mode on. Ab main sharp aur seedhi baat karungi, sab kuch dhyan se handle karungi.", "excited")
        }
        if (has("normal mode", "normal ho ja", "normal ban ja", "normal on", "normal moad")) {
            Prefs.put(c, "mode", "normal")
            return Reply("Normal mode on! Chalo ab aaram se, dosti wali baatein karte hain.", "happy")
        }
        val switchWords = has("switch", "change", "badlo", "ban ja", "bulao", "aao", "laao", "mode", "chahiye", "dikhao")
        if (switchWords && has("jarvis")) {
            Prefs.puti(c, "char", 1)
            refreshChar = true
            return Reply("Jarvis online. All systems ready, sir.", "excited")
        }
        if (switchWords && has("maya")) {
            Prefs.puti(c, "char", 0)
            refreshChar = true
            return Reply("Main wapas aa gayi! Maya here, hehe.", "happy")
        }
        if (has("agla character", "next character", "character badlo", "character change")) {
            val n = CharStore.entries(c).size
            Prefs.puti(c, "char", (Prefs.geti(c, "char") + 1) % n)
            refreshChar = true
            return Reply("Ye lo, naya character.", "wink")
        }
        if (has("voice badlo", "voice change", "next voice", "awaaz badlo")) {
            val v = VoiceStore.next(c)
            return Reply("Voice badal di: " + v.name + ". Kaisi lag rahi hai?", "happy")
        }
        return null
    }
}
