package com.zara.floatai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class Look(
    val name: String, val hair: Int, val hairShade: Int, val eye: Int,
    val outfit: Int, val outfit2: Int, val skin: Int,
    val kind: Int, val acc: Int, val cloth: Int, val persona: Int
)

/** 50 original anime-style characters, generated from combinations of hair, colors, accessories and outfits. */
object Looks {
    val titles = listOf("Bubbly", "Sharmili", "Tsundere", "Calm Didi", "Hyper", "Shararati", "Dreamy", "Cool", "Pyaari", "Nerdy")

    val personas = listOf(
        "bubbly, optimistic and cheerful; says things like 'arre wah' and 'yaay'",
        "shy and soft-spoken, a little stuttery ('u-um...'), blushes easily but is very sweet",
        "a tsundere: acts tough and teasing ('hmph') but secretly cares a lot",
        "a calm, caring elder-sister type who gives gentle advice",
        "super energetic and hyper, loves cheering the user on ('chalo chalo!')",
        "mischievous and playful, loves teasing and little jokes",
        "dreamy and poetic, speaks softly with pretty imagery",
        "cool with dry humor and short sentences, but very loyal",
        "very affectionate, worries about the user and uses their name often",
        "curious and nerdy, asks questions and shares fun facts"
    )

    private val names = listOf(
        "Mika", "Aoi", "Nyx", "Hikari", "Yuzu", "Sora", "Riko", "Hana", "Kaito", "Ren",
        "Miyu", "Yuna", "Akari", "Haru", "Nana", "Rina", "Kenji", "Tsubasa", "Emi", "Daichi",
        "Noa", "Mei", "Sota", "Ayame", "Koharu", "Rui", "Itsuki", "Chiyo", "Mizuki", "Shiori",
        "Toma", "Hotaru", "Sumire", "Kazuki", "Momo", "Yuki", "Reina", "Ayumi", "Leo", "Lumi",
        "Kiri", "Mari", "Shun", "Airi", "Zen", "Iris", "Luna", "Reo", "Saki", "Tomo"
    )

    private val hairs = listOf(
        0xFF22D3EE to 0xFF0E7490, 0xFF3B82F6 to 0xFF1D4ED8, 0xFF8B5CF6 to 0xFF5B21B6, 0xFFFDE68A to 0xFFF59E0B,
        0xFFFB923C to 0xFFEA580C, 0xFF2B2F55 to 0xFF1B1E3A, 0xFFE5E7EB to 0xFF9CA3AF, 0xFF34D399 to 0xFF047857,
        0xFFF87171 to 0xFFB91C1C, 0xFFA16207 to 0xFF713F12, 0xFFF472B6 to 0xFFBE185D, 0xFFA3E635 to 0xFF4D7C0F
    )
    private val eyes = listOf(
        0xFF8B5CF6, 0xFFFBBF24, 0xFFF43F5E, 0xFF38BDF8, 0xFF14B8A6, 0xFFFB923C, 0xFF3B82F6, 0xFFD946EF, 0xFF0EA5E9
    )
    private val outfits = listOf(
        0xFF1E1B4B to 0xFF22D3EE, 0xFF111827 to 0xFFEF4444, 0xFF18181B to 0xFFA855F7, 0xFFFFFFFF to 0xFFFB7185,
        0xFFFEF3C7 to 0xFFDC2626, 0xFF0F766E to 0xFFFDE047, 0xFF7C2D12 to 0xFFFBBF24, 0xFF1D4ED8 to 0xFFFFFFFF,
        0xFFBE185D to 0xFFFFE4E6, 0xFF334155 to 0xFF38BDF8
    )
    private val skins = listOf(0xFFFFE4D2, 0xFFF8D5B8, 0xFFEBC3A0)

    val all: List<Look> = List(50) { i ->
        val h = hairs[i % 12]
        val o = outfits[(i * 3 + i / 7) % outfits.size]
        Look(
            names[i], h.first.toInt(), h.second.toInt(), eyes[(i * 3 + 1) % eyes.size].toInt(),
            o.first.toInt(), o.second.toInt(), skins[i % 3].toInt(),
            i % 10, (i * 3 + i / 10) % 10, (i / 2) % 5, (i * 7) % 10
        )
    }
}

/**
 * Original anime-style characters drawn in code.
 * Moods: neutral, happy, sad, surprised, love, sleepy, angry, shy, excited, thinking, wink, cry.
 * Hair/accessories sway with a spring physics when the window is dragged (nudge).
 */
class CharacterView(ctx: Context) : View(ctx) {
    var style = 0
        set(v) { field = v.coerceIn(0, Looks.all.size - 1); invalidate() }
    var mood = "neutral"
    var speaking = false
    var listening = false
    var waving = false
    var sleeping = false

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f
    private var physA = 0f
    private var physV = 0f
    private var lastMs = SystemClock.uptimeMillis()
    private var hopStart = 0L
    private val ink = 0xFF3F3F46.toInt()
    private val lip = 0xFFB5334F.toInt()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    /** Window drag ke waqt call karo: dx = window ka horizontal move (px). Hair opposite side me jhoolte hain. */
    fun nudge(dx: Float) { physV = (physV - dx * 3f).coerceIn(-700f, 700f) }
    fun hop() { hopStart = SystemClock.uptimeMillis() }

    private fun fill(col: Int) { p.shader = null; p.style = Paint.Style.FILL; p.color = col }
    private fun grad(c1: Int, c2: Int, y0: Float, y1: Float) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, y0, 0f, y1, c1, c2, Shader.TileMode.CLAMP)
    }
    private fun stroke(col: Int, wd: Float) {
        p.shader = null; p.style = Paint.Style.STROKE; p.color = col; p.strokeWidth = wd; p.strokeCap = Paint.Cap.ROUND
    }

    private fun heart(c: Canvas, x: Float, y: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(x, y + s * 0.35f)
        path.cubicTo(x - s, y - s * 0.3f, x - s * 0.5f, y - s * 1.1f, x, y - s * 0.45f)
        path.cubicTo(x + s * 0.5f, y - s * 1.1f, x + s, y - s * 0.3f, x, y + s * 0.35f)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    private fun spark(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(x, y - r)
        path.quadTo(x, y, x + r, y)
        path.quadTo(x, y, x, y + r)
        path.quadTo(x, y, x - r, y)
        path.quadTo(x, y, x, y - r)
        path.close()
        fill(col)
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val L = Looks.all[style]
        val u = width / 100f
        val cx = width / 2f
        val now = SystemClock.uptimeMillis()
        var dt = (now - lastMs) / 1000f
        lastMs = now
        if (dt > 0.05f) dt = 0.05f
        physV += (-140f * physA - 8f * physV) * dt
        physA = (physA + physV * dt).coerceIn(-40f, 40f)

        val m = if (sleeping) "sleepy" else mood
        val sway = sin(t * 2 * PI).toFloat()
        var bob = sway * 2.5f * u * (if (m == "sleepy") 0.4f else 1f)
        if (m == "excited") bob -= abs(sin(t * 2 * PI * 2)).toFloat() * 3f * u
        val hp = (now - hopStart) / 700f
        if (hp in 0f..1f) bob -= abs(sin(hp * PI * 2)).toFloat() * 9f * u
        val blink = if (m == "sleepy" || m == "happy" || m == "love" || m == "excited") 1f
            else if (t > 0.93f || (t > 0.45f && t < 0.48f)) 0.1f else 1f
        val mo = if (speaking) abs(sin(t * 2 * PI * 6)).toFloat() else 0f
        val lt = now / 1000f
        val gx = sin(lt * 0.7f) * 1.5f * u
        val gy = sin(lt * 0.5f + 1f) * 0.8f * u

        c.save()
        c.translate(0f, bob)
        if (listening) {
            stroke(0xAAFF4081.toInt(), 2.5f * u)
            c.drawCircle(cx, 48 * u, (33 + 4 * abs(sin(t * 2 * PI * 2)).toFloat()) * u, p)
        }
        c.save()
        c.rotate(physA * 0.5f, cx, 24 * u)
        backHair(c, L, u, cx, sway)
        c.restore()
        body(c, L, u, cx)
        fill(L.skin)
        c.drawCircle(cx, 48 * u, 28 * u, p)
        fill(0x1A7C5A4A.toInt())
        c.drawOval(RectF(cx - 24 * u, 36 * u, cx + 24 * u, 46 * u), p)
        c.save()
        c.translate(-physA * 0.05f * u, 0f)
        frontHair(c, L, u, cx, sway)
        stroke(0x55FFFFFF.toInt(), 2.2f * u)
        c.drawArc(RectF(cx - 22 * u, 16 * u, cx + 4 * u, 34 * u), 200f, 70f, false, p)
        c.restore()
        eyes(c, L, u, cx, m, blink, gx, gy)
        if (L.acc == 9) glasses(c, u, cx)
        brows(c, u, cx, m)
        fill(when (m) { "shy" -> 0xBBFF6B8A.toInt(); "love" -> 0x99FF6B8A.toInt(); else -> 0x55FF6B8A.toInt() })
        c.drawCircle(cx - 18 * u, 62 * u, 4 * u, p)
        c.drawCircle(cx + 18 * u, 62 * u, 4 * u, p)
        mouth(c, u, cx, m, mo)
        extras(c, u, cx, m)
        c.restore()
    }

    // ---------------- hair ----------------
    private fun hairBlock(c: Canvas, L: Look, u: Float, cx: Float, top: Float, bottom: Float, half: Float, r: Float) {
        grad(L.hair, L.hairShade, top * u, bottom * u)
        c.drawRoundRect(RectF(cx - half * u, top * u, cx + half * u, bottom * u), r * u, r * u, p)
    }

    private fun tail(c: Canvas, L: Look, u: Float, rootX: Float, rootY: Float, len: Float, w: Float, ang: Float) {
        c.save()
        c.rotate(ang, rootX, rootY * u)
        grad(L.hair, L.hairShade, rootY * u, (rootY + len) * u)
        c.drawRoundRect(RectF(rootX - w * u / 2, rootY * u, rootX + w * u / 2, (rootY + len) * u), w * u / 2, w * u / 2, p)
        c.restore()
    }

    private fun backHair(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.kind) {
            0 -> {
                tail(c, L, u, cx - 30 * u, 30f, 78f, 20f, sway * 3f + physA * 1.2f)
                tail(c, L, u, cx + 30 * u, 30f, 78f, 20f, sway * 3f + physA * 1.2f)
                hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
            }
            1 -> hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
            2 -> hairBlock(c, L, u, cx, 12f, 114f, 35f, 30f)
            3 -> {
                hairBlock(c, L, u, cx, 14f, 84f, 33f, 30f)
                grad(L.hair, L.hairShade, 4 * u, 24 * u)
                c.drawCircle(cx - 26 * u, 14 * u, 10 * u, p)
                c.drawCircle(cx + 26 * u, 14 * u, 10 * u, p)
            }
            4 -> hairBlock(c, L, u, cx, 14f, 80f, 33f, 30f)
            5 -> {
                hairBlock(c, L, u, cx, 12f, 70f, 32f, 28f)
                tail(c, L, u, cx + 24 * u, 24f, 72f, 14f, -physA * 1.3f + sway * 4f)
            }
            6 -> hairBlock(c, L, u, cx, 12f, 64f, 32f, 28f)
            7 -> hairBlock(c, L, u, cx, 12f, 112f, 35f, 30f)
            8 -> hairBlock(c, L, u, cx, 12f, 62f, 32f, 28f)
            else -> {
                hairBlock(c, L, u, cx, 12f, 66f, 32f, 28f)
                tail(c, L, u, cx - 35 * u, 56f, 38f, 14f, sway * 4f + physA * 1.1f)
                tail(c, L, u, cx + 35 * u, 56f, 38f, 14f, sway * 4f + physA * 1.1f)
            }
        }
    }

    private fun bangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 46 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 48 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 48 * u)
        path.lineTo(cx + 22 * u, 30 * u); path.lineTo(cx + 10 * u, 40 * u); path.lineTo(cx - 2 * u, 28 * u)
        path.lineTo(cx - 14 * u, 40 * u); path.lineTo(cx - 23 * u, 30 * u); path.close()
        c.drawPath(path, p)
    }

    private fun shortBangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 40 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 46 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 46 * u)
        path.lineTo(cx + 24 * u, 26 * u); path.lineTo(cx + 12 * u, 34 * u); path.lineTo(cx, 24 * u)
        path.lineTo(cx - 12 * u, 34 * u); path.lineTo(cx - 24 * u, 26 * u); path.close()
        c.drawPath(path, p)
    }

    private fun sideBangs(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 10 * u, 52 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 52 * u)
        path.quadTo(cx - 30 * u, 13 * u, cx, 13 * u)
        path.quadTo(cx + 30 * u, 13 * u, cx + 30 * u, 46 * u)
        path.lineTo(cx + 20 * u, 33 * u)
        path.quadTo(cx + 4 * u, 46 * u, cx - 14 * u, 30 * u)
        path.quadTo(cx - 22 * u, 42 * u, cx - 30 * u, 52 * u)
        path.close()
        c.drawPath(path, p)
    }

    private fun spiky(c: Canvas, L: Look, u: Float, cx: Float) {
        grad(L.hair, L.hairShade, 4 * u, 46 * u)
        path.reset()
        path.moveTo(cx - 30 * u, 46 * u); path.lineTo(cx - 34 * u, 20 * u); path.lineTo(cx - 20 * u, 28 * u)
        path.lineTo(cx - 18 * u, 6 * u); path.lineTo(cx - 6 * u, 22 * u); path.lineTo(cx + 2 * u, 4 * u)
        path.lineTo(cx + 10 * u, 22 * u); path.lineTo(cx + 22 * u, 8 * u); path.lineTo(cx + 24 * u, 28 * u)
        path.lineTo(cx + 36 * u, 22 * u); path.lineTo(cx + 30 * u, 46 * u)
        path.lineTo(cx + 22 * u, 34 * u); path.lineTo(cx + 8 * u, 42 * u); path.lineTo(cx - 4 * u, 32 * u)
        path.lineTo(cx - 16 * u, 42 * u); path.lineTo(cx - 24 * u, 34 * u); path.close()
        c.drawPath(path, p)
    }

    private fun frontHair(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.kind) {
            1 -> spiky(c, L, u, cx)
            6 -> {
                shortBangs(c, L, u, cx)
                c.save()
                c.rotate(physA * 1.5f + sway * 3f, cx, 14 * u)
                stroke(L.hair, 2.6f * u)
                path.reset()
                path.moveTo(cx, 15 * u)
                path.quadTo(cx + 4 * u, 6 * u, cx + 10 * u, 8 * u)
                c.drawPath(path, p)
                c.restore()
            }
            8 -> shortBangs(c, L, u, cx)
            7 -> sideBangs(c, L, u, cx)
            else -> bangs(c, L, u, cx)
        }
        accessory(c, L, u, cx, sway)
    }

    private fun accessory(c: Canvas, L: Look, u: Float, cx: Float, sway: Float) {
        when (L.acc) {
            1 -> {
                stroke(L.outfit2, 3.5f * u)
                c.drawArc(RectF(cx - 31 * u, 14 * u, cx + 31 * u, 82 * u), 190f, 160f, false, p)
                fill(L.outfit2)
                c.drawRoundRect(RectF(cx - 37 * u, 42 * u, cx - 27 * u, 62 * u), 4 * u, 4 * u, p)
                c.drawRoundRect(RectF(cx + 27 * u, 42 * u, cx + 37 * u, 62 * u), 4 * u, 4 * u, p)
                fill(0xFF0F172A.toInt())
                c.drawCircle(cx - 32 * u, 52 * u, 2.5f * u, p)
                c.drawCircle(cx + 32 * u, 52 * u, 2.5f * u, p)
            }
            2 -> {
                c.save()
                c.rotate(physA * 0.4f, cx, 22 * u)
                for (s in intArrayOf(-1, 1)) {
                    fill(L.hairShade)
                    path.reset()
                    path.moveTo(cx + s * 27 * u, 24 * u); path.lineTo(cx + s * 27 * u, 3 * u); path.lineTo(cx + s * 9 * u, 15 * u)
                    path.close()
                    c.drawPath(path, p)
                    fill(0xFFFFB6C9.toInt())
                    path.reset()
                    path.moveTo(cx + s * 24 * u, 19 * u); path.lineTo(cx + s * 24 * u, 8 * u); path.lineTo(cx + s * 15 * u, 15 * u)
                    path.close()
                    c.drawPath(path, p)
                }
                c.restore()
            }
            3 -> {
                for (s in intArrayOf(-1, 1)) {
                    grad(L.hair, L.hairShade, 3 * u, 28 * u)
                    path.reset()
                    path.moveTo(cx + s * 28 * u, 26 * u); path.lineTo(cx + s * 24 * u, 4 * u); path.lineTo(cx + s * 8 * u, 16 * u)
                    path.close()
                    c.drawPath(path, p)
                    fill(0xFFFFD1DC.toInt())
                    path.reset()
                    path.moveTo(cx + s * 24 * u, 21 * u); path.lineTo(cx + s * 22 * u, 10 * u); path.lineTo(cx + s * 14 * u, 17 * u)
                    path.close()
                    c.drawPath(path, p)
                }
            }
            4 -> {
                fill(0xFFFF3B5C.toInt())
                val x = cx - 22 * u
                val y = 20 * u
                path.reset(); path.moveTo(x, y); path.lineTo(x - 10 * u, y - 7 * u); path.lineTo(x - 10 * u, y + 7 * u); path.close()
                c.drawPath(path, p)
                path.reset(); path.moveTo(x, y); path.lineTo(x + 10 * u, y - 7 * u); path.lineTo(x + 10 * u, y + 7 * u); path.close()
                c.drawPath(path, p)
                c.drawCircle(x, y, 3 * u, p)
            }
            5 -> {
                spark(c, cx + 18 * u, 24 * u, 5 * u, 0xFFFDE047.toInt())
                spark(c, cx - 20 * u, 22 * u, 3 * u, 0xFFFFFFFF.toInt())
            }
            6 -> {
                val x = cx + 20 * u
                val y = 20 * u
                fill(0xFFFFFFFF.toInt())
                for (i in 0 until 5) {
                    val a = i * 2 * PI / 5
                    c.drawCircle(x + (5 * u * cos(a)).toFloat(), y + (5 * u * sin(a)).toFloat(), 3.2f * u, p)
                }
                fill(0xFFFFD84D.toInt())
                c.drawCircle(x, y, 3 * u, p)
            }
            7 -> {
                fill(0xFF1E1B4B.toInt())
                c.drawOval(RectF(cx - 36 * u, 18 * u, cx + 36 * u, 29 * u), p)
                path.reset()
                path.moveTo(cx - 20 * u, 22 * u)
                path.quadTo(cx - 4 * u, 17 * u, cx + 10 * u, 6 * u)
                path.quadTo(cx + 14 * u, 15 * u, cx + 20 * u, 22 * u)
                path.close()
                c.drawPath(path, p)
                fill(L.outfit2)
                c.drawRect(cx - 20 * u, 18 * u, cx + 20 * u, 22 * u, p)
                spark(c, cx + 12 * u, 14 * u, 3.5f * u, 0xFFFDE047.toInt())
            }
            8 -> {
                stroke(L.outfit2, 4f * u)
                c.drawArc(RectF(cx - 29 * u, 14 * u, cx + 29 * u, 60 * u), 205f, 130f, false, p)
            }
        }
    }

    // ---------------- body ----------------
    private fun body(c: Canvas, L: Look, u: Float, cx: Float) {
        fill(L.outfit)
        path.reset()
        path.moveTo(cx - 17 * u, 76 * u); path.lineTo(cx + 17 * u, 76 * u)
        path.lineTo(cx + 27 * u, 128 * u); path.lineTo(cx - 27 * u, 128 * u); path.close()
        c.drawPath(path, p)
        fill(L.outfit2)
        when (L.cloth) {
            1 -> {
                c.drawRoundRect(RectF(cx - 20 * u, 74 * u, cx + 20 * u, 85 * u), 5 * u, 5 * u, p)
                c.drawRoundRect(RectF(cx + 8 * u, 80 * u, cx + 17 * u, 104 * u), 4 * u, 4 * u, p)
            }
            2 -> {
                c.drawCircle(cx - 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx + 4 * u, 86 * u, 4 * u, p)
                c.drawCircle(cx, 86 * u, 2.5f * u, p)
            }
            3 -> {
                fill(Color.WHITE)
                path.reset()
                path.moveTo(cx - 17 * u, 76 * u); path.lineTo(cx + 17 * u, 76 * u); path.lineTo(cx + 12 * u, 92 * u)
                path.lineTo(cx, 84 * u); path.lineTo(cx - 12 * u, 92 * u); path.close()
                c.drawPath(path, p)
                fill(L.outfit2)
                c.drawCircle(cx, 85 * u, 3 * u, p)
            }
            4 -> {
                stroke(L.outfit2, 5f * u)
                c.drawArc(RectF(cx - 20 * u, 70 * u, cx + 20 * u, 90 * u), 10f, 160f, false, p)
                stroke(Color.WHITE, 1.4f * u)
                c.drawLine(cx - 4 * u, 88 * u, cx - 4 * u, 100 * u, p)
                c.drawLine(cx + 4 * u, 88 * u, cx + 4 * u, 100 * u, p)
            }
            else -> {
                path.reset()
                path.moveTo(cx - 9 * u, 76 * u); path.lineTo(cx + 9 * u, 76 * u); path.lineTo(cx, 90 * u); path.close()
                c.drawPath(path, p)
            }
        }
        if (waving) {
            val ang = Math.toRadians((-55 + sin(t * 2 * PI * 4) * 22).toDouble())
            val sx = cx + 20 * u
            val sy = 88 * u
            val hx = sx + (26 * u * cos(ang)).toFloat()
            val hy = sy + (26 * u * sin(ang)).toFloat()
            stroke(L.outfit, 6 * u)
            c.drawLine(sx, sy, hx, hy, p)
            fill(L.skin)
            c.drawCircle(hx, hy, 5 * u, p)
        }
    }

    // ---------------- face ----------------
    private fun eyes(c: Canvas, L: Look, u: Float, cx: Float, m: String, blink: Float, gx0: Float, gy0: Float) {
        var gx = gx0
        var gy = gy0
        when (m) {
            "shy" -> { gx = -2.5f * u; gy = 2.5f * u }
            "thinking" -> { gx = 2.5f * u; gy = -2.5f * u }
            "sad", "cry" -> { gx = 0f; gy = 1.5f * u }
        }
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * 12 * u
            val ey = 51 * u
            val arcUp = m == "happy" || (m == "wink" && s == -1)
            when {
                arcUp -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 200f, 140f, false, p)
                }
                m == "sleepy" -> {
                    stroke(ink, 2.2f * u)
                    c.drawArc(RectF(ex - 6 * u, ey - 5 * u, ex + 6 * u, ey + 5 * u), 20f, 140f, false, p)
                }
                m == "love" -> heart(c, ex, ey, 7 * u, 0xFFFF4D8D.toInt())
                m == "excited" -> {
                    fill(Color.WHITE)
                    c.drawOval(RectF(ex - 8 * u, ey - 10 * u, ex + 8 * u, ey + 10 * u), p)
                    spark(c, ex, ey, 9 * u, L.eye)
                    spark(c, ex - 2 * u, ey - 3 * u, 3 * u, Color.WHITE)
                }
                else -> {
                    val big = if (m == "surprised") 1.15f else 1f
                    val sq = if (m == "angry") 0.8f else 1f
                    c.save()
                    c.scale(1f, blink * sq, ex, ey)
                    fill(Color.WHITE)
                    c.drawOval(RectF(ex - 8 * u * big, ey - 10 * u * big, ex + 8 * u * big, ey + 10 * u * big), p)
                    val ir = (if (m == "surprised") 5.2f else 6.6f) * u
                    fill(L.eye)
                    c.drawCircle(ex + gx, ey + gy, ir, p)
                    fill(0xFF111827.toInt())
                    c.drawCircle(ex + gx, ey + gy, ir * 0.5f, p)
                    fill(Color.WHITE)
                    c.drawCircle(ex + gx - 2.5f * u, ey + gy - 3f * u, 2.2f * u, p)
                    c.drawCircle(ex + gx + 2.2f * u, ey + gy + 2.5f * u, 1.1f * u, p)
                    c.restore()
                    stroke(0xFF111827.toInt(), 1.8f * u)
                    c.drawArc(RectF(ex - 8.5f * u, ey - 10.5f * u, ex + 8.5f * u, ey + 9.5f * u), 205f, 130f, false, p)
                    if (m == "cry") {
                        val ph = (t * 2 + (if (s == 1) 0.3f else 0f)) % 1f
                        fill(0xCC60A5FA.toInt())
                        c.drawRoundRect(RectF(ex - 1.6f * u, ey + 9 * u, ex + 1.6f * u, ey + (12 + ph * 14) * u), 1.6f * u, 1.6f * u, p)
                    }
                }
            }
        }
    }

    private fun glasses(c: Canvas, u: Float, cx: Float) {
        stroke(0xFF334155.toInt(), 1.6f * u)
        c.drawCircle(cx - 12 * u, 51 * u, 10 * u, p)
        c.drawCircle(cx + 12 * u, 51 * u, 10 * u, p)
        c.drawLine(cx - 2 * u, 50 * u, cx + 2 * u, 50 * u, p)
    }

    private fun brows(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "sad", "cry", "shy" -> {
                stroke(ink, 1.8f * u)
                c.drawLine(cx - 19 * u, 41 * u, cx - 7 * u, 37 * u, p)
                c.drawLine(cx + 7 * u, 37 * u, cx + 19 * u, 41 * u, p)
            }
            "angry" -> {
                stroke(ink, 2.2f * u)
                c.drawLine(cx - 19 * u, 36 * u, cx - 7 * u, 40 * u, p)
                c.drawLine(cx + 7 * u, 40 * u, cx + 19 * u, 36 * u, p)
            }
            "surprised", "excited" -> {
                stroke(ink, 1.8f * u)
                c.drawArc(RectF(cx - 19 * u, 31 * u, cx - 7 * u, 41 * u), 200f, 140f, false, p)
                c.drawArc(RectF(cx + 7 * u, 31 * u, cx + 19 * u, 41 * u), 200f, 140f, false, p)
            }
            "thinking" -> {
                stroke(ink, 1.8f * u)
                c.drawLine(cx - 19 * u, 40 * u, cx - 7 * u, 40 * u, p)
                c.drawArc(RectF(cx + 7 * u, 30 * u, cx + 19 * u, 40 * u), 200f, 140f, false, p)
            }
        }
    }

    private fun mouth(c: Canvas, u: Float, cx: Float, m: String, mo: Float) {
        if (mo > 0.05f) {
            fill(lip)
            c.drawOval(RectF(cx - 4.5f * u, 65 * u, cx + 4.5f * u, (66 + 7 * mo) * u), p)
            return
        }
        when (m) {
            "happy", "wink" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 7 * u, 58 * u, cx + 7 * u, 72 * u), 20f, 140f, false, p) }
            "excited" -> { fill(lip); c.drawArc(RectF(cx - 7 * u, 60 * u, cx + 7 * u, 74 * u), 0f, 180f, true, p) }
            "sad" -> { stroke(lip, 1.8f * u); c.drawArc(RectF(cx - 5 * u, 68 * u, cx + 5 * u, 78 * u), 200f, 140f, false, p) }
            "cry" -> {
                stroke(lip, 1.8f * u)
                c.drawArc(RectF(cx - 5 * u, 68 * u, cx + 5 * u, 78 * u), 200f, 140f, false, p)
            }
            "shy" -> {
                stroke(lip, 1.6f * u)
                path.reset()
                path.moveTo(cx - 5 * u, 67 * u)
                path.quadTo(cx - 2.5f * u, 64 * u, cx, 67 * u)
                path.quadTo(cx + 2.5f * u, 70 * u, cx + 5 * u, 67 * u)
                c.drawPath(path, p)
            }
            "thinking" -> { fill(lip); c.drawOval(RectF(cx + 1 * u, 65 * u, cx + 6 * u, 70 * u), p) }
            "surprised" -> { fill(lip); c.drawOval(RectF(cx - 3.5f * u, 65 * u, cx + 3.5f * u, 73 * u), p) }
            "sleepy", "angry" -> { stroke(lip, 1.8f * u); c.drawLine(cx - 4 * u, 68 * u, cx + 4 * u, 68 * u, p) }
            else -> { stroke(lip, 1.6f * u); c.drawArc(RectF(cx - 5 * u, 62 * u, cx + 5 * u, 70 * u), 20f, 140f, false, p) }
        }
    }

    private fun extras(c: Canvas, u: Float, cx: Float, m: String) {
        when (m) {
            "love" -> for (i in 0..2) {
                val ph = (t + i / 3f) % 1f
                val a = ((1f - ph) * 255).toInt()
                heart(c, cx + (i - 1) * 16 * u + sin(ph * 6.28f) * 3 * u, 30 * u - ph * 26 * u, (3 + 2 * (1 - ph)) * u, Color.argb(a, 255, 77, 141))
            }
            "happy", "excited", "wink" -> {
                val a = (abs(sin(t * 2 * PI * 2)) * 255).toInt()
                spark(c, cx - 38 * u, 30 * u, 4 * u, Color.argb(a, 255, 220, 100))
                spark(c, cx + 38 * u, 58 * u, 3 * u, Color.argb(a, 255, 220, 100))
                if (m == "excited") spark(c, cx + 36 * u, 22 * u, 4.5f * u, Color.argb(255 - a, 255, 220, 100))
            }
            "shy" -> {
                fill(0xCC60A5FA.toInt())
                c.drawCircle(cx + 28 * u, 38 * u, 2 * u, p)
            }
            "thinking" -> {
                for (i in 0..2) {
                    val a = (((t * 3 - i) % 1f + 1f) % 1f * 255).toInt()
                    fill(Color.argb(a, 120, 120, 140))
                    c.drawCircle(cx + (30 + i * 6) * u, (20 - i * 6) * u, (1.8f + i * 0.5f) * u, p)
                }
            }
            "sad" -> {
                val ph = (t * 2) % 1f
                fill(0xCC60A5FA.toInt())
                c.drawCircle(cx - 16 * u, (58 + ph * 14) * u, 1.8f * u, p)
            }
            "sleepy" -> {
                val ph = t % 1f
                val a = ((1f - ph) * 255).toInt()
                fill(Color.argb(a, 147, 197, 253))
                p.textSize = 9 * u
                c.drawText("z", cx + 26 * u + ph * 6 * u, 24 * u - ph * 10 * u, p)
                p.textSize = 12 * u
                c.drawText("Z", cx + 32 * u + ph * 4 * u, 16 * u - ph * 8 * u, p)
            }
            "surprised" -> {
                fill(0xFFEF4444.toInt())
                p.textSize = 14 * u
                p.isFakeBoldText = true
                c.drawText("!", cx + 30 * u, 22 * u, p)
                p.isFakeBoldText = false
            }
            "angry" -> {
                stroke(0xFFEF4444.toInt(), 2f * u)
                c.drawLine(cx + 24 * u, 16 * u, cx + 32 * u, 24 * u, p)
                c.drawLine(cx + 32 * u, 16 * u, cx + 24 * u, 24 * u, p)
            }
        }
    }
}
