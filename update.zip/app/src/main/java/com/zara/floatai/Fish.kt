package com.zara.floatai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fish Audio text-to-speech. reference_id = voice model ID (Fish dashboard se). */
object Fish {
    fun tts(key: String, refId: String, text: String): ByteArray {
        if (key.isEmpty()) throw Eleven.Err(0, "", "Fish Audio key daalo (Voice card me).")
        if (refId.isEmpty()) throw Eleven.Err(0, "", "Fish voice ID khaali hai.")
        val body = JSONObject()
            .put("text", text)
            .put("reference_id", refId)
            .put("format", "mp3")
            .put("normalize", true)
        val con = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 15000
        con.readTimeout = 45000
        con.doOutput = true
        con.setRequestProperty("Authorization", "Bearer $key")
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Accept", "audio/mpeg")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val data = (if (code >= 400) con.errorStream else con.inputStream)?.readBytes() ?: ByteArray(0)
        if (code >= 400) throw Eleven.Err(code, "", String(data).take(160))
        return data
    }

    fun friendly(e: Exception): String {
        if (e is Eleven.Err) {
            return when (e.code) {
                0 -> e.message ?: "Error"
                401, 403 -> "Fish key galat ya permission nahi (" + e.code + ")."
                402 -> "Fish Audio credit khatam ya plan chahiye (402)."
                429 -> "Fish Audio par abhi limit hai (429). Thodi der baad."
                else -> "Fish error " + e.code + ": " + (e.message ?: "")
            }
        }
        if (e is java.io.IOException) return "Internet connect nahi ho raha."
        return "Error: " + (e.message ?: "unknown")
    }
}
